/* Enable experimental Windows trust store support */
pref("security.enterprise_roots.enabled", true);