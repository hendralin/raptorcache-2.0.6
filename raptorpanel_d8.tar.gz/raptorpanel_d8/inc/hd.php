<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
if (!function_exists('dir_path')) {
    include_once '/usr/share/raptor/main/functions.php';
}

require_once RP_PATH.'/global/lang.php';
require_once RP_PATH."/lang/$deflang.php";
?>


<div id="hard_disk_view">
<?php 

$imgsrc = "../images/line_green.png";

require RP_PATH.'/models/HardDisk.php';
$hd = new HardDisk();

for ($i=0; $i < $hd->getCountDisk(); $i++) {
	$name_disk = explode("/dev/", $hd->arr_dev_disk[$i]);
	$name_sdx = $name_disk[1];

	echo '<div id="hdall">';
	echo '<table class="tg">';

	$smt = $hd->getSmartool($name_sdx);
	$io = $hd->getIostat($name_sdx);
	$spaceHd = $hd->getSpaceHd($name_sdx);
 ?>

	  <tr>
	  	<th colspan="9" style="width:944px;border-left:none;text-align:left;"><?php echo $smt[0]."&nbsp;&nbsp; Model - ".$smt[1]; ?></th>
	  </tr>
	  <tr>    
	  	<td class="hd_head" rowspan="5">
	  		<div class="hd_icon"><font style="font-size:12px;color:#555;"><strong><?php echo $hd->arr_dev_disk[$i]; ?></strong></font>
	  			<div id="lghd"></div>
	  			<font style="font-size:12px;color:#555;"><strong><?php echo $smt[2]; ?></strong></font>
	  		</div>
	  	</td>      
	  </tr>  

	  <tr><td style="background:#efefef;">

		<table class="hd_stats">
		  <tr>
		    <th class="">S.M.A.R.T</th>
		    <th class="">Write Req. /s</th>
		    <th class="">Write KB/s</th>
		    <th class="">Read Req. /s</th>
		    <th class="">Read KB/s</th>
		    <th class=""><?php echo $hd_temp; ?></th>		    
		    <th class="">I/O</th>
		  </tr>	  
		  <tr>       	
		    <td class=""><?php echo $smt[3]; ?></td>
		    <td class=""><?php echo $io[0]; ?></td>
		    <td class=""><?php echo $io[1]; ?></td>	    
		    <td class=""><?php echo $io[2]; ?></td>
		    <td class=""><?php echo $io[3]; ?></td>
		    <td class=""><?php echo $hd->getTempHd($name_sdx); ?></td>
		    <td class="" style="text-align:left;">
	        	<div class="graph_hd_io">  
	        	    <?php
	        	    	if ($io[4] < 25) {
	        	    	 	$ios = "<span>".$io[4]."%</span>";
	        	    	 } else {
	        	    	 	$ios = "<span style='color:#fff'>".$io[4]."%</span>";
	        	    	 }
	        	     ?>
	            	<div class="bar" style='background-image:url(<?php echo $imgsrc; ?>);position:relative;z-index:20;width: <?php echo $io[4]; ?>%;'> <?php echo $ios; ?></div>
	        	</div>
		    </td>
		  </tr>
		  <tr>    
		  	<th class="th-2">Hours On</th>
		    <th class="th-2">Offline Uncorrectable</th>    
		    <th class="th-2">Reallocated Sector</th>
		    <th class="th-2">Seek Error</th>
		    <th class="th-2">Espera</th>
		    <th class="th-2"><?php echo "Usage"; ?></th>
		    <th class="th-2"><?php echo "Free"; ?></th>
		  </tr>
		  <tr>    
		    <td class=""><?php echo end($smt[4]); ?></td>
		    <td class=""><?php echo end($smt[5]); ?></td>
		    <td class=""><?php echo end($smt[6]); ?></td>
		    <td class=""><?php echo end($smt[7]); ?></td>
		    <td class=""><?php echo $hd->getLatencyHd($name_sdx); ?></td>
		    <td class="c_blue"><?php echo $spaceHd[2]; ?></td>
		    <td class="c_blue"><?php echo $spaceHd[3]; ?></td>
		  </tr>	  
		</table>

	  </td></tr>
	</table>
</div>

<?php }
?>

</div>