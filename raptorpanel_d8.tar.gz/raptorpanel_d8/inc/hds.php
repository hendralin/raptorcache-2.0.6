<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
if (!function_exists('dir_path')) {
    include_once '/usr/share/raptor/main/functions.php';
}

require_once RP_PATH.'/global/lang.php';
require_once RP_PATH."/lang/$deflang.php";
?>
        <table class="tabhdsys" style="" cellspacing="0" >   
          <tr>    
            <th>&nbsp;</th>
            <th><?php echo $sysdisk_dsk; ?></th>
            <th><?php echo $sysdisk_cdir; ?></th>
            <th><?php echo $sysdisk_et;; ?></th>
            <th><?php echo $sysdisk_eu;; ?></th>
            <th><?php echo $sysdisk_el; ?></th>
            <th><?php echo $sysdisk_u; ?></th>
            <th style="border-right:none"><?php echo $sysdisk_temp; ?></th>
          </tr>

<?php 

require RP_PATH.'/models/HardDisk.php';
$hd = new HardDisk();

for ($i=0; $i < $hd->getCountDisk(); $i++) {
  $name_disk = explode("/dev/", $hd->arr_dev_disk[$i]);
  $name_sdx = $name_disk[1];

  $mountHd = $hd->getMountHd($name_sdx);
  $spaceHd = $hd->getSpaceHd($name_sdx);

?>
          <tr>  
            <td style="width:10px;" class="last"><?php echo ""; ?></td> 
            <td style="" class="last"><?php echo $hd->arr_dev_disk[$i]; ?></td>              
            <td style="" class="last"><?php if($mountHd == "System") echo "<span style='color:#2ec2d0;'>".$mountHd."</span>";else echo $mountHd; ?></td>              
            <td style="" class="last"><?php echo $spaceHd[1]; ?></td>              
            <td style="" class="last"><?php echo $spaceHd[2]; ?></td>              
            <td style="color:green;" class="last"><?php echo $spaceHd[3]; ?></td>              
            <td style="color:#2ec2d0;" class="last"><?php echo $spaceHd[4]; ?></td>           
            <td style="color:green;" class="last"><?php echo $hd->getTempHd($name_sdx); ?></td>          
          </tr> 
<?php 
}
?>

       </table>        
