<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

require_once "../main/functions.php";
require "../class/Database.php";

$db = Database::getInstance();
$db->getConnection();

$requestData= $_REQUEST;

$columns = array( 
	0 =>'date_ssl', 
	1 =>'count_files', 
	2 => 'file_size',
	3=> 'eco_size',
	4=> 'hits'
);

$sql = "SELECT DATE_FORMAT(date_ssl,'%d/%m/%Y') as date_ssl, count_files, file_size, eco_size, hits ";
$sql.=" FROM `raptor`.`ssl`";
$query         = $db->execute($sql);
$totalData     = mysqli_num_rows($query);
$totalFiltered = $totalData; 

$sql = "SELECT DATE_FORMAT(date_ssl,'%d/%m/%Y') as date_ssl, count_files, file_size, eco_size, hits ";
$sql.=" FROM `raptor`.`ssl` ";

if( !empty($requestData['search']['value']) ) {   
	$sql.=" HAVING domain LIKE '".$requestData['search']['value']."%' ";    
}

$query         = $db->execute($sql);
$totalFiltered = mysqli_num_rows($query);  
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";	
$query         = $db->execute($sql);

$data = array();
while( $row = mysqli_fetch_array($query) ) { 
	$nestedData= array(); 
	$percent   = round(($row["eco_size"]/$row["file_size"])*100,2);
	$hits      = $row["hits"];
	
	$nestedData[] = "<div style='text-align:center;'><img src='".get_view_link()."/images/imgpng/date.png' style='height:16px;vertical-align:bottom' alt='' /></div>";
	$nestedData[] = $row["date_ssl"];
	$nestedData[] = $row["count_files"];
	$nestedData[] = sizeFormat($row["file_size"]);
	$nestedData[] = sizeFormat($row["eco_size"]);
	$nestedData[] = round($hits,0);
	$nestedData[] = $percent."%";
	
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),    
			"recordsTotal"    => intval( $totalData ),  
			"recordsFiltered" => intval( $totalFiltered ), 
			"data"            => $data   
			);

echo json_encode($json_data);  

$db->disconnectDB();

?>
