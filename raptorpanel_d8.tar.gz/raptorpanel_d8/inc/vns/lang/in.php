<?php 
session_start();

include_once "../../main/functions.php";

require "../../global/lang.php";
require "../../lang/$deflang.php";
?>
<?php

// sidebar labels
$L['summary'] = $vns_res;
$L['hours'] = $vns_hr;
$L['days'] = $vns_d;
$L['months'] = $vns_m;

// main table headers
$L['Summary'] = $vns_res2;
$L['Top 10 days'] = $vns_t10;
$L['Last 24 hours'] = $vns_u24h;
$L['Last 30 days'] = $vns_u30d;
$L['Last 12 months'] = $vns_u12m;

// traffic table columns
$L['In'] = 'In';
$L['Out'] = 'Out';
$L['Total'] = 'Total';

// summary rows
$L['This hour'] = $vns_eh;
$L['This day'] = $vns_ed;
$L['This month'] = $vns_em;
$L['All time'] = $vns_tt;

// graph text
$L['Traffic data for'] = 'Trafico de datos';
$L['bytes in'] = 'TX';
$L['bytes out'] = 'RX';

// date formats
$L['datefmt_days'] = '%d %B';
$L['datefmt_days_img'] = '%d';
$L['datefmt_months'] = '%B %Y';
$L['datefmt_months_img'] = '%b';
$L['datefmt_hours'] = '%l%P';
$L['datefmt_hours_img'] = '%l';
$L['datefmt_top'] = '%d %B %Y';
