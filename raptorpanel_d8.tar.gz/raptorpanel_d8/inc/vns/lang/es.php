<?php

// sidebar labels
$L['summary'] = $_SESSION["rp"]["dia"]["vns_res"];
$L['hours'] = $_SESSION["rp"]["dia"]["vns_hr"];
$L['days'] = $_SESSION["rp"]["dia"]["vns_d"];
$L['months'] = $_SESSION["rp"]["dia"]["vns_m"];

// main table headers
$L['Summary'] = $_SESSION["rp"]["dia"]["vns_res2"];
$L['Top 10 days'] = $_SESSION["rp"]["dia"]["vns_t10"];
$L['Last 24 hours'] = $_SESSION["rp"]["dia"]["vns_u24h"];
$L['Last 30 days'] = $_SESSION["rp"]["dia"]["vns_u30d"];
$L['Last 12 months'] = $_SESSION["rp"]["dia"]["vns_u12m"];

// traffic table columns
$L['In'] = 'In';
$L['Out'] = 'Out';
$L['Total'] = 'Total';

// summary rows
$L['This hour'] = $_SESSION["rp"]["dia"]["vns_eh"];
$L['This day'] = $_SESSION["rp"]["dia"]["vns_ed"];
$L['This month'] = $_SESSION["rp"]["dia"]["vns_em"];
$L['All time'] = $_SESSION["rp"]["dia"]["vns_tt"];;

// graph text
$L['Traffic data for'] = 'Trafico de datos';
$L['bytes in'] = 'TX';
$L['bytes out'] = 'RX';

// date formats
$L['datefmt_days'] = '%d %B';
$L['datefmt_days_img'] = '%d';
$L['datefmt_months'] = '%B %Y';
$L['datefmt_months_img'] = '%b';
$L['datefmt_hours'] = '%l%P';
$L['datefmt_hours_img'] = '%l';
$L['datefmt_top'] = '%d %B %Y';
