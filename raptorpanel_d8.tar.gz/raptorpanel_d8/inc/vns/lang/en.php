<?php 

// sidebar labels
$L['summary'] = 'Resumen';
$L['hours'] = 'Horas';
$L['days'] = 'D&iacute;as';
$L['months'] = 'Meses';

// main table headers
$L['Summary'] = 'Resumen';
$L['Top 10 days'] = 'Top 10 D&iacute;as';
$L['Last 24 hours'] = '&Uacute;ltimas 24 Horas';
$L['Last 30 days'] = '&Uacute;ltimos 30 D&iacute;as';
$L['Last 12 months'] = '&Uacute;ltimos 12 Meses';

// traffic table columns
$L['In'] = 'In';
$L['Out'] = 'Out';
$L['Total'] = 'Total';

// summary rows
$L['This hour'] = 'Esta Hora';
$L['This day'] = 'Este Dia';
$L['This month'] = 'Este Mes';
$L['All time'] = 'Todo el Tiempo';

// graph text
$L['Traffic data for'] = 'Tr&aacute;fico de datos';
$L['bytes in'] = 'Bytes In';
$L['bytes out'] = 'Bytes Out';

// date formats
$L['datefmt_days'] = '%d %B';
$L['datefmt_days_img'] = '%d';
$L['datefmt_months'] = '%B %Y';
$L['datefmt_months_img'] = '%b';
$L['datefmt_hours'] = '%l%P';
$L['datefmt_hours_img'] = '%l';
$L['datefmt_top'] = '%d %B %Y';
