<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

 ?>

<table class="sortable body_log" cellspacing='0'>
	<tr>
		<td>
			<div class="rep_logs_lst">
<pre class="log_lst">
<?php system("sudo tail -60 /var/log/raptor/sys.log | sort -r"); ?>
</pre>			
			</div>	
		</td>
	</tr>
</table>
