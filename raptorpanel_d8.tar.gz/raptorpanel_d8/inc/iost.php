<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();
if (!function_exists('dir_path')) {
    include_once $_SERVER['DOCUMENT_ROOT'].'/main/functions.php';
}

require_once RP_PATH.'/global/lang.php';
require_once RP_PATH."/lang/$deflang.php";
?>

<div id="io">
	<table class="sortable">
		<tr><th class="sel_log">Input/Output Stat</th></tr>
	</table>

	<table class="sortable body_log" cellspacing='0'>
	                  
		  <tr>    
		  	<th>&nbsp;</th>
		  	<th>%user</th>
		  	<th>%nice</th>
		    <th>%system</th>    
		    <th>%iowait</th>
		    <th>%steal</th>
		    <th style="border-right:none;">%idle</th>
		  </tr>	
<?php 
        $iostat_cpu = exec("iostat -c 1 2 | grep -v 'Linux' | sed '/[0-9]/!d' | tail -1");
        $iostat_cpu = ltrim($iostat_cpu);
        //echo ltrim($iostat_cpu)."<br>";
        while (strpos($iostat_cpu, "  ") > 0 ) 
          $iostat_cpu = str_replace("  ", " ", $iostat_cpu);
        $iostat_cpu = explode(" ", ltrim($iostat_cpu));        
 ?>
		  <tr>    
			<td class="iostat">AVG CPU</td>  
		    <td class="iostat"><?php echo $iostat_cpu[0]; ?></td>
		    <td class="iostat"><?php echo $iostat_cpu[1]; ?></td>
		    <td class="iostat"><?php echo $iostat_cpu[2]; ?></td>
		    <td class="iostat"><?php echo $iostat_cpu[3]; ?></td>
		    <td class="iostat"><?php echo $iostat_cpu[4]; ?></td>
		    <td class="iostat"><?php echo $iostat_cpu[5]; ?></td>
		  </tr>			  

	</table>

	<table class="sortable body_log" cellspacing='0'>
	                  
		  <tr>    
		  	<th>Dev.</th>
		  	<th>rrqm/s</th>
		    <th>wrqm/s</th>    
		    <th>r/s</th>
		    <th>w/s</th>
		    <th>rkB/s</th>
		    <th>wkB/s</th>
		    <th>avgrq-sz</th>
		    <th>avgqu-sz</th>
		    <th>await</th>
		    <th>r_await</th>
		    <th>w_await</th>
		    <th>svctm</th>
		    <th style="border-right:none;">%util</th>
		  </tr>	
<?php 
	$count_disk = shell_exec("sudo fdisk -l | grep 'Disk' | grep bytes | grep -Ee '/dev/sd[a-z]' | grep -v '/dev/dm-0' | grep -v '/dev/mapper/' | wc -l");

	$dev_disk = shell_exec("sudo fdisk -l /dev/sd? | grep Disk |grep bytes | awk '{print $2}'");
	$dev_disk = explode(":", $dev_disk);

	for ($i=0; $i < $count_disk ; $i++) {

		$name_disk = explode("/dev/", $dev_disk[$i]);
		$name_disk_sdx = $name_disk[1];

        $iostat = exec("iostat -x -d -k 1 2 $name_disk_sdx | tail -2 | grep \"$name_disk_sdx\"");
        while (strpos($iostat, "  ") > 0 )
          $iostat = str_replace("  ", " ", $iostat);
        $iostat = explode(" ", $iostat);        
 ?>
		  <tr>    
		    <td style="color:#0e82b2"><?php echo $iostat[0]; ?></td>
		    <td class="iostat"><?php echo $iostat[1]; ?></td>
		    <td class="iostat"><?php echo $iostat[2]; ?></td>
		    <td class="iostat"><?php echo $iostat[3]; ?></td>
		    <td class="iostat"><?php echo $iostat[4]; ?></td>
		    <td class="iostat"><?php echo $iostat[5]; ?></td>
		    <td class="iostat"><?php echo $iostat[6]; ?></td>
		    <td class="iostat"><?php echo $iostat[7]; ?></td>
		    <td class="iostat"><?php echo $iostat[8]; ?></td>
		    <td class="iostat"><?php echo $iostat[9]; ?></td>
		    <td class="iostat"><?php echo $iostat[10]; ?></td>
		    <td class="iostat"><?php echo $iostat[11]; ?></td>
		    <td class="iostat"><?php echo $iostat[12]; ?></td>
		   	<td class="iostat"><?php echo $iostat[13]; ?></td>
		  </tr>			  
<?php }
?>
	</table>
</div>