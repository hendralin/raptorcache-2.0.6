<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

echo "<div id=\"ping_dns\">";
echo "<table class=\"sortable body_log\" cellspacing='0'>";
error_reporting(0);
	echo "<tr>";
		echo "<th>&nbsp;</th>";
		echo "<th>Host</th>";			
		echo "<th>Size</th>";
		//echo "<th>&nbsp;</th>";
		//echo "<th>&nbsp;</th>";	
		echo "<th>Icmp Req.</th>"; 
		echo "<th>TTL</th>"; 
		echo "<th style=\"border-right:none;\">Time</th>";		
	echo "</tr>";

	$first_dns = exec("cat /etc/resolv.conf | grep nameserv | grep -v '##-##' | head -1 | awk {'print $2'}");

	exec("sudo ping ".trim($first_dns)." -c 1 | grep icmp > /dev/shm/ping-dns");
	$logfile = file("/dev/shm/ping-dns");

        for ($i=sizeof($logfile);$i>0;$i--) {        
        	$row = trim($logfile[$i-1]);
        	$rw = explode(" ", chop($row));
        	//if (trim($rw[2]) == "from")
        	//	$from = "FROM";

        	$address = explode(":",$rw[3]);
        	$icmp = explode("=",$rw[4]);
        	$ttl = explode("=",$rw[5]);

        	$time = explode("=",$rw[6]);
        	$time_dns = $time[1];

        	if ($time_dns <= 320) {
        		$time_dns = "<span class=\"c_blue\">".$time_dns." ms</span>";
        	}
        	else if ($time_dns > 320 && $time_dns <= 960) {
        		$time_dns = "<span class=\"c_orange\">".$time_dns." ms</span>";
        	}
        	else if ($time_dns > 960) {
        		$time_dns = "<span class=\"c_red\">".$time_dns." ms</span>";
        	}

		    echo "<tr class=\"row\" >" ;
		    	echo "<td style=\"width:20px;\" ></td>";
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$address[0]."</td>";		    	
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$rw[0]." bytes</td>";
				//echo "<td style=\"width:72px;\" class=\"c_blue\">".$rw[1]."</td>";		    	
				//echo "<td style=\"width:72px;\" class=\"c_blue\">".$from."</td>";		    			    	
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$icmp[1]."</td>";
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$ttl[1]."</td>";
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$time_dns."</td>";
			echo "</tr>";
        }

        echo "</table>";
echo "</div>";        
 ?>
