<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

require_once '../main/auth.php';

if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}

require "../class/Database.php";

$db = Database::getInstance();
$db->getConnection();

$requestData= $_REQUEST;

$columns = array( 
	0 => 'domain', 
	1 => 'domain', 
	2 => 'files',
	3 => 'sizes',
	4 => 'eco',
	5 => 'hits',
	6 => 'percent'
);

$sql = "SELECT domain, COUNT(*) as files, sum(file_size) as sizes, sum(requested_size) as eco, sum(requested_size/file_size) as hits, sum(requested_size)/sum(file_size) as percent";
$sql.= " FROM raptor group by domain";
$query         = $db->execute($sql);
$totalData     = mysqli_num_rows($query);
$totalFiltered = $totalData; 
/*
$sql = "SELECT domain, COUNT(*) as files, sum(file_size) as sizes, sum(requested_size) as eco, sum(requested_size/file_size) as hits ";
$sql.=" FROM raptor WHERE 1=1 group by domain ";
 */
if( !empty($requestData['search']['value']) ) {   
	$sql.=" HAVING domain LIKE '".$requestData['search']['value']."%' ";    
}

$query         = $db->execute($sql);
$totalFiltered = mysqli_num_rows($query);  
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";	
$query         = $db->execute($sql);

$data = array();
while( $row = mysqli_fetch_array($query) ) { 
	$nestedData= array(); 
	//$percent   = round(($row["eco"]/$row["sizes"])*100,2);
	$percent   = round($row["percent"] * 100, 2);
	$domain    = $row["domain"];
	$hits      = 0;
	$hits      = $hist + $row["hits"];
		if (file_exists(get_view_link()."/images/img-domain/$domain.png")) {
			$icon = get_view_link()."/images/img-domain/$domain.png";
		} else {
			$icon = get_view_link()."/images/img-domain/1link.png";
		}	
	$nestedData[] = "<div style='text-align:center;'><img src='$icon' style='height:16px;vertical-align:bottom' alt='' /></div>";
	$nestedData[] = $row["domain"];
	$nestedData[] = $row["files"];
	$nestedData[] = sizeFormat($row["sizes"]);
	$nestedData[] = sizeFormat($row["eco"]);
	$nestedData[] = round($hits,0);
	$nestedData[] = $percent."%";
	
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),    
			"recordsTotal"    => intval( $totalData ),  
			"recordsFiltered" => intval( $totalFiltered ), 
			"data"            => $data   
			);

echo json_encode($json_data);  

$db->disconnectDB();

?>
