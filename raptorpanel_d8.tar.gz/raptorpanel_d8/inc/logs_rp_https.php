<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

echo "<table id=\"log_ajx_https\" class=\"sortable body_log\" cellspacing='0'>";
error_reporting(0);
	echo "<tr>";
		echo "<th>&nbsp;</th>";
		echo "<th>Date/Time</th>";
		echo "<th>State</th>";
		//echo "<th>Method</th>";
		echo "<th>Type</th>";
		echo "<th>Domain</th>";
		echo "<th>File</th>"; 
		echo "<th style=\"border-right:none;\">Size</th>";		
	echo "</tr>";

	$count_row_tail = 0;
	$count_row_tail = shell_exec("sudo tail -n 320 /var/log/squid3/access.log | grep https: | grep -v TCP_MISS/204 | grep -v CONNECT | grep -v TCP_MISS/304 | grep -E 'googlevideo|https://scontent' | wc -l");
	//$count_row_tail = exec("sudo tail -n 120 /var/log/squid3/access.log | grep https: | grep -v \"TCP_MISS/204\" | grep googlevideo | grep videoplayback | wc -l");

	$count_row_rptlgs = 0;
	$count_row_rptlgs = shell_exec("sudo cat /dev/shm/rptlgs | wc -l");
 
	if ( $count_row_rptlgs <= 30 && $count_row_tail > 30 ) {
		shell_exec("sudo tail -n 320 /var/log/squid3/access.log | grep https: | grep -v TCP_MISS/204 | grep -v CONNECT | grep -v TCP_MISS/304 | grep -E 'googlevideo|https://scontent' > /dev/shm/rptlgs");
	}
	else if ( $count_row_rptlgs == 0 && $count_row_tail > 0 ) {
		shell_exec("sudo tail -n 320 /var/log/squid3/access.log | grep https: | grep -v TCP_MISS/204 | grep -v CONNECT | grep -v TCP_MISS/304 | grep -E 'googlevideo|https://scontent' > /dev/shm/rptlgs");			
	} else {
		shell_exec("sudo tail -n 740 /var/log/squid3/access.log | grep https: | grep -v TCP_MISS/204 | grep -v CONNECT | grep -v TCP_MISS/304 | grep -E 'googlevideo|https://scontent' > /dev/shm/rptlgs");	
	}


	
	$logfile = file("/dev/shm/rptlgs");

        for ($i = sizeof($logfile); $i > 0; $i--) {        
			$row = trim($logfile[$i-1]);
			$rw = explode(" ", chop($row));
			//echo $rw[2]."<br>";
			$timestamp=$rw[0];
			$date = "<pre style=\"font-family:Verdana;font-size:12px;margin:0;padding:0;\">".date("d/m/Y", $timestamp)." ".date("h:i:s", $timestamp)."</pre>";

			$http = explode("://" , $rw[5]);
			if (strlen($http[1]) > 32) {
				$file = ".../ ".substr($http[1], -31);
			}else{
				$file = $http[1];
			}

			$domain = explode("/", $http[1]);
			//$domain = $domain[0];
			if (strlen($domain[0]) > 16) {
				$domain = substr($domain[0], -15);
			} else {         	
				$domain = $domain[0];
				if (empty($domain)) 
					continue;
			}         

			if($http[0]=="https"){$http[0]="HTTPS";};

			if ($rw[6] > 0) {         	
				$size_file = $rw[6];
			if($size_file<1024)
			{
				$size_file = $size_file." bytes";
				//$size_file = $size_file." KiB";
			}
			else if($size_file<(1024*1024))
			{
				$size_file=round($size_file/1024,2)." KiB";
			}
			else if($size_file<(1024*1024*1024))
			{
				$size_file=round($size_file/(1024*1024),2)." MiB";
			}
			else if($size_file/(1024*1024*1024*1024))
			{
				$size_file=round($size_file/(1024*1024*1024),2)." GiB";
			}else	{
				$size_file=round($size_file/(1024*1024*1024*1024),2)." TiB";
			}
			} else {
				$size_file = 0;
			}

			if ($rw[2] == "TCP_HIT/200" || $rw[2] == "TCP_MEM_HIT/200" || $rw[2] == "MEM_HIT/200") {
				$rw[2] = "HIT/200";
			echo "<tr class=\"row\" >" ;
				echo "<td style=\"width:20px;\" class=\"c_red\"><span class=\"icon-upload\"></td>";
				echo "<td style=\"width:120px;\" class=\"c_red\">".$date."</td>";
				echo "<td style=\"width:72px;\" class=\"c_red\">".$rw[2]."</td>";
				//echo "<td style=\"width:72px;\" class=\"c_red\">".$rw[2]."</td>";
				echo "<td style=\"width:72px;\" class=\"c_red\">".$http[0]."</td>";
				echo "<td style=\"width:160px;\" class=\"c_red\">".$domain."</td>";
				echo "<td style=\"text-align:left;width:240px;\" class=\"c_red\">".$file."</td>";
				echo "<td style=\"width:84px;\" class=\"c_red\">".$size_file."</td>";
			echo "</tr>";
			} else if ($rw[2] == "MISS/206") {
			echo "<tr class=\"row\" >" ;
				echo "<td style=\"width:20px;\" class=\"c_green\"><span class=\"icon-download\"></td>";		    
				echo "<td style=\"width:120px;\" class=\"c_green\">".$date."</td>";
				echo "<td style=\"width:72px;\" class=\"c_green\">".$rw[2]."</td>";
				//echo "<td style=\"width:72px;\" class=\"c_green\">".$rw[2]."</td>";
				echo "<td style=\"width:72px;\" class=\"c_green\">".$http[0]."</td>";
				echo "<td style=\"width:160px;\" class=\"c_green\">".$domain."</td>";
				echo "<td style=\"text-align:left;width:240px;\" class=\"c_green\">".$file."</td>";
				echo "<td style=\"width:84px;\" class=\"c_green\">".$size_file."</td>";
			echo "</tr>";
			} else if ($rw[2] == "MISS/302" || $rw[2] == "MISS/304" ||$rw[2] == "DELETED" || $rw[2] == "REDIRECT") {
			echo "<tr class=\"row\" >" ;
				echo "<td style=\"width:20px;\" class=\"c_orange\"><span class=\"icon-download\"></td>";		    
				echo "<td style=\"width:120px;\" class=\"c_orange\">".$date."</td>";
				echo "<td style=\"width:72px;\" class=\"c_orange\">".$rw[2]."</td>";
				//echo "<td style=\"width:72px;\" class=\"c_orange\">".$rw[2]."</td>";
				echo "<td style=\"width:72px;\" class=\"c_orange\">".$http[0]."</td>";
				echo "<td style=\"width:160px;\" class=\"c_orange\">".$domain."</td>";
				echo "<td style=\"text-align:left;width:240px;\" class=\"c_orange\">".$file."</td>";
				echo "<td style=\"width:84px;\" class=\"c_orange\">".$size_file."</td>";
			echo "</tr>";
			} else {
				$rw[2] = "MISS/200";
			echo "<tr class=\"row\">";
				echo "<td style=\"width:20px;\" class=\"c_blue\"><span class=\"icon-download\"></td>";		    
				echo "<td style=\"width:120px;\" class=\"c_blue\">".$date."</td>";
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$rw[2]."</td>";
				//echo "<td style=\"width:72px;\" class=\"c_blue\">".$rw[2]."</td>";
				echo "<td style=\"width:72px;\" class=\"c_blue\">".$http[0]."</td>";
				echo "<td style=\"width:160px;\" class=\"c_blue\">".$domain."</td>";
				echo "<td style=\"text-align:left;width:240px;\" class=\"c_blue\">".$file."</td>";
				echo "<td style=\"width:84px;\" class=\"c_blue\">".$size_file."</td>";
			echo "</tr>";
			}

        }

        echo "</table>";
 ?>
