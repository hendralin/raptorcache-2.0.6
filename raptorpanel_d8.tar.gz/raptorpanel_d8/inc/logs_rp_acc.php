<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

echo "<table id=\"log_ajx_acc\" class=\"sortable body_log\" cellspacing='0'>";
error_reporting(0);
	echo "<tr>";
		echo "<th>&nbsp;</th>";
		echo "<th>Date/Time</th>";
		echo "<th>State</th>";
		//echo "<th>Method</th>";
		echo "<th>Type</th>";
		echo "<th>Domain</th>";
		echo "<th>File</th>"; 
		echo "<th style=\"border-right:none;\">Size</th>";		
	echo "</tr>";

	exec("sudo tail -n 60 /var/log/raptor/access.log > /dev/shm/rptlg");
	$logfile = file("/dev/shm/rptlg");

        for ($i=sizeof($logfile);$i>0;$i--) {        
	         $row = trim($logfile[$i-1]);
	         $rw = explode(" ", chop($row));

			$timestamp=$rw[0];
			$date = "<pre style=\"font-family:Verdana;font-size:12px;margin:0;padding:0;\">".date("d/m/Y", $timestamp)." ".date("h:i:s", $timestamp)."</pre>";

	         $http = explode("://" , $rw[7]);
	         if (strlen($http[1])>32) {
	         	$file = ".../ ".substr($http[1], -31);
	         }else{
	         	$file = $http[1];
	         }

	         if($http[0]=="http"){$http[0]="HTTP";};

	         if ($rw[8] > 0) {         	
	         	$size_file = $rw[8];
				if($size_file<1024)
				{
			    	$size_file = $size_file." bytes";
				}
				else if($size_file<(1024*1024))
				{
			    	$size_file=round($size_file/1024,2)." KiB";
				}
				else if($size_file<(1024*1024*1024))
				{
			    	$size_file=round($size_file/(1024*1024),2)." MiB";
				}
				else if($size_file/(1024*1024*1024*1024))
				{
			    	$size_file=round($size_file/(1024*1024*1024),2)." GiB";
				}else	{
			    	$size_file=round($size_file/(1024*1024*1024*1024),2)." TiB";
				}
	         } else {
	         	$size_file = 0;
	         }

	         if ($rw[3] == "HIT/200") {
			    echo "<tr class=\"row\" >" ;
			    	echo "<td style=\"width:20px;\" class=\"c_red\"><span class=\"icon-upload\"></span></td>";
					echo "<td style=\"width:120px;\" class=\"c_red\">".$date."</td>";
					echo "<td style=\"width:72px;\" class=\"c_red\">".$rw[3]."</td>";
					//echo "<td style=\"width:72px;\" class=\"c_red\">".$rw[5]."</td>";
					echo "<td style=\"width:72px;\" class=\"c_red\">".$http[0]."</td>";
					echo "<td style=\"width:160px;\" class=\"c_red\">".$rw[6]."</td>";
					echo "<td style=\"text-align:left;width:240px;\" class=\"c_red\">".$file."</td>";
					echo "<td style=\"width:84px;\" class=\"c_red\">".$size_file."</td>";
				echo "</tr>";
	         }
	         else if ($rw[3] == "MISS/206") {
			    echo "<tr class=\"row\" >" ;
			    	echo "<td style=\"width:20px;\" class=\"c_green\"><span class=\"icon-download\"></span></td>";		    
					echo "<td style=\"width:120px;\" class=\"c_green\">".$date."</td>";
					echo "<td style=\"width:72px;\" class=\"c_green\">".$rw[3]."</td>";
					//echo "<td style=\"width:72px;\" class=\"c_green\">".$rw[5]."</td>";
					echo "<td style=\"width:72px;\" class=\"c_green\">".$http[0]."</td>";
					echo "<td style=\"width:160px;\" class=\"c_green\">".$rw[6]."</td>";
					echo "<td style=\"text-align:left;width:240px;\" class=\"c_green\">".$file."</td>";
					echo "<td style=\"width:84px;\" class=\"c_green\">".$size_file."</td>";
				echo "</tr>";
	         }else if ($rw[3] == "MISS/302" || $rw[3] == "MISS/304" ||$rw[3] == "DELETED" || $rw[3] == "REDIRECT") {
			    echo "<tr class=\"row\" >" ;
			    	echo "<td style=\"width:20px;\" class=\"c_orange\"><span class=\"icon-download\"></td>";		    
					echo "<td style=\"width:120px;\" class=\"c_orange\">".$date."</td>";
					echo "<td style=\"width:72px;\" class=\"c_orange\">".$rw[3]."</td>";
					//echo "<td style=\"width:72px;\" class=\"c_orange\">".$rw[5]."</td>";
					echo "<td style=\"width:72px;\" class=\"c_orange\">".$http[0]."</td>";
					echo "<td style=\"width:160px;\" class=\"c_orange\">".$rw[6]."</td>";
					echo "<td style=\"text-align:left;width:240px;\" class=\"c_orange\">".$file."</td>";
					echo "<td style=\"width:84px;\" class=\"c_orange\">".$size_file."</td>";
				echo "</tr>";
	         } else {

			    echo "<tr class=\"row\">";
			    	echo "<td style=\"width:20px;\" class=\"c_blue\"><span class=\"icon-download\"></td>";		    
					echo "<td style=\"width:120px;\" class=\"c_blue\">".$date."</td>";
					echo "<td style=\"width:72px;\" class=\"c_blue\">".$rw[3]."</td>";
					//echo "<td style=\"width:72px;\" class=\"c_blue\">".$rw[5]."</td>";
					echo "<td style=\"width:72px;\" class=\"c_blue\">".$http[0]."</td>";
					echo "<td style=\"width:160px;\" class=\"c_blue\">".$rw[6]."</td>";
					echo "<td style=\"text-align:left;width:240px;\" class=\"c_blue\">".$file."</td>";
					echo "<td style=\"width:84px;\" class=\"c_blue\">".$size_file."</td>";
				echo "</tr>";
			}	         
        }

        echo "</table>";
 ?>
