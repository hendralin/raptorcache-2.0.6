<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */
require_once '../main/auth.php';

if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}

require_once dir_path().'/class/Database.php';

$db = Database::getInstance();
$db->getConnection();

$requestData = $_REQUEST;

$columns = array( 
	0 =>'d_down', 
	1 =>'d_down', 
	2 => 'file',
	3=> 'file_size'
);

$sql = "SELECT DATE_FORMAT(d_down,'%d/%m/%Y') as d_down, file, file_size";
$sql.=" FROM `raptor`.`http`";
$query         = $db->execute($sql);
$totalData     = mysqli_num_rows($query);
$totalFiltered = $totalData; 

if( !empty($requestData['search']['value']) ) {   
	$sql.=" HAVING d_down LIKE '".$requestData['search']['value']."%' ";    
}
$query         = $db->execute($sql);
$totalFiltered = mysqli_num_rows($query);  
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";	
$query = $db->execute($sql);

$data = array();
while( $row = mysqli_fetch_array($query) ) { 
	$nestedData = array(); 
	
	$nestedData[] = "<div style='text-align:center;'><img src='".get_view_link()."/images/imgpng/date.png' style='height:16px;vertical-align:bottom' /></div>";
	$nestedData[] = $row["d_down"];
	$nestedData[] = $row["file"];
	$nestedData[] = sizeFormat($row["file_size"]);
	
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),    
			"recordsTotal"    => intval( $totalData ),  
			"recordsFiltered" => intval( $totalFiltered ), 
			"data"            => $data   
			);

echo json_encode($json_data);  

$db->disconnectDB();

?>
