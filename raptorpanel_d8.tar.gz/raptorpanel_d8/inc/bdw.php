<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();
if (!function_exists('dir_path')) {
    include_once $_SERVER['DOCUMENT_ROOT'].'/main/functions.php';
    include_once $_SERVER['DOCUMENT_ROOT'].'/main/settings.php';
}

?>
<table id="ethmon"><tr><td><?php echo trafEth($eth_input_server, '/var/tmp/ethmon'); ?></td></tr></table>