<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

require_once $_SERVER['DOCUMENT_ROOT']."/global/lang.php";
require_once $_SERVER['DOCUMENT_ROOT']."/lang/$deflang.php";

include_once $_SERVER['DOCUMENT_ROOT'].'/models/SyState.php';

$sys = new SyState();

?>

<div id="tbsys">  

  <div class="cpustate1">        
        <table>                    
          <tr>
            <th><div id="im1a"></div><?php echo $vit_er; ?></th>
            <td><p class="first_block"><?php echo $sys->stat_cache("8080") ?></p></td>
            <td><p class="first_block"><?php echo $sys->version_rp(); ?></p></td>
          </tr>
          <tr>
            <th><div id="im2a"></div><?php echo $vit_es; ?></th>
            <td><p class="first_block"><?php echo $sys->stat_cache("3128") ?></p></td>
            <td><p class="first_block"><?php echo $sys->version_sq(); ?></p></td>      
          </tr>        
          <tr>
            <th><div id="im3a"></div><?php echo $vit_con; ?></th>
            <td><p class="first_block"><?php echo $sys->cnx_us(); ?></p></td>  
            <td><p class="first_block"><?php echo $sys->open_threads_netstat(); ?></p></td>          
          </tr>            
          <tr>
            <th><div id="im4a"></div><?php echo $vit_us; ?></th>
            <td><p class="first_block"><?php echo $sys->num_us(); ?></p></td>
            <td></td>
          </tr>        
        </table>
  </div>

    <div class="cpustate2">        
      <table>                              
        <tr>
          <th><div id="im1b"></div><?php echo $vit_dns; ?></th>
          <td><p class="first_block"><?php echo $sys->cnx_dns(); ?></p></td>            
        </tr>       
        <tr>
          <th><div id="im2b"></div><?php echo $vit_tact; ?></th>
          <td><p class="first_block"><?php echo $sys->uptime(); ?></p></td>            
        </tr>
        <tr>
          <th><div id="im3b"></div><?php echo $vit_temp; ?></th>
          <td><p class="first_block"><?php echo $sys->cpu_temp(); ?></p></td>            
        </tr>
        <tr>
          <th><div id="im4b"></div><?php echo "&nbsp;I/O"; ?></th>
          <td><p class="first_block"><?php echo $sys->io_cpu(); ?></p></td>            
        </tr>        
      </table>
    </div>

  <div class="sysbar">
    <table>
    <tr>
      <td class="bartitle">L.A.</td>
      <td><span class="lavg"><?php echo $sys->system_load(); ?></span></td>
    </tr>

    <tr><td class="bartitle" style="">CPU</td>
        <td>
          <div class="graphcpu1">  
            <div class="bar" style='width: <?php $cpu_usage = $sys->cpu_bar(); echo $cpu_usage[0]; ?>%;'> <?php echo $cpu_usage[1]; ?></div>
          </div>
        </td>
    </tr>

    <tr><td class="bartitle" style="">RAM</td>
    <?php include_once $_SERVER['DOCUMENT_ROOT'].'/models/MemoryRam.php'; 
          $mem = new MemoryRam();
          $mem_value = $mem->getValuesRam();
    ?>
        <td>
          <div class="graphm1">  
            <div class="bar" style="width: <?php echo $mem_value[4]; ?>%;"> <?php echo $mem_value[4]; ?>%</div>
          </div>
        </td>
    </tr>

    </table>
  </div>

</div>
