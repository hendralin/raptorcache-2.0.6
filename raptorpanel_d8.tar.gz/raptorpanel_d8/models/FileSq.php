<?php 

class FileSq
{

	private $file = "/etc/squid3/squid.conf";
	public $dns1;
	public $dns2;

	public function get_dns_nameservers()
	{
		$file = $this->file;
		$line_dns_nameservers = search_string($file, "dns_nameservers");
		$line_dns_nameservers = $line_dns_nameservers['string'];
		$dir_dns_nameservers = explode(" ",$line_dns_nameservers);
		$this->dns1 = $dir_dns_nameservers[1];
		$this->dns2 = $dir_dns_nameservers[2];		
	}

	public function show_localnet() 
	{
		$file = $this->file;
		$content = file($file);
		echo "<table class=\"sortable\" cellspacing='0' style=\"border-radius:3px;width:372px;margin-left:10px;margin-bottom:0;\">";
		echo "<tr>";
		echo "<th style='border-right:none;'>ACL Localnet</th><th style='border-right:none;'></th>";
		echo "</tr>";
		$pos = 0;
		foreach( $content as $line_search ) {        
			if (strstr($line_search, 'acl localnet')) {
				$row_string = $pos+1;  
				$file_content = file_get_contents($file);
				$arr_lines = explode("\n", $file_content);
				$line_string = $arr_lines[($row_string-1)];
				$value = explode(" ", $line_string);
				$value = $value[3];
				$delete_line = "<a class='del_regx' href='sqconf.req?delete_line={$value}'>X</a>";
				echo "<tr class='row'><td>".$value."</td><td style='text-align:right;'>".$delete_line."</td></tr>";
			}
			$pos++;
		}
		echo "</table>";  
	}

	public function __call($name, $arguments)
	{
		$no_method = true;

		$method_name = substr($name, 0, 3);

		if ($method_name == 'get') {
			$no_method = false;
			$real_name = substr(strtolower($name), 4);
			return $this->$real_name;
		}

		if ($no_method) {
			throw Exception("Method {$name} no found");			
		}

	}	

}

 ?>