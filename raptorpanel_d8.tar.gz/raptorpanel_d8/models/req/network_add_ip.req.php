<?php 
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

session_start();

$interface_r = $_POST['interface'];
$ip_r = $_POST['ip'];
$netmask_r = $_POST['netmask'];
$network_r = $_POST['network'];
$broadcast_r = $_POST['broadcast'];
$gateway_r = $_POST['gateway'];

$dns_nameservers_r = exec("sudo cat /etc/resolv.conf | grep -v '##-##' | grep nameserver | head -1 | awk '{print $2}'");

$network_i = exec("sudo cat /etc/network/interfaces | grep address | awk {'print $2'} | head -n1");
if ($ip_r == $network_i) {
	header('location:Network_Config?error_add_ip=no');
	exit();
} else {
	$dt = date('dhi');
	$tag = "#".$interface_r."#".$dt;

	$allow = "allow-hotplug ".$interface_r;
	$iface = "iface ".$interface_r." inet static";
	$address = "	address ".$ip_r;
	$netmask = "	netmask ".$netmask_r;
	$network = "	network ".$network_r;
	$broadcast = "	broadcast ".$broadcast_r;
	$gateway = "	gateway ".$gateway_r;
	$dns_comment = "	# dns-* options are implemented by the resolvconf package, if installed";
	$dns_nameservers = "	dns-nameservers ".$dns_nameservers_r;
	$dns_search = "	dns-search raptorcache.org ";

	$nb = "\n";

	$file = fopen("/etc/network/interfaces", "w+");

	fwrite($file, "# The loopback network interface" . PHP_EOL);
	fwrite($file, "auto lo" . PHP_EOL);
	fwrite($file, "iface lo inet loopback" . PHP_EOL);
	//fwrite($file, $nb . PHP_EOL);
	fwrite($file, "# The primary network interface" . PHP_EOL);
	fwrite($file, $allow . PHP_EOL);
	fwrite($file, $iface . PHP_EOL);
	fwrite($file, $address . PHP_EOL);
	fwrite($file, $netmask . PHP_EOL);
	fwrite($file, $network . PHP_EOL);
	fwrite($file, $broadcast . PHP_EOL);
	fwrite($file, $gateway . PHP_EOL);
	fwrite($file, $dns_comment . PHP_EOL);
	fwrite($file, $dns_nameservers . PHP_EOL);
	fwrite($file, $dns_search . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);

	fclose($file);
}

header('location:Network_Config');

 ?>