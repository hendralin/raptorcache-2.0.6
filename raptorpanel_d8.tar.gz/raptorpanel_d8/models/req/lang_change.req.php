<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

if(isset($_POST['lang'])){       
    $archivo = fopen("global/lang.php","w");    
    $cadena = "<?php
    
\$deflang=\"".$_POST['lang']."\";\r\n
?>
";  
    fputs($archivo,$cadena);     
    fclose($archivo);  
}
echo "<script>window.location='Language_Config';</script>";
 ?>