<?PHP
/**
 *
 * @package Raptorcache
 * @since 1.0
 */
 
 session_start();

include_once '/usr/share/raptor/main/functions.php';

$file = "/etc/raptor/raptor.conf";
$content = file_get_contents($file);

if (isset($_POST['rp_submit'])) {  

  $value_cache_limit = empty($_POST['cache_limit']) ? "80" : $_POST['cache_limit'];   
  $value_min_object_size = empty($_POST['min_object_size']) ? "2048" : $_POST['min_object_size'];

  $row_cache_limit = search_string($file, "CACHE_LIMIT");
  $row_cache_limit = $row_cache_limit['string']; 
  $name_cache_limit = explode(" ", $row_cache_limit);
  $new_line_cl      = $name_cache_limit[0]." ".$value_cache_limit;
 
  	file_put_contents($file, str_replace($row_cache_limit, $new_line_cl, $content));

  $row_min_object_size  = search_string($file, "MIN_OBJECT_SIZE");
  $row_min_object_size = $row_min_object_size['string'];
  $name_min_object_size = explode(" ", $row_min_object_size);
  $new_line_moz         = $name_min_object_size[0]." ".$value_min_object_size;
  $content = file_get_contents($file);
  	file_put_contents($file, str_replace($row_min_object_size, $new_line_moz, $content));

header("location: Raptor_Conf?accion=1");

} else {
header("location: Raptor_Conf?error=1");  
}

?>
