<?php 
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

session_start();

$n_eth = $_GET['num_eth'];
echo $n_eth."<br>";

function str_replace_limit($search, $replace, $string, $limit = 1) {
  if (is_bool($pos = (strpos($string, $search))))
    return $string;

  $search_len = strlen($search);

  for ($i = 0; $i < $limit; $i++) {
    $string = substr_replace($string, $replace, $pos, $search_len);

    if (is_bool($pos = (strpos($string, $search))))
      break;
  }
  return $string;
}

if(isset($_GET['num_eth'])){

	$file = "/etc/network/interfaces";
	$fileln = file($file);

	$hotplug = "address ".$n_eth;      
	$pos = 0;

	foreach($fileln as $linea){	        
		if (strstr($linea,$hotplug)){
			$row = $pos-2;	
			//echo $row."<br>";
			break;
		}
	   $pos++;
	}
	
	for ($i=1; $i <= 10; $i++) {
		$content = file_get_contents($file);
		$line1 = explode("\n", $content);
		$newline1 = "##-##";
		//echo $line1[($row+$i-1)]."<br>";
		$replace = str_replace_limit($line1[($row+$i-1)], $newline1, $content, 2);
		file_put_contents($file, $replace);	
	}

	$del_space = file_get_contents($file);
	$newline2 = "";
	file_put_contents($file, str_replace("##-##"."\n", $newline2, $del_space));	

	header("location: Network_Config");
	exit();
}

 ?>