<?php 

include_once '/usr/share/raptor/main/functions.php';

$file = "/etc/resolv.conf";
$content = file_get_contents($file);
$line_cache_dns = search_string($file, "127.0.0.1");

$dns_stat = $_POST['dns_cache_stat'];

if ($dns_stat == 0) {
	$new_line = "nameserver 127.0.0.1";
	file_put_contents($file, str_replace($line_cache_dns['string'], $new_line, $content));
	header('location:DNS_Config?accion=1');
}
if ($dns_stat == 1) {
	$new_line = "##-##nameserver 127.0.0.1";
	file_put_contents($file, str_replace($line_cache_dns['string'], $new_line, $content));	
	header('location:DNS_Config?accion=1');	
}


 ?>