<?PHP
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();

$file = "/etc/squid3/squid.conf";
$fileln = file($file);

$v_dns_nameservers1 = empty($_POST['dns_nameservers1']) ? "8.8.8.8" : $_POST['dns_nameservers1']; 
$v_dns_nameservers2 = empty($_POST['dns_nameservers2']) ? "8.8.4.4" : $_POST['dns_nameservers2'];
   
$v_cache_mem = $_POST['cache_mem'];

$pos = 0;

if (isset($_POST['dns_submit'])) {

	foreach ($fileln as $linea) {                
		if (strstr($linea, "dns_nameservers"))
		 $pos_dns_nameservers = $pos+1;		
		if (strstr($linea, "cache_mem"))
		 $row_cache_mem = $pos+1;   
		$pos++;
	}

	$content1 = file_get_contents($file);
	$list_content = explode("\n", $content1);

	$row_cache_mem = $list_content[($row_cache_mem-1)];
	$name_cache_mem = substr($row_cache_mem, 0, 9);
	$new_cache_mem = $name_cache_mem." ".$v_cache_mem." MB";
	if ($name_cache_mem == "cache_mem") {
		file_put_contents($file, str_replace($list_content[($row_cache_mem-1)], $new_cache_mem, $content1));
	}

	$row_dns_nameservers = $list_content[($pos_dns_nameservers-1)];
	$name_dns_nameservers = substr($row_dns_nameservers, 0, 15);
	$new_dns_nameservers = $name_dns_nameservers." ".$v_dns_nameservers1." ".$v_dns_nameservers2;
	if ($name_dns_nameservers == "dns_nameservers") {
		$content2 = file_get_contents($file);
		file_put_contents($file, str_replace($list_content[($pos_dns_nameservers-1)], $new_dns_nameservers, $content2));
	}

	header("location: Squid_Conf?accion=1");
	exit();
}

if (isset($_POST['acl_submit'])) {

		$acl_localnet = $_POST['acl_ln'];

		$pos = 0;
		foreach($fileln as $linea){	        
			if (strstr($linea, "acl localnet"))
			 $pos_new_line = $pos + 1;       
		    $pos++;
		}
		$content1 = file_get_contents($file);
		$row_regex   = explode("\n", $content1);
		$new_line_regex = $row_regex[($pos_new_line-1)]."\n"."acl localnet src ".$acl_localnet;
		
		file_put_contents($file, str_replace($row_regex[($pos_new_line-1)], $new_line_regex, $content1));

	header("location: Squid_Conf?accion=1");	
	exit();
}

if ( isset($_GET['delete_line']) ) {

	$ruleName = "acl localnet src ".$type_set_line;    
	$pos = 0;
	foreach ( $fileln as $linea ) {	        
		if ( strstr($linea, $ruleName) ){
			$row=$pos+1;        
		}
		$pos++;
	}

	$contenido = file_get_contents($file);
	$lineas    = explode("\n", $contenido);

	$newline2 = "";
	file_put_contents($file, str_replace($lineas[($row-1)]."\n", $newline2, $contenido));
	
	header("location: Squid_Conf?accion=1");
	exit();
}

header("location: Squid_Conf");

?>
