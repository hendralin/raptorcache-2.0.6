<?php 
/**
 *
 * @package Raptorcache
 * @since 1.4
 */

session_start();

if ( isset($_GET['change_state']) ) {
	$location = $_GET['location'];
	$file     = $_GET['file'];	
	$name     = $_GET['change_state'];
	$rule_name = "#name#".$name;    
	if (change_rule_state($file, $rule_name)) {
		header("location: $location");
	} else {
		header("location: $location?error=1");
	}
	return;
}

if ( $_GET['move'] == "up" || $_GET['move'] == "down" ) {
	$location    =  $_GET['location'];
	$file        =  $_GET['file'];
	$regexName   =  $_GET["regex_name"]; 
	if ($_GET['move'] == "up") {
		if (del_void_line($file)) {
			header("location: $location");
			return;
		}
		if (up_line($file, $regexName)) {
			header("location: $location");
		} else {
			header("location: $location?error=1");
		}
		return;
	}
	if ($_GET['move'] == "down") {
		if (del_void_line($file)) {
			header("location: $location");
			return;
		}
		if (down_line($file, $regexName)) {
			header("location: $location");
		} else {
			header("location: $location?error=1");
		}
		return;
	}	
}

if ( isset($_POST['new_regex']) ) {
	$location =  $_POST['location'];
	$file     =  $_POST['file'];
	$name     = ucfirst(trim($_POST['name']));
	$regex    = trim($_POST['nameregex']);

	$fileln    = file($file);

	if ($name == "" || $regex =="") {
		header("location: $location?error=1");
		return;
	}

	$pos_check_regex = "";
	$pos = 0;
	foreach ($fileln as $linea) {	        
		if (strstr($linea, $name)) {
			$pos_check_regex = $pos;   
		}
	    $pos++;
	}
	if ($pos_check_regex != "") {
		//Duplicated name
		$name = $name."_".$pos_check_regex;		
	}
	$fh         = fopen($file, 'a') or die("can't open file");
	$stringData = $regex." #name#".$name."\n";
	fwrite($fh, $stringData);
	fclose($fh);

	header("location: $location");
	return;
}

if ( isset($_POST['filter_rule']) ) {	
	$location =  $_POST['location'];
	$file     =  $_POST['file'];

	$fileln    = file($file);
	$name      = ucfirst(trim($_POST['name']));
	$chain     = trim($_POST['chain']);
	$src       = trim($_POST['src']);
	$action    = trim($_POST['action']);

	if ($name == "" || $src =="") {
		header("location: $location");
		exit();
	}
	$pos = 0;
	foreach ($fileln as $linea) {	        
		if (strstr($linea, $name)) {
			$pos_check_regex = $pos;   
		}
	    $pos++;
	}
	if ($pos_check_regex != "") {
		$content_check = file_get_contents($file);
		$row_ckeck   = explode("\n", $content_check);
		$check_line1 = $row_ckeck[($pos_check_regex)]."\n";
		$check_line2 = $row_ckeck[($pos_check_regex)-1]."\n";
		$check_line3 = $row_ckeck[($pos_check_regex)-2]."\n";

		$check_line1 = trim($check_line1);
		$check_line2 = trim($check_line2);
		$check_line3 = trim($check_line3);

		$check_name = explode("#name#", $check_line1);
		$check_name = trim($check_name[1]);

		$check_name2 = explode("#name#", $check_line2);
		$check_name2 = trim($check_name2[1]);

		$check_name3 = explode("#name#", $check_line3);
		$check_name3 = trim($check_name3[1]);		

		if ($name == $check_name || $name == $check_name2 || $name == $check_name3) {
			$name = $name."_".$pos_check_regex;
		}		
	}
	$fh         = fopen($file, 'a') or die("can't open file");
	$stringData = "iptables -A ".$chain." -s ".$src." -j ".$action." #name#".$name."\n";
	fwrite($fh, $stringData);
	fclose($fh);
	header("location: $location");
	return;
}

if ( isset($_POST['add_domain']) ) {
	$location =  $_POST['location'];
	$file     =  $_POST['file'];

	$fileln    = file($file);
	$name      = ucfirst(trim($_POST['name']));
	$domain    = trim($_POST['domain']);
	$domain1   = explode(".", $domain);
	$dom_name  = $domain1[0];
	$com       = $domain1[1];

	if ($name == "" || $domain =="") {
		header("location: $location");
		exit();
	}
	$pos = 0;
	foreach ($fileln as $linea) {	        
		if (strstr($linea, $name)) {
			$pos_check_regex = $pos;   
		}
	    $pos++;
	}
	if ($pos_check_regex != "") {
		$content_check = file_get_contents($file);
		$row_ckeck   = explode("\n", $content_check);
		$check_line1 = $row_ckeck[($pos_check_regex)]."\n";
		$check_line2 = $row_ckeck[($pos_check_regex)-1]."\n";
		$check_line3 = $row_ckeck[($pos_check_regex)-2]."\n";

		$check_line1 = trim($check_line1);
		$check_line2 = trim($check_line2);
		$check_line3 = trim($check_line3);

		$check_name = explode("#name#", $check_line1);
		$check_name = trim($check_name[1]);

		$check_name2 = explode("#name#", $check_line2);
		$check_name2 = trim($check_name2[1]);

		$check_name3 = explode("#name#", $check_line3);
		$check_name3 = trim($check_name3[1]);		

		if ($name == $check_name || $name == $check_name2 || $name == $check_name3) {
			$name = $name."_".$pos_check_regex;
		}		
	}
	$fh         = fopen($file, 'a') or die("can't open file");
	//$stringData = "iptables -A ".$chain." -s ".$src." -j ".$action." #name#".$name."\n";
	/*$stringData = "http.*({$dom_name}|\.{$dom_name})\.{$com}.* #name#".$name."\n";*/
	$stringData = "\.{$dom_name}\.{$com} #name#".$name."\n";
	fwrite($fh, $stringData);
	fclose($fh);
	header("location: $location");
	exit();
}

if ( isset($_GET['edit_regex']) ) {
	$location    = $_GET['location'];
	$file        = $_GET['file'];
	$rule        = $_GET["rule"]; 
	$idrule      = $_GET["idrule"];
	$regexName   = "#name#".ucfirst($_GET["namerule"]); 

	$fileln      = file($file);

	$content   = file_get_contents($file);
	$row_regex = explode("\n", $content);
	$new_rule  = trim($rule)." ".trim($regexName);
	if ($rule != "") {
		file_put_contents($file, str_replace($row_regex[($idrule)], $new_rule, $content));
	}
	
	header("location: $location");
	return;
}

if ( isset($_GET['delete_line']) ) {
	$location =  $_GET['location'];
	$file     =  $_GET['file'];
	$regex    =  $_GET["delete_line"]; 
	$rule    =  $_GET["rule"]; 

	$del_rule = $rule."#name#".$name_rule; 

	if ($file == "" || $regex == "") {
		header("location: $location?error=1");
		return;
	}

	if (del_rule_line($file, $del_rule)) {
		header("location: $location");
	} else {
		header("location: $location?error=1");
	}	
	return;
}

	
?>

