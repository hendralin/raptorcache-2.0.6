<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

session_start();

function ipcache($string_search, $ip_r, $last_string) {
	$file = "/etc/squid3/squid.conf";
	$fileln = file($file);	
	$pos = 0;
	foreach($fileln as $linea) { 
		if (strstr($linea, $string_search)){
		 $num_row = $pos + 1;        
		}
		$pos++;
	} 
	$content = file_get_contents($file);
	$arr_lines = explode("\n", $content);
	$line_string = $arr_lines[($num_row - 1)];
	$arr_first_str = explode(" ", $line_string);

	$first_str = $arr_first_str[0];

	$new_line = $first_str." ".$ip_r." ".$last_string; 
		
	file_put_contents($file, str_replace($arr_lines[($num_row - 1)], $new_line, $content));			
}

if ($_GET['ip_cache'] != "") {
	$ip_r = $_GET['ip_cache'];

	ipcache("cache_peer ", $ip_r, "parent 8080 0 proxy-only no-digest");
	ipcache("allow host", $ip_r, "allow host_lst");
	ipcache("allow ext", $ip_r, "allow exts");
	ipcache("deny head_html", $ip_r, "deny head_html");
	ipcache("deny wth_lst", $ip_r, "deny wth_lst");
	ipcache("allow raptor_lst", $ip_r, "allow raptor_lst");
	ipcache("allow sys_lst", $ip_r, "allow sys_lst");
	ipcache("cache_peer_access", $ip_r, "deny all");

	header("location: Network_Config?accion=1");		
} else {
	header("location: Network_Config?error=1");	
}


?>


