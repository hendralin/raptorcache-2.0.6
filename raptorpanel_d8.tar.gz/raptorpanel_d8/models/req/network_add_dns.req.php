<?php 
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

session_start();

$dns_search = "search raptor.os";

if ($_POST['dns1'] == "127.0.0.1") {
	$dns1 = "##-##nameserver 127.0.0.1";
} else {
	$dns1 = "nameserver 127.0.0.1";	
}

$dns2 = "nameserver ".$_POST['dns2'];
$dns3 = "nameserver ".$_POST['dns3'];

$nb = "";

$file = fopen("/etc/resolv.conf", "w");

fwrite($file, $dns_search . PHP_EOL);
fwrite($file, $dns1 . PHP_EOL);
fwrite($file, $dns2 . PHP_EOL);
fwrite($file, $dns3 . PHP_EOL);
fwrite($file, $nb . PHP_EOL);

fclose($file);

header('location:DNS_Config?accion=1');

 ?>