<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
session_start();
require_once "main/functions.php";

$ip_mk = 0;
$user_mk = $pass_mk  = "";

require "class/Database.php";
require "models/Router.php";

$db = Database::getInstance();
//$db->getConnection();
$rb = new Router($db);


	if (isset($_POST["add_user_mk"])) {
		$ipAdd   = $_POST['ip_mk_list'];
		$userAdd = $_POST['user_mk_list'];
		if ( $rb->setUserList($ipAdd, $userAdd) ) {
			header("location: Mikrotik_List");
		} else {
			header("location: Mikrotik_List?error=1");
		}
	} 

	if (isset($_GET["rm_id"])) {		
		$rm_id = $_GET["rm_id"];
		if ( $rb->delUserList($rm_id) ) {
			header("location: Mikrotik_List");
		} else {
			header("location: Mikrotik_List?error=1");
		}
	} 

$db->disconnectDB();

header("location: Mikrotik_List?error=1");
 ?>