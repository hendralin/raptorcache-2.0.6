<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
session_start(); 
require 'class/Database.php';
require 'class/Sanitize.php';
require 'models/User.php';

$db = Database::getInstance();
$db->getConnection();

$objUser = new User($db);

if ( isset($_POST['new_user_form']) ) {
	$user    = $_POST['userName'];	
	$pass    = md5($_POST['pass']);	
	$profile = $_POST['perfil'];
	$mail    = $_POST['mail'];

	$sql  = "INSERT INTO user(loginUser, passUser, idprofile, emailUser) VALUES('".$user."', '".$pass."','".$profile."','".$mail."')";
	$stat = $db->execute($sql);
	if (!$stat) {
		echo "<script>window.location='Users_Config?add=no';</script>";
	}

	$db->disconnectDB();;
	echo "<script>window.location='Users_Config?accion=1';</script>";
	exit();	
}

if ( isset($_POST['change_user_form']) ) {
	$user    = $_POST['user'];
	$oldpass = $_POST['oldpass'];
	$newPass = md5($_POST['newpass']);

	//print_r($_POST['user'])."<br>";

	//$sql = "SELECT loginUser FROM user WHERE loginUser = '".$user."' ";
	$sql = "SELECT * FROM user, user_profile WHERE user.loginUser = '".$user."' AND user.passUser = '".md5($oldpass)."' ";
	$usr   = $db->execute($sql);

	if ( mysqli_num_rows($usr) > 0 ) {
		$sql = "UPDATE user SET passUser='".$newPass."' WHERE loginUser='".$user."'";
		$db->execute($sql);
		$db->disconnectDB();	
		echo "<script>window.location='Users_Config?accion=1';</script>";
	} else {
		echo "<script>window.location='Users_Config?changePass=no';</script>";	
	}	
	return;
}

if ( isset($_GET['idUser']) ) {
	$idDel = $_GET['idUser'];
	$sql   = "DELETE FROM user WHERE idUser='".$idDel."'";
	$db->execute($sql);
	$db->disconnectDB();
	echo "<script>window.location='Users_Config?accion=1';</script>";
	exit();
}

 ?>