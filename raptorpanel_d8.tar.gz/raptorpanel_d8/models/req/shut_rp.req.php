<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
session_start();
if (isset($_POST)) {
	exec("sudo bash /etc/raptor/run.v/shut_rp.sh");
    echo "<div>Raptor</div>";     
}	
 ?>