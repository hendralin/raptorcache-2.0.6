<?php 

class Cron
{
	private $file = "/etc/crontab";
	private $stat_shutdown;
	private $hour_shutdown;
	private $minute_shutdown;

	public function get_value_clean()
	{
		$line_clean = search_string($this->file, "clean ");
		$v_clean = explode("clean", $line_clean['string']);
		$v_clean = trim($v_clean[1]);
		return $v_clean;
	}

	public function get_values_shutdown()
	{
		$line_shutdown = search_string($this->file, "shutdown -h");
		$line_shutdown = $line_shutdown['string'];
		if (substr($line_shutdown, 0, 1) == "#") {
			$this->stat_shutdown = false;
		} else {
			$this->stat_shutdown = true;
		}
		$line_shutdown = explode(" ", $line_shutdown);
		$this->hour_shutdown = $line_shutdown[0];
		$this->minute_shutdown = $line_shutdown[1];
	}	

	public function __call($name, $arguments)
	{
		$no_method = true;

		$method_name = substr($name, 0, 3);

		if ($method_name == 'get') {
			$no_method = false;
			$real_name = substr(strtolower($name), 4);
			return $this->$real_name;
		}

		if ($no_method) {
			throw Exception("Method {$name} no found");			
		}

	}	
	
}

 ?>