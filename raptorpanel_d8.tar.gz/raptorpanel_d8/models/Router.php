<?php 

class Router 
{
	public $objDb;
	private $address_mk = 0;
	private $user_mk = "";
	private $pass_mk  = "";
	public $API;

	public function __construct($db)
	{		
		$this->objDb = $db;	
	}

	public function checkApiCon($address_mk, $user_mk, $pass_mk)
	{
		require_once "inc/routeros_api.class.php";
		$this->API = new routeros_api();
		if ( $this->API->connect($address_mk, $user_mk, $pass_mk) ) {
			return true;
		} else {
			return false;
		}
	}

	public function getRouterValuesDB()
	{
		$sql = "SELECT * FROM user_mk";
		$query = $this->objDb->execute($sql);

		if ( mysqli_num_rows($query) > 0 ) {
			foreach ( $query as $row ) {
				$this->address_mk = $row['ip_mk'];
				$this->user_mk = $row['user_mk'];
				$this->pass_mk = $row['pass_mk'];
			}		
			return array($this->address_mk, $this->user_mk, $this->pass_mk);
		} 
	}

	public function conApiRouter()
	{
		if ( count($this->getRouterValuesDB()) > 0 ) {
			$this->pass_mk = de_str($this->pass_mk);
			require_once "inc/routeros_api.class.php";
			$this->API = new routeros_api();
			$this->API->debug = false;
			if ($this->address_mk == "0.0.0.0") {				
				return;
			}
			if ( $this->API->connect($this->address_mk, $this->user_mk, $this->pass_mk) ) {
				return true;
			} else {
				return false;
			}			
		} else {
			return false;
		}		
	}

	public function setUserList($address, $name)
	{
		if ( $this->conApiRouter() ) {
		   $this->API->comm("/ip/firewall/address-list/add", array(
		      "disabled" => "no",
		      "list" => "https_users",
		      "address" => "$address",
		      "comment" => "$name",
		      ));		         
		   $this->API->disconnect();
		} 
	}

	public function delUserList($remove_id)
	{
		if ( $this->conApiRouter() ) {
			$this->API->write('/ip/firewall/address-list/remove
				=.id='.$remove_id);		               
			$READ = $this->API->read(false);
			$ARRAY = $this->API->parse_response($READ);			         
		   $this->API->disconnect();
		} 
	}	

	public function showListUsers()
	{
		echo "
		<table class='sortable' cellspacing='0' style='border-radius:0 0 3px 3px;'>
		<tr>
		<th>Usuario</th>
		<th>IP</th>
		<th style='border-right:none;'>&nbsp;</th>
		</tr>";		
		if ( $this->conApiRouter() ) {
		$ARRAY = $this->API->comm('/ip/firewall/address-list/print
		    ?list=https_users       
		');
		$connect_mk = "<span class='enabled_pl' style='text-shadow:none;'>ON</span>";
		$count = count($ARRAY);    
		echo "
		<tr style='background:#fff;'>
		<td style='padding:0;'>";
		for ($i=0; $i<$count; $i++)	{
		$regtable = $ARRAY[$i];
			echo "<p style='border-bottom:1px solid #ddd;margin:0;padding:4px;'>".$regtable['comment'] . "</p>";
		}		
		echo "
		</td>
		<td style='padding:0;'>";
		for ($i=0; $i<$count; $i++)	{
		$regtable = $ARRAY[$i];	
			echo "<p style='border-bottom:1px solid #ddd;margin:0;padding:4px;'>".$regtable['address'] . "</p>";
		}		
		echo "
		</td>
		<td style='padding:0;'>";
		for ($i=0; $i<$count; $i++) {
		$regtable = $ARRAY[$i]; 
		echo "<p style='border-bottom:1px solid #ddd;margin:0;padding:4px;'><a class='del_regx' href=\"mk_u_list_arm.req?rm_id={$regtable['.id']}\">X</a></p>";
		}   
		echo "
		</td>
		</tr>
		</table>";		
		} else {
			echo "<tr><td colspan='3'></td></tr></table>";
		}	
	}
	
}

 ?>