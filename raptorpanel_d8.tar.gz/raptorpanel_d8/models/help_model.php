<?php

class Help_Model extends Model {

	function __construct() {
		echo 'Help model';
	}

}