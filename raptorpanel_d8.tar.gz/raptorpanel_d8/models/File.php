<?php 

class File
{
	public $route;
	public $content;

	public function __construct($route) {
		$this->route = $route;
	}

	public function getFileLocation() {
		$location_url = explode("/", $_SERVER['REQUEST_URI']);
		$location_url = end($location_url);
		return $location_url;
	}	

	public function getContent() {
		$this->content = $this->route;
		$this->content = file_get_contents($this->content);
		$this->content = explode("\n", $this->content);
		return $this->content; // array content
	}
}

 ?>