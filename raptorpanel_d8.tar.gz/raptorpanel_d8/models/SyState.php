<?php 

class SyState
{
	public function stat_cache($port) 
	{
		$iprp = "localhost";
		$nic = "";
		$nic = fsockopen($iprp, $portr, $errno, $errstr, 2);
    	if ($nic) {
      		return "<span style=\"color:rgb(252, 69, 69);\">Offline</span>";
    		fclose($nic);      		
    	} else {
      		return "<span style=\"color:#5daf48\">Activo</span>";          
    	}
	}

	public function version_rp()
	{
		$vrp = exec("sudo /usr/sbin/raptor | grep 'Raptor' | awk '{print $6}' | head -1");
		return "<span style='color:#2ec2d0'>v.".$vrp."b</span>";
	}

	public function version_sq()
	{
		$vsq = "";
		$vsq = exec("/usr/sbin/squid3 -v | awk '{print $4}' | head -1");
		if (!$vsq) 
		$vsq = exec("/usr/sbin/squid -v | awk '{print $4}' | head -1");  
		return "<span style='color:#2ec2d0'>v.".$vsq."</>";
	}	

	public function cnx_us() 
	{
		$cnx = 0;	
		$cnx = exec("netstat -ntu | grep -e'8080' -e'3128'| wc -l");
		if (!$cnx) {
			$cnx = 0;
		}
		return $cnx;
	}	

	public function open_threads_netstat() 
	{
		$cnx = "";
		$cnx = exec("netstat -ntu | grep -e '8080' | grep -v '127.0.0.1' | wc -l");
		if (!$cnx) {
			$cnx = 0;
		}
		$cnx = round($cnx,0);
		return $cnx;
	}	

	public function num_us() 
	{
		$num_us = "";
		$num_us = exec("netstat -plan|grep :3128 | awk {'print $5'} | cut -d: -f 1 | sort | uniq -c | sort -n | grep -v 0.0.0.0 | grep -v 127.0.0.1 | wc -l");
		return $num_us;
	}

	public function cnx_dns() 
	{
		$cnx_dns = "";
		$cnx_dns = exec("less \/var\/cache\/bind\/named_dump.db | grep -v ';' | grep -v 'DATE' | sort | uniq -c | wc -l");
		if ($cnx_dns < 5) 
		$cnx_dns = "<span style='color:#777'>Disabled</span>";
		return $cnx_dns;
	}

	public function format_time($seconds, $mins, $hours, $days) 
	{  
		$mins  = intval($seconds / 60 % 60);
		$hours = intval($seconds / 3600 % 24);
		$days  = intval($seconds / 86400);
		if ($days > 0) {
			$uptimeString .= $days;
			$uptimeString .= (($days == 1) ? "d" : "d");
		}
		if ($hours > 0) {
			$uptimeString .= (($days > 0) ? " " : "") . $hours;
			$uptimeString .= ((hours == 1) ? "h" : "h");
		}
		if ($mins > 0) {
			$uptimeString .= (($days > 0 || $hours > 0) ? " " : "") . $mins;
			$uptimeString .= (($mins == 1) ? "m" : "m");
		}
		if ($secs > 0) {
			$uptimeString .= (($days > 0 || $hours > 0 || $mins > 0) ? " " : "") . $secs;
			$uptimeString .= (($secs == 1) ? "s" : "s");
		}
		return $uptimeString;
	}
	public function uptime() 
	{
		$uptime	= $uptimeSecs = $staticUptime = "";
		$uptime = exec("cat /proc/uptime");
		$uptime = split(" ",$uptime);
		$uptimeSecs = $uptime[0];
		$staticUptime = $this->format_time($uptimeSecs);
		return $staticUptime;
	}	
	
	public function cpu_temp() 
	{
		$ln = "";
	    $ln = exec("sensors | grep \"CPU Temperature\" >/dev/null 2>&1");
	    if (trim($ln) == "")
	      $ln = exec("sensors | grep \"temp1\"");
	    if (trim($ln) != "") {
	      $tp = explode(" ", $ln);
	      for ($i=0; $i<sizeof($tp); $i++) {
	        if (strpos($tp[$i], "+") !== false) {
	          $cp = str_replace("+", "", $tp[$i]);
	          break;
	        }
	      }
	    }
	    if (trim($cp) == "")
	      $cp = exec("sensors | grep \"Core \" | awk '{ T += \$3 } { C += 1 } END { print T/C } '");
	    $cp = (int)$cp;
	    if (trim($cp) == 0) {
	      $temp = "<span style='color:#777'>No Support</span>";
	    }
	    else if (trim($cp) == "") {
	      $temp = "<span style='color:#777'>No Support</span>";
	    }
	    else {
	       $temp = substr($cp,0,2)." &deg;C";
	    }
	    return $temp;
	}

	public function io_cpu() 
	{
		$iostat_cpu = "";
		$iostat_cpu = exec("iostat -c 1 2 | grep -v 'Linux' | sed '/[0-9]/!d' | tail -1");
		$iostat_cpu = ltrim($iostat_cpu);
		while (strpos($iostat_cpu, "  ") > 0 ) 
		$iostat_cpu = str_replace("  ", " ", $iostat_cpu);
		$iostat_cpu = explode(" ", ltrim($iostat_cpu));  
		$io_cpu = $iostat_cpu[3];
		return $io_cpu;
	} 

	public function system_load() 
	{
		$sl = $cpu = "";
		$sl = exec("cat /proc/loadavg | awk '{ print \$1\" \"\$2\" \"\$3\"\" }'");
		$sl = explode(" ", $sl);
		$cpu = exec("cat /proc/cpuinfo | grep \"model name\" | wc -l");
		$pc = array(round(($sl[0]/$cpu)*100, 0),round(($sl[1]/$cpu)*100, 0),round(($sl[2]/$cpu)*100, 0));
		if ($pc[0] > 100) $pc[0] = 100;
		if ($pc[1] > 100) $pc[1] = 100;
		if ($pc[2] > 100) $pc[2] = 100;
		if ($pc[0] < 50)
		$r = "<span class='loadGreen'>".$sl[0]." (".$pc[0]."%)</span>";
		else if ($pc[0] < 80)
		$r = "&nbsp;&nbsp;<span class='loadOrange'>".$sl[0]." (".$pc[0]."%)</span>";
		else
		$r = "&nbsp;&nbsp;<span class='loadRed'>".$sl[0]." (".$pc[0]."%)</span>";
		if ($pc[1] < 50)
		$r .= "&nbsp;&nbsp;<span class='loadGreen'>".$sl[1]." (".$pc[1]."%)</span>";
		else if ($pc[1] < 80)
		$r .= "&nbsp;&nbsp;<span class='loadOrange'>".$sl[1]." (".$pc[1]."%)</span>";
		else
		$r .= "&nbsp;&nbsp;<span class='loadRed'>".$sl[1]." (".$pc[1]."%)</span>";
		if ($pc[2] < 50)
		$r .= "&nbsp;&nbsp;<span class='loadGreen'>".$sl[2]." (".$pc[2]."%)</span>";
		else if ($pc[2] < 80)
		$r .= "&nbsp;&nbsp;<span class='loadOrange'>".$sl[2]." (".$pc[2]."%)</span>";
		else
		$r .= "&nbsp;&nbsp;<span class='loadRed'>".$sl[2]." (".$pc[2]."%)</span";
		return $r;
	}

	public function cpu_bar() 
	{
		exec('ps aux', $processes);
		foreach($processes as $process) {
			$cols = split(' ', ereg_replace(' +', ' ', $process));
			if (strpos($cols[2], '.') > -1) {
			  $cpuBar += floatval($cols[2]);
			}        
		}
		if ($cpuBar < 100) {
			if ($cpuBar <= 10) {
			  $usage = "<span style=\"color:#555555\">".$cpuBar."%</span>";
			}
			else if ($cpuBar > 10 || $cpuBar < 99) {
			  $usage = "<span style=\"color:#dbeaf9\">".$cpuBar."%</span>";
			} else {
			  $usage = 99;
			}  
			return array($cpuBar, $usage);
		} else {
			return array(0, 0);    
		}
	}


}


 ?>