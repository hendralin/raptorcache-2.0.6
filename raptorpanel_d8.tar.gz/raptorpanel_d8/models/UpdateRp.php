<?php 

class UpdateRp extends FileRp
{

	public $update_core;
	public $update_panel;
	public $update_services;

	public function get_host_conection() 
	{
	    $errno = "";
	    $errstr = "";
	    $connected = fsockopen('www.alterserv.com', 80, $errno, $errstr, 2);		
		if ($connected) { 
			$run_up_check = shell_exec("sudo bash /etc/raptor/run.v/up_check.sh"); 
			return true;
		} else {
			return false;
		}
	}

	public function get_file_info($line_string) 
	{
		$file_info = "/etc/raptor/up.v/info.txt";
		$file_info_ln = file($file_info);
		$pos = 0;
		foreach($file_info_ln as $linea) {         
			if (strstr($linea, $line_string))
			  $num_line = $pos+1;    
			$pos++;
		}
		$content      = file_get_contents($file_info);
		$line_version = explode("\n", $content);
		$line_version = $line_version[($num_line-1)];
		$v_version    = explode(" ",$line_version);
		$version_rp   = trim($v_version[1]);
		$version      =  de_str($version_rp);
		return $version;
	}

	public function get_core_up_v()
	{
		$cloud_core = $this->get_file_info("core-version");	
		return $cloud_core;
	}

	public function get_panel_up_v()
	{
		$cloud_panel = $this->get_file_info("panel-version");	
		return $cloud_panel;
	}

	public function get_services_up_v()
	{
		$cloud_services = $this->get_file_info("services");	
		return $cloud_services;
	}		

	public function get_core_local_v()
	{
		$v_raptor = 0;
		$v_raptor = trim($this->get_core_version());
		$quit     = array('b', 'v', '.');
		$local_raptor_v = str_replace($quit, "", $v_raptor);
		$local_raptor_v = strip_tags($local_raptor_v);	
		return $local_raptor_v;
	}	

	public function get_panel_local_v()
	{
		$vp    = $this->get_panel_version();
		$vp    = str_replace(".", "", $vp);
		return $vp;
	}

	public function get_services_local_v()
	{
		$v_services       = $this->get_services_version();
		$local_services_v = str_replace(".", "", $v_services);	
		return $local_services_v;
	}

	public function show_alert_update()
	{
		$str_update    ="Actualizaci&oacute;n";
  		$str_available ="Disponible";
		$lic = $this->get_lic_name_raptor();
		$cloud_core = str_replace(".", "", $this->get_core_up_v());
		$cloud_panel = str_replace(".", "", $this->get_panel_up_v());
		$cloud_services = str_replace(".", "", $this->get_services_up_v());

		if ( ($cloud_core <= $this->get_core_local_v()) && ($cloud_panel <= $this->get_panel_local_v()) && ($cloud_services <= $this->get_services_local_v()) ) {
			$this->update_core  = false;
			$this->update_panel = false;	
			$this->update_services  = false;
			$case_update = "<div id='case_green' class='update_box'>Update OK.</div>";	
		}
		else if ( ($cloud_core > $this->get_core_local_v()) && ($cloud_panel > $this->get_panel_local_v()) && ($cloud_services > $this->get_services_local_v()) ) {
			if ($lic == "Free") {
				$this->update_core  = true;		
			} else {
				$this->update_core  = false;
			}	
			$this->update_panel = true;	
			$this->update_services  = true;
			$case_update = "<div id='case_blue'>{$str_update} Core , Panel & Services {$str_available}</div>";	
		}
		else if ( ($cloud_core > $this->get_core_local_v()) && ($cloud_panel > $this->get_panel_local_v()) ) {
			if ($lic == "Free") {
				$this->update_core  = true;		
			} else {
				$this->update_core  = false;
			}	
			$this->update_panel = true;	
			$case_update = "<div id='case_blue'>{$str_update} Core & Panel {$str_available}</div>";	
		}
		else if ( ($cloud_core > $this->get_core_local_v()) && ($cloud_services > $this->get_services_local_v()) ) {
			$this->update_core  = true;	
			if ($lic == "Free") {
				$this->update_core  = true;		
			} else {
				$this->update_core  = false;
			}		
			$this->update_services = true;	
			$case_update = "<div id='case_blue'>{$str_update} Core & Services {$str_available}</div>";	
		}
		else if ($cloud_core > $this->get_core_local_v()) {
			if ($lic == "Free") {
				$this->update_core  = true;		
			} else {
				$this->update_core  = false;
			}	
			$case_update = "<div id='case_blue'>{$str_update} Core {$str_available}</div>";	
		}
		else if ($cloud_panel > $this->get_panel_local_v()) {
			$this->update_panel = true;	
			$case_update = "<div id='case_blue'>{$str_update} WebPanel {$str_available}</div>";	
		}
		else if ($cloud_services > $this->get_services_local_v()) {
			$this->update_services  = true;		
			$case_update = "<div id='case_blue'>{$str_update} Services {$str_available}</div>";		
		} 		
		return $case_update;
	}

	public function update_status()
	{
		$this->show_alert_update();
		if ($this->update_core  == true || $this->update_panel == true || $this->_services == true) {
			return true;
		} else {
			return false;
		}		
	}


}


 ?>