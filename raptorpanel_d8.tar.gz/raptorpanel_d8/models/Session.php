<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

class Session
{
	
	public function __construct(){ }
	
	public function init()
	{
		@session_start();
	}
	
	public function set($varname, $value)
	{
		
		$_SESSION[$varname] = $value;
		
	}
	
	public function destroy()
	{
		
		session_unset();
		session_destroy();
		
	}
	
}

?>