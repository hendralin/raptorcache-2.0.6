<?php 

class FileRp extends File
{
	private $rule;
	private $rule_name;
	private $rule_state;

	public function showRules() 
	{		
		$arrline = $this->getContent();
		echo "<table class='sortable' cellspacing='0' style='border-radius:0 0 3px 3px;text-align:left;'>"; 
	    echo "<tr>";
	    echo "<th>&nbsp;</th>";
	    echo "<th>Name</th>";
	    echo "<th>Rule</th>";
	    echo "<th style='border-right:none;'></th>";
	    echo "<th style='border-right:none;'></th>";
	    echo "<th style='border-right:none;'></th>";
	    echo "<th style='border-right:none;padding: 2px 4px;'></th>";
	    echo "</tr>";
			for ($i=0; $i < count($arrline); $i++) { 
				$line = explode("#name",$arrline[$i]);
				$this->rule = $line[0];
				
				if (isset($this->rule)) {
					$line = preg_replace("[\n|\r|\n\r]", ' ', $line[1]);		
					if ($line != "") {				
						$this->rule_name = explode("#", $line);	
						$this->rule_name = $this->rule_name[1];		        

						$this->rule_state = substr($arrline[$i], 0, 5);
						if ($this->rule_state == "##-##") {
							$this->rule_state = "OFF";
							$this->rule = explode("-##", $this->rule);
							$this->rule = $this->rule[1];
							echo "<tr class='row'>";
							echo "<td style='color:#AAA;width:40px;'>".$this->state_rule($this->rule_name, $this->rule_state)."</td>";
							echo "<td style='color:#AAA;text-align:left;'>".$this->rule_name."</td>";
							echo "<td style='color:#AAA;text-align:left;width:700px;'>".$this->rule."</td>";	
							echo "<td style='padding-right:0'>".$this->move_up_rule($this->rule_name)."</td>";
							echo "<td style='padding-right:0'>".$this->move_down_rule($this->rule_name)."</td>";
							echo "<td style='padding-right:0'>".$this->edit_rule($i)."</td>";
							echo "<td style='color:#AAA;padding: 2px 4px;'>".$this->delete_rule($this->rule_name, $this->rule)."</td>";
							echo "</tr>";				
						} else {
							$this->rule_state = "ON";
							echo "<tr class='row'>";
							echo "<td style='width:40px;'>".$this->state_rule($this->rule_name, $this->rule_state)."</td>";
							echo "<td style='text-align:left;'>".$this->rule_name."</td>";
							echo "<td style='text-align:left;width:700px;'>".$this->rule."</td>";			
							echo "<td style='padding-right:0'>".$this->move_up_rule($this->rule_name)."</td>";
							echo "<td style='padding-right:0'>".$this->move_down_rule($this->rule_name)."</td>";					
							echo "<td style='padding-right:0'>".$this->edit_rule($i)."</td>";					
							echo "<td style='padding: 2px 4px;'>".$this->delete_rule($this->rule_name, $this->rule)."</td>";
							echo "</tr>";				
						}
					}
				}
			}
		echo "</table>";
	} 

	private function state_rule($rule_name, $rule_state)
	{
		if ($rule_state == "ON") {
			return "<a class='enabled_pl' href='mod_lst.req?change_state={$rule_name}&location={$this->getFileLocation()}&file={$this->route}'>ON</a>";
		} else {
			return "<a class='disabled_pl' href='mod_lst.req?change_state={$rule_name}&location={$this->getFileLocation()}&file={$this->route}'>OFF</a>";
		}	
	}

	private function move_up_rule($rule_name)
	{
		return "<a class='arrow_up' href='mod_lst.req?regex_name={$rule_name}&move=up&location={$this->getFileLocation()}&file={$this->route}' ><span class='icon-caret-up'></span></a>";
	}

	private function move_down_rule($rule_name)
	{
		return "<a class='arrow_down' href='mod_lst.req?regex_name={$rule_name}&move=down&location={$this->getFileLocation()}&file={$this->route}' ><span class='icon-caret-down'></span></a>";
	}	

	private function edit_rule($i)
	{
		return "<a class='editRule' onclick='window.dat=".$i."'><span class='icon-pencil-square-o'></span></a>";
	}    	

	private function delete_rule($rule_name, $rule)
	{
		return "<a class='del_regx' href='mod_lst.req?delete_line={$rule_name}&rule={$rule}&location={$this->getFileLocation()}&file={$this->route}'>X</a>";
	}  

	public function get_core_version() {
		$vrp = exec("sudo /usr/sbin/raptor | grep 'Raptor' | awk '{print $6}' | head -1");
		return $vrp."b";
	}

	public function get_panel_version()
	{
		$vp    = search_string("/usr/share/raptor/main/settings.php", "verwp");
		$vp    = explode("=", $vp['string']);
		$vp    = $vp[1];
		$quit  = array('"');
		$vp    = str_replace($quit, "", $vp);
		return trim($vp);
	}

	public function get_services_version() {
		$vsvc = exec("sudo /usr/bin/clean -v");
		if ($vsvc == "") {
			$vsvc = 0;
		}
		return trim($vsvc);
	}

	public function get_lic_name_raptor() 
	{
		$nlic_rp = exec("sudo /usr/sbin/raptor | grep 'Licence:' | cut -d: -f2");
		if ($nlic_rp != "") {
			$lic = $nlic_rp;
		} else {
			$lic = "Free";
		}
		return trim($lic);
	}

	public function get_lic_key_raptor() 
	{
		$nkey_rp = exec("sudo /usr/sbin/raptor | grep 'Key:' | cut -d: -f2");
		if ($nkey_rp != "") {
			$key = $nkey_rp;
		} else {
			$key = "Uknow";
		}
		return trim($key);
	}	

}	

 ?>