<?php

Class HardDisk 
{
	private $count_disk;
	private $list_dev_disk;

	public $arr_dev_disk;

	public function __construct() {
		$name_grep_disk      = exec("sudo fdisk -l | grep /dev/ | grep bytes | head -n1 | awk {'print $1'}");
		$this->count_disk    = shell_exec("sudo fdisk -l | grep ".$name_grep_disk." | grep bytes | grep -Ee '/dev/sd[a-z]' | grep -v '/dev/dm-0' | grep -v '/dev/mapper/' | wc -l");
		$this->list_dev_disk = shell_exec("sudo fdisk -l /dev/sd? | grep ".$name_grep_disk." | grep bytes | awk '{print $2}' | sed -e 's/://g'");
		$this->arr_dev_disk  = explode("\n", $this->list_dev_disk);		
	}

	public function getCountDisk() {
		return $this->count_disk;
	}

	public function getIostat($sda) {   
        $iostat = exec("iostat -x -d -k 1 2 {$sda} | tail -2 | grep \"{$sda}\"");
        while (strpos($iostat, "  ") > 0 )
          $iostat = str_replace("  ", " ", $iostat);

        $iostat = explode(" ",$iostat);
      	$iw = number_format($iostat[9], 1, ".", "");
      	if ($iw > 100) 
      		$iw = 100;
    	if ($iostat != "") {
	      	$io = array($iostat[3] , $iostat[5], $iostat[4], $iostat[6], $iw);
    	} 
    	return $io;			
	}

	public function getTempHd($sda) {
			(int)$temp = shell_exec("cat /dev/shm/".trim($sda)."-A | grep Temperature | grep Temperature_Celsius | awk '{print $10}'");
			if ($temp != "") {
				$temp = substr($temp,0,2);				
				if ($temp <= 40) {
			    	$temp = "<span style='color:green'>".$temp." &deg;C</span>";
				}
				else if ($temp > 40 && $temp <= 60) {
			    	$temp = "<span style='color:orange'>".$temp." &deg;C</span>";
				} 
				else if ($temp > 60) {
			    	$temp = "<span style='color:red'>".$temp." &deg;C</span>";
				}
			} else {
			  $temp = "<span style='color:#777'>No support</span>";
			}		
			return $temp;
	}

	public function getLatencyHd($sdx) {
			$t_sdx = "/dev/".$sdx;
			$iop = shell_exec("sudo ioping -c 1 -s 1k ".trim($t_sdx)." | grep time");
			$iop = explode("time=", $iop);
			$l_ioping = $iop[1];
			return $l_ioping;
	}

	public function getSpaceHd($sdx) {
		$disk_space = shell_exec("df -h | grep ".$sdx." |  sed 's/ /\\n/g' | grep -Ee '[a-zA-Z0-9]' ");
		$sd = explode("\n", $disk_space);
		return $sd;
	}

	public function getListDevDisk() {
		return $this->list_dev_disk;
	}

	public function getSmartool($sdx) {
		$t_sdx = "";
		$t_sdx = "/dev/".$sdx;
		shell_exec("sudo smartctl -i ".trim($t_sdx)." > /dev/shm/".$sdx."-i");
		shell_exec("sudo smartctl -A ".trim($t_sdx)." > /dev/shm/".$sdx."-A");

		$file = "/dev/shm/".trim($sdx)."-i";
		$model = getValueHd($file, "Model Family:", ":");
		$device = getValueHd($file, "Device Model:", ":");
		$smart = getValueHd($file, "SMART support is:", ":");
			$smart = trim($smart[1]);
			if ($smart == "Enabled") {
				$smart='<span style="color:green">Enabled</span>';
			}else{
			    $smart='<span style="color:#fb4949">Disabled</span>';
			}

		$capacity_all = getValueHd($file, "User Capacity:", ":");
		$capacity = explode("bytes",$capacity_all[1]);
		$hdsmd = str_replace(',', '', $capacity[0]);
		$hdsmd = sizeFormat($hdsmd);		

		$file_a = "/dev/shm/".trim($sdx)."-A";
		$power_on = getValueHd($file_a, "Power_On_Hours", " ");
		$uncorrectable = getValueHd($file_a, "Offline_Uncorrectable", " ");
		$reallocated = getValueHd($file_a, "Reallocated_Sector_Ct", " ");
		$seek_error = getValueHd($file_a, "Seek_Error_Rate", " ");

		$smartool = array($model[1], $device[1], $hdsmd, $smart, $power_on, $uncorrectable, $reallocated, $seek_error);
		return $smartool;		
	}

	public function getMountHd($sdx) {
		$sd[0] = $sd[1] = $sd[2] = $sd[3] = $sd[4] = $sd[5] = "";
		//$disk_space = shell_exec("df -h | grep ".$sdx." |  sed 's/ /\\n/g' | grep -Ee '[a-zA-Z0-9]' ");//check this line sda
		$disk_space = shell_exec("df -h | grep ".$sdx." |  sed 's/ /\\n/g' | grep -Ee '[a-zA-Z0-9]' ");//check this line sda

		if ($this->count_disk >= 1) {
			$hd_sys1 = exec("sudo blkid | grep 'swap' | awk '{print $1}' | sed 's/[0-9:]//g'");
			$hd_sys2 = exec("sudo df -h | grep -w '/' | awk '{print $1}' |  sed 's/[0-9:]//g' | grep -v 'dev/disk'");
			//$no_mount = exec("ls /dev/sd* | sed '/[0-9]/d' | grep -v ".$hd_sys."");
			//if (trim($dev_disk[$i]) == trim($no_mount)) {
			$dev_disk = "/dev/".$sdx;
			if (trim($dev_disk) == trim($hd_sys1) || trim($dev_disk) == trim($hd_sys2)) {
				//$disk_space = exec("df -h | grep rootfs"); // deprecated Deb7
				//$disk_space = exec("df -h | grep -w '/' | grep -v 'dev/disk'"); 
				$sd = explode("\n", $disk_space);
				$cache_num = "System";
			} else {
				if ($disk_space == "") { 
					$cache_num = "No Mount";
				} else {
					$sd = explode("\n", $disk_space);
					$cache_num = explode("/usr/local/raptor/", $sd[5]);
					$cache_num = $cache_num[1];    
				}		
				//$sd[1] = $sd[2] = $sd[3] = $sd[4] = $sd[5] = "-";
			}  
		} 		
		return $cache_num;
	}

	public function getUuid($sdx) {
		$dev_disk = "/dev/".$sdx;
		$uuid = exec("sudo blkid ".trim($dev_disk)." | awk '{print $2}' | tr -d '\"'");
		if ($uuid == "") $uuid = exec("sudo blkid | grep ".trim($dev_disk)." | grep -v 'swap' | awk '{print $2}' | tr -d '\"'");
		return $uuid;
	}

}

