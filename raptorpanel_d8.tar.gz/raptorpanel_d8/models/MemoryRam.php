<?php 

class MemoryRam {

	private $output;

	public function getValuesRam() 
	{
		exec("free -m", $this->output);
	    $str = trim($this->output[1]);
	    $str = preg_replace("/\s(?=\s)/", "", $str);
	    $str = preg_replace("/[\n\r\t]/", " ", $str);
	    $ram = explode(" ", $str);
	     

	    $mem_tot = $ram[1]*1024*1024;

	    $mem_free = $ram[3]*1024*1024;
	    $mem_porc = round($ram[3] * 100 / $ram[1],0);

	    if($mem_porc<=8) {
	      $mem_free_porc="<font color='red'>({$mem_porc}%)</font>";
	    }    
	    else if($mem_porc>8 && $mem_porc<15){
	      $mem_free_porc="<font color='orange'>({$mem_porc}%)</font>";
	    }     
	    else if($mem_porc>15){
	      $mem_free_porc="<font color='green'>({$mem_porc}%)</font>";
	    }

	    $mem_us = $ram[2]*1024*1024;
	    $mem_us_porc = round($ram[2] * 100 / $ram[1],0);

	    $mem_comp = $ram[4]*1024*1024;
	    $mem_comp_porc = " (".round($ram[4] * 100 / $ram[1],0)."%)";

	    $mem_buf = $ram[5]*1024*1024;
	    $mem_buf_porc = " (".round($ram[5] * 100 / $ram[1],0)."%)";

	    $mem_ch = $ram[6]*1024*1024;
	    $mem_ch_porc = "<font color=\"#2ec2d0\"> (".round($ram[6] * 100 / $ram[1],0)."%)</font>"; 	

	    $mem_values = array($mem_tot, $mem_free, $mem_free_porc, $mem_us, $mem_us_porc, $mem_comp, $mem_comp_porc, $mem_buf, $mem_buf_porc, $mem_ch, $mem_ch_porc);

	    return $mem_values;
	}

	public function getValuesSwap() 
	{
	    $str = trim($this->output[3]);
	    $str = preg_replace("/\s(?=\s)/", "", $str);
	    $str = preg_replace("/[\n\r\t]/", " ", $str);		
		$swap = explode(" ", $str);
	    $swap_tot = $swap[1]*1024*1024;

	    $swap_us = $swap[2]*1024*1024;
	    $swap_us_porc = " (".round($swap[2] * 100 / $swap[1],0)."%)";

	    $swap_free = $swap[3]*1024*1024;
	    $swap_free_porc = " (".round($swap[3] * 100 / $swap[1],0)."%)";

	    $swap_values = array($swap_tot, $swap_us, $swap_us_porc, $swap_free, $swap_free_porc);

	    return $swap_values;
	}

 }

 ?>