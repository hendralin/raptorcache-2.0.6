<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4.4
 */

class User extends Sanitize
{	
	public $objDb;
	public $objSession;
	public $result;
	public $rows;
	public $userRange;
	private $usern;
	private $passwd;

	public function __construct($db)
	{		
		$this->objDb = $db;	
	}
	
	public function loginUser()
	{
		$this->usern = $_POST['usern'];
		$this->usern = $this->string_sanitize($this->usern);
		$this->passwd = $_POST['passwd'];
		$this->passwd = $this->string_sanitize($this->passwd);
		$this->objSession = new Session();
		$sql = "SELECT * FROM user, user_profile WHERE user.loginUser = '".$this->usern."' AND user.passUser = '".md5($this->passwd)."' AND user.idprofile = user_profile.idProfile ";
		$this->result = $this->objDb->execute($sql);
		$this->rows   = mysqli_num_rows($this->result);
		if ( $this->rows > 0 ) {
			
			if ( $row = mysqli_fetch_array($this->result)) {
				//Sesions
				$this->objSession->init();
				$this->objSession->set('user', $row["loginUser"]);
				$this->objSession->set('iduser', $row["idUser"]);
				$this->objSession->set('idprofile', $row["idprofile"]);
				
				$this->userRange = $row["nameProfi"];
				
				switch( $this->userRange ){
						
					case 'admin':
						header('Location: admin/init');
						break;

					case 'invitado':
						header('Location: admin/init');
						break;
				}				
			}			
		} else {			
			header("Location: /?error=1&$this->rows");			
		}
		
	}

	public function getArrUser() 
	{
		$sql = "SELECT * FROM user";		
		$this->result = $this->objDb->execute($sql);
		return $this->result;
	}	

}

?>