<?php 

class Network 
{
/**
 * List interface network names.
 * @return array list interface network names
 */
	public function list_interface_name() 
	{
		$eth = shell_exec("sudo ls -A /sys/class/net | tr -d ' '");	
		//$eth = preg_replace("[\n|\r|\n\r]", '-', $eth);
		$arrEth = explode("\n", $eth);
		return $arrEth;
	}

	public function get_ip_cache()
	{
		$file = "/etc/squid3/squid.conf";
		$fileln = file($file);
		$pos = 0;
		foreach( $fileln as $linea ) {    
			if ( strstr($linea, "cache_peer ") ) {
			  $pos_cache_peer = $pos+1;        
			} 
			$pos++;
		}
		$content = file_get_contents($file);
		$row_cache_peer = explode("\n", $content);
		$ip_cache = $row_cache_peer[($pos_cache_peer-1)];
		$ip_cache = explode(" ", $ip_cache);		
		return $ip_cache[1];
	}

	public function show_interfaces() 
	{
	    $eth = shell_exec("sudo ifconfig -a -s | grep -Ee 'eth[0-9]' | awk {'print $1\" \"$2\" \"$3\" \"$4\" \"$5\" \"$6\" \"$7\" \"$8\" \"$9\" \"$10\" \"$11\" \"$12'}");
	    $eth = explode("\n", $eth);
	    echo "<table class=\"iface\" cellspacing='0' style=\"border-radius:0 0 3px 3px;\">";
	    echo "<tr>";
	    echo "<th>Iface</th>";
	    echo "<th>MTU</th>";
	    echo "<th>Met</th>";  
	    echo "<th>RX-OK</th>";
	    echo "<th>RX-ERR</th>";
	    echo "<th>RX-DRP</th>";
	    echo "<th>RX-OVR</th>";
	    echo "<th>TX-OK</th>";
	    echo "<th>TX-ERR</th>";
	    echo "<th>TX-DRP</th>";
	    echo "<th>TX-OVR</th>";
	    echo "<th style='border-right:none;'>Flag</th>";
	    echo "</tr>";
	    for ($i = 0; $i < count($eth); $i++) { 
	      if ($eth[$i] == "") 
	        break;
	      $dts_eth = trim($eth[$i]);
	      $dts_eth = explode(" ", $dts_eth);
	      echo "<tr class='row'>";
	      echo "<td>".$dts_eth[0]."</td>"; 
	      echo "<td>".$dts_eth[1]."</td>"; 
	      echo "<td>".$dts_eth[2]."</td>"; 
	      echo "<td>".$dts_eth[3]."</td>"; 
	      echo "<td>".$dts_eth[4]."</td>"; 
	      echo "<td>".$dts_eth[5]."</td>"; 
	      echo "<td>".$dts_eth[6]."</td>";  
	      echo "<td>".$dts_eth[7]."</td>"; 
	      echo "<td>".$dts_eth[8]."</td>"; 
	      echo "<td>".$dts_eth[9]."</td>"; 
	      echo "<td>".$dts_eth[10]."</td>"; 
	      echo "<td>".$dts_eth[11]."</td>"; 
	      echo "</tr>";
	    }
	    echo "</table>";		
	}

	public function show_ip_address_list() 
	{
	  $file_interface = "/etc/network/interfaces";
	  $fileln = file($file_interface);

	  echo "<table class=\"sortable\" cellspacing='0' style=\"border-radius:0 0 3px 3px;\">";
	  echo "<tr>";
	  echo "<th>Interface</th>";
	  echo "<th>IP</th>";
	  echo "<th>Netmask</th>";
	  echo "<th>Network</th>";
	  echo "<th>Broadcast</th>";
	  echo "<th>Gateway</th>";
	  echo "<th style='border-right:none;'></th>";
	  echo "</tr>";

	  $pos = 0;
	  foreach ($fileln as $linea) {
	    if (strstr($linea , "interface")) {
	          $row_check_format = $pos+1;
	    }    
	    if (strstr($linea , "allow-hotplug eth")) {
	          $row_allow_hotplug = $pos+1;
	    }
	    if (strstr($linea , "auto eth")) {
	          $row_auto = $pos+1;
	    }
	    if (strstr($linea , "auto br")) {
	          $row_br = $pos+1;
	    }      
	    $pos++;  
	  }

	    $pos = 0;
	    if (!isset($row_br)) { // not bridge interfaces
	      if ($row_allow_hotplug != "") {
	        $row_sel_type_eth = "allow-hotplug eth";
	      } else {
	        $row_sel_type_eth = "auto eth";
	      }

	      foreach ($fileln as $linea) {              
	        if (strstr($linea , $row_sel_type_eth)) {
	          $row_sel_eth = $pos+1;         

	          $num_eth = file_get_contents($file_interface);
	          $l_eth = explode("\n", $num_eth);

	          $eth_ex = $l_eth[($row_sel_eth-1)];
	          $n_eth = explode(" ",$eth_ex);
	          $n_eth = $n_eth[1];

	          $old_cache_mem = file_get_contents($file_interface);
	          $l_cache_mem = explode("\n", $old_cache_mem);

	          $allow_ex = $l_cache_mem[($row_sel_eth-1)];
	          $allow = explode(" ",$allow_ex);

	          $iface_ex = $l_cache_mem[($row_sel_eth)];
	          $iface = explode(" ",$iface_ex);

	          $address_ex = $l_cache_mem[($row_sel_eth)+1];
	          $address = explode(" ", $address_ex);
	          $ip_addrs = $address[1];

	          $netmask_ex = $l_cache_mem[($row_sel_eth+2)];
	          $netmask = explode(" ", $netmask_ex);

	          $network_ex = $l_cache_mem[($row_sel_eth+3)];
	          $network = explode(" ", $network_ex);

	          $broadcast_ex = $l_cache_mem[($row_sel_eth+4)];
	          $broadcast = explode(" ", $broadcast_ex); 

	          $gateway_ex = $l_cache_mem[($row_sel_eth+5)];
	          $gateway = explode(" ", $gateway_ex);

	          $comment_ex = $l_cache_mem[($row_sel_eth+6)];
	          $comment = explode(" ", $comment_ex);

	          $dns_nameservers_ex = $l_cache_mem[($row_sel_eth+7)];
	          $dns_nameservers = explode(" ", $dns_nameservers_ex);

	          $dns_search_ex = $l_cache_mem[($row_sel_eth+8)];
	          $dns_search = explode(" ", $dns_search_ex);

	          if ($row_check_format == "") {
	            $allow[1] = "Unreadable";
	            $address[1] = $netmask[1] = $network[1] = $broadcast[1] = $gateway[1] = "-";
	          } 

	          echo "<tr class='row'>";
	          echo "<td>{$allow[1]}</td>";
	          echo "<td>{$address[1]}</td>";
	          echo "<td>{$netmask[1]}</td>";
	          echo "<td>{$network[1]}</td>";
	          echo "<td>{$broadcast[1]}</td>";
	          echo "<td>{$gateway[1]}</td>";
	          echo "<td><a class='del_regx' href='network_del_ip.php?num_eth={$ip_addrs}'>X</a></td>"; // Delete interface
	          echo "</tr>";
	        }
	        $pos++;
	      }
	    }
	    $pos = 0;
	    if (isset($row_br)) {
	      foreach ($fileln as $linea) {
	        if (strstr($linea , "auto br")) {
	              $row_br = $pos+1;
	        }      
	        $pos++;         
	      }      

	      $old_br = file_get_contents($file_interface);
	      $l_br = explode("\n", $old_br);

	      $br_ex = trim($l_br[($row_br-1)]);
	      $brx = explode(" ", $br_ex);

	      $address_ex = trim($l_br[($row_br+2)]);
	      $address = explode(" ", $address_ex);        

	      $netmask_ex = trim($l_br[($row_br+3)]);
	      $netmask = explode(" ", $netmask_ex);

	      $network_ex = trim($l_br[($row_br+4)]);
	      $network = explode(" ", $network_ex);

	      $broadcast_ex = trim($l_br[($row_br+5)]);
	      $broadcast = explode(" ", $broadcast_ex); 

	      $gateway_ex = trim($l_br[($row_br+6)]);
	      $gateway = explode(" ", $gateway_ex);                

	      echo "<tr class='row'>";
	      echo "<td>{$brx[1]}</td>";
	      echo "<td>{$address[1]}</td>";
	      echo "<td>{$netmask[1]}</td>";
	      echo "<td>{$network[1]}</td>";
	      echo "<td>{$broadcast[1]}</td>";
	      echo "<td>{$gateway[1]}</td>";
	      echo "<td><a class='del_regx' href='network_del_ip.php?num_eth={$ip_addrs}'>X</a></td>";
	      echo "</tr>";
	    }
	  echo "</table>";		
	}		

	public function show_dns_address() {
	  $file_dns = "/etc/resolv.conf";
	  $fileln = file($file_dns);
	  echo "<table class=\"sortable\" cellspacing='0' style=\"border-radius:0 0 3px 3px;width:300px;margin-bottom: 0;\">";
	  echo "<tr>";
	  echo "<th style='border-right:none;'>Nameservers</th>";
	  echo "</tr>";
	    $posdns = 0;
	    foreach($fileln as $line_dns) {        
	      if (strstr($line_dns, "nameserver")){
	        $row_dns  = $posdns + 1;  
	        $content  = file_get_contents($file_dns);
	        $l_dns    = explode("\n", $content);
	        $l_dns    = $l_dns[($row_dns - 1)];
	        $ip_dns   = explode(" ", $l_dns);
	        $ip_dns   = $ip_dns[1];
	        if (trim($ip_dns) != "127.0.0.1")
	        echo "<tr class='row'><td>".$ip_dns."</td></tr>";
	      }
	      $posdns++;
	    }
	  echo "</table>";  
	}	

}


 ?>