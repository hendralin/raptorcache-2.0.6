<?php 
/**
 *
 * @package Raptorcache
 * @since 1.4
 */

$verwp    = "1.4.4";
$cop_year = "2017";

$eth_input_server = "eth0";

 ?>