<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */
 
header ("Content-type: text/html; charset=utf-8");
session_start();

  if (isset($_SESSION["rp"])) $noCookies=0; else $noCookies=1;
  echo $noCookies;

?>