<?php 

		$url = $getUrl;
		$url = rtrim($url, '/');
		$url = explode('/', $url);

		if (count($url) > 2) {
			header('location: /');
			exit();
		}

		if ($url[0] == "" || $url[0] == "i") {
			$url[0] = "index";
		}		

		if (isset($url[1])) {
			switch ($url[1]) {
				case 'System':
					$url[1] = 'system';	
					break;	
				case 'Getpage':
					$url[1] = 'getpage';
					break;								
				case 'Domains':
					$url[1] = 'domains';
					break;				
				case 'Storage':
					$url[1] = 'storage';
					break;									
				case 'Request':
					$url[1] = 'request';
					break;									
				case 'Threads':
					$url[1] = 'threads';
					break;	
				case 'Network_Traffic':
					$url[1] = 'network_Traffic';
					break;	
				case 'SSL':
					$url[1] = 'ssl';
					break;			
				case 'SUMMARY_SSL':
					$url[1] = 'summary_Ssl';
					break;		
				case 'SUMMARY_HTTP':
					$url[1] = 'summary_Http';
					break;		
				case 'Raptor_Conf':
					$url[1] = 'raptor_Conf';
					break;
				case 'Raptor_List':
					$url[1] = 'raptor_List';
					break;	
				case 'Raptor_WhiteList':
					$url[1] = 'raptor_WhiteList';
					break;	
				case 'Raptor_BlackList':
					$url[1] = 'raptor_BlackList';
					break;	
				case 'Raptor_Firewall':
					$url[1] = 'raptor_Firewall';
					break;	
				case 'Squid_Conf':
					$url[1] = 'squid_Conf';
					break;	
				case 'Monitor_Hard_Disk':
					$url[1] = 'monitor_Hard_Disk';
					break;
				case 'Monitor_Hard_Disk_IO':
					$url[1] = 'monitor_Hard_Disk_IO';
					break;	
				case 'Log_Access_HTTP':
					$url[1] = 'log_Access_HTTP';
					break;										
				case 'Log_Access_HTTPS':
					$url[1] = 'log_Access_HTTPS';
					break;										
				case 'Log_Error':
					$url[1] = 'log_Error';
					break;										
				case 'Log_System':
					$url[1] = 'log_System';
					break;									
				case 'Num_Conection_Users':
					$url[1] = 'num_Conection_Users';
					break;									
				case 'Ping_DNS':
					$url[1] = 'ping_Dns';
					break;									
				case 'Backup_Database':
					$url[1] = 'backupBd';
					break;																				
				case 'Update':
					$url[1] = 'update';
					break;						
				case 'Update_Manual':
					$url[1] = 'update_Manual';
					break;						
				case 'Licence':
					$url[1] = 'licence';
					break;		
				case 'Shutdown':
					$url[1] = 'shutdown';
					break;										
				case 'Network_Config':
					$url[1] = 'network_Config';
					break;					
				case 'DNS_Config':
					$url[1] = 'Dns_Config';
					break;				
				case 'Mount_Disk':
					$url[1] = 'mount_Disk';
					break;		
				case 'Scheduler':
					$url[1] = 'scheduler';
					break;									
				case 'Mikrotik_List':
					$url[1] = 'mikrotik_List';
					break;								
				case 'Users_Config':
					$url[1] = 'users_Config';
					break;				
				case 'Language_Config':
					$url[1] = 'language_Config';
					break;			
				case '*Conf_Man_775_*':
					$url[1] = 'mnl_cnf';
					break;						
				case 'Exit':
					$url[1] = 'log_Out';
					break;	
			}		
		}	   

 ?>