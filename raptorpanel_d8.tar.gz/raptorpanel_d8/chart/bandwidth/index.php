<?php 
if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}
 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
<script src="../<?php echo get_view_link(); ?>/js/rpengine.js"></script>    
<script src="../<?php echo get_view_link(); ?>/js/highstock.js"></script> 

<script>
$(document).ready(function() {
	    Highcharts.setOptions({
        lang: {
            numericSymbols: [' Kbps', ' Mbps', ' Gbps', ' Tbps', ' Pbps', ' Ebps']
        }
    });
    chart = new Highcharts.Chart({

        chart: {
            width: 978,
            backgroundColor: '#F9F9F9',
            renderTo: 'cont_bdw',
            defaultSeriesType: 'spline',
            events: {
                load: function requestData() {
                        $.ajax({
                            url: 'data.php',
                            success: function(point) {
                                var series = chart.series[0],
                                    shift = series.data.length > 220; 

                                var series2 = chart.series[1],
                                    shift2 = series2.data.length > 220; 

                                /*var series3 = chart.series[2],
                                    shift3 = series3.data.length > 220;*/

                                chart.series[0].addPoint([point[0],point[1]], true, shift);
                                chart.series[1].addPoint([point[0],point[2]], true, shift2);
                                //chart.series[2].addPoint([point[0],point[3]], true, shift3);
                                setTimeout(requestData, 2337);    
                            },       
                            cache: false
                        });
                    }
            }
        },
        credits: {
            text: false
        },        
        title: {
            text: false
        },
        legend: {
        	enabled: false
        },  
                
        exporting: {
            enabled: false
        },              
        xAxis: {
            labels: {
                enabled: false
                //x: 5
            },
            type: 'datetime',
        	tickInterval: 1,
            tickPixelInterval: 150,
            minRange: 450 * 1000,
        },
        yAxis: {
        	min:0,
            title: {
                text: false
            },  
            tickPixelInterval: 26,
            gridLineDashStyle: 'Dot',
            gridLineColor: '#777777' 
        },
        tooltip:false,
        plotOptions: {
            series: {
                lineWidth: 1,
                marker: {
                    radius: 0,
                    lineWidth: 1,
                    lineColor: null 
                },
                states: {
                	hover: {
                        enabled: false
                    }
                }
            }            
        },        
        series: [{
            tipe:'line',
            name: 'RX',
            color: '#FF0000',
            data: []
        },{
            tipe:'line',
            name: 'TX',
            color: '#2175D9',            
            data: []
        
        }/*,{
            tipe:'line',
            name: 'Total',
            color: '#5daf48',            
            data: []
        }*/]        
    });        
});

</script>
    <style>
    body{
        margin:0;
    }
    #cont_bdw{
    background-color:#F9F9F9;
    min-width: 400px; 
    max-width:978px; 
    height: 160px; 
    margin: 0 auto;
    border-left: 1px solid #afafaf;
    border-right: 1px solid #afafaf;
    /*border-top: 1px solid #afafaf; 
    padding-top:6px;*/
    border-bottom: 1px solid #afafaf;
    border-radius: 0 0 2px 2px;
    -webkit-border-radius: 0 0 2px 2px;
    -moz-border-radius: 0 0 2px 2px;
    display: inline-block;
}
    </style>    
</head>
<body>
    <div id="cont_bdw"></div>    
</body>
</html>