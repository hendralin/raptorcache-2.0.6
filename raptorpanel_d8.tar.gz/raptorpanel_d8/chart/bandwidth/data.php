<?php
header("Content-type: text/json");

    $file = "/var/tmp/ethmon";
	//define("FILE_ETHMON",     "/var/tmp/ethmon");
    //$r_file = file_get_contents($file);
    $r_file = file_get_contents($file);
    if ($r_file == "") {
    	require_once '../../main/settings.php';
    	exec("sudo ifstat -b 0.5 1 | grep -v eth0 | grep -v Kbps | xargs > $file");
    	$r_file = file_get_contents($file);
    }    
    $r_file = trim($r_file);
    $l_file = explode(" ", $r_file);
    $txeth = $l_file[0] * 1024;
    $rxeth = end($l_file) * 1024;
$x = time() * 1000;

$y = $rxeth;

//$x2 = time() * 1000;
$y2 = $txeth;

//$y3 = $y + $y2;
//$y3 = rand($y, $y2);

//$ret = array($x, $y, $y2, $y3);
$ret = array($x, $y, $y2);
echo json_encode($ret);
?>