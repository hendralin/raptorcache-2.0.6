<?php 
session_start();
include_once "../main/auth.php";
include_once "../main/functions.php";
include_once "../lang/Spanish.lang.php";
include_once "../conexion.php";
include_once "../main/sys.php";
?>
<?php
$cache_dir = "/raptorcache";
      $arr_d = explode("#", disk_use($cache_dir));
      $d_total = $arr_d[0]; 
      $d_usado = $arr_d[1]; 
      $d_pusado = $arr_d[2]; 
      $d_libre = $arr_d[3]; 
      $d_plibre = $arr_d[4]; 
?>
<?php
try {
    $db = new PDO("mysql:host=".DBHOST.";dbname=".DBNAME, DBUSER, DBPASS);    
} catch (PDOException $e) {
  print "<div style='font-family:Arial;color:#FFF;margin:auto;'><p style='background:red;text-align:center;border: 1px solid red; border-radius:4px;padding:4px;'>".$mysqlErr."<br />". $e->getMessage()."</p></div>";    
} 

global $db;
$query = "select domain, COUNT(*) as id from raptor";
foreach ($db->query($query) as $valor) {  
$totalcount += $valor["id"];      
}
$db = null;
?>
<script type="text/javascript" src="../js/jquery-1.7.2.js"></script> 
<script type="text/javascript" src="../js/highcharts.js"></script> 
<!--<script type="text/javascript" src="http://code.highcharts.com/highcharts.js"></script>
<script type="text/javascript" src="http://code.highcharts.com/highcharts-more.js"></script>-->
<script>
$(function () {
    $(document).ready(function () {
        //Highcharts.wrap(Highcharts.seriesTypes.pie.prototype, 'animate', function (proceed, init) {});
        var chart = null;

        var colors = Highcharts.getOptions().colors,
            categories = ['Usado', 'Libre'],
            name = 'Browser brands',
            data = [{
                y: <?php echo $d_pusado;?>,
                color: colors[0],
                drilldown: {
                    name: 'MSIE versions',
                    categories: ['MSIE 6.0', 'MSIE 7.0', 'MSIE 8.0', 'MSIE 9.0'],
                    data: [10.85, 7.35, 33.06, 2.81],
                    color: colors[0]
                }
            }, {
                y: <?php echo $d_plibre;?>,
                color: '#83be26',
                drilldown: {
                    name: 'Firefox versions',
                    categories: ['Firefox 2.0', 'Firefox 3.0', 'Firefox 3.5', 'Firefox 3.6', 'Firefox 4.0'],
                    data: [0.20, 0.83, 1.58, 13.12, 5.43],
                    color: colors[1]
                }
            }];


        // Build the data array
        var browserData = [];
        for (var i = 0; i < data.length; i++) {

            // add browser data
            browserData.push({
                name: categories[i],
                y: data[i].y,
                color: data[i].color
            });

        }

        // Create the chart
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'container2',
                backgroundColor:'#d8e5f2',
                type: 'pie'
            },
            credits: {
                text: false
            },
            title: {
                text: null
            },
            series: [{
                name: 'Space',
                data: browserData,
                innerSize: '0%'
            }],
            tooltip: {
                /*valueSuffix: '%',
                positioner: function () {
                    return {
                        x: this.chart.series[0].center[0] - (this.label.width / 2) + 8,
                        y: this.chart.series[0].center[1] - (this.label.height / 2) + 8
                    };
                }*/
                    formatter: function() {
                        return this.point.name + " - " + Highcharts.numberFormat(this.y, 0) +' ';
                        //return '<b>'+ this.point.y +' %'+'</b>';
                    }
            },
            plotOptions: {
                pie: {
                    cursor: 'pointer',
                    dataLabels: {
                        connectorColor: 'blue'
                    },
                    point: {
                        events: {
                            mouseOver: function () {

                                if (!this.connector.dynamicConnector) {
                                    var width = 16,
                                        height = 24;
                                    // Extract the connector start position
                                    var dArr = this.connector.d.split(' ');
                                    var startY = dArr.pop(),
                                        startX = dArr.pop();
                                    var start = [parseFloat(startX), parseFloat(startY)];
                                    // Construct the triangle
                                    var path = 'M ' + start[0] + ' ' + start[1] + 'L ' + (start[0] + height) + ' ' + (start[1] - (width / 2)) + ' L ' + (start[0] + height) + ' ' + (start[1] + (width / 2)) + ' L ' + start[0] + ' ' + start[1];

                                    // Convert the section angle from radian to degree and apply to the trangle
                                    // Setup rotation, x, y required by the updateTransform method
                                    this.connector.rotation = (this.angle * 180) / Math.PI;
                                    this.connector.x = startX;
                                    this.connector.y = startY;
                                    this.connector.updateTransform();

                                    this.connector.attr('stroke', this.color);
                                    this.connector.attr('fill', Highcharts.Color(this.color).brighten(0.2).get());
                                    this.connector.attr('d', path);

                                    this.connector.dynamicConnector = true;
                                }
                                this.connector.show();
                            },
                            mouseOut: function () {
                                this.connector.hide();
                            }
                        }
                    }
                }
            }
        });
    });
});
</script>

<script>

$(document).ready(function act() {
   $("#hddisk").load("../inc/hd_nums.php");
  var refreshId2 = setInterval(function ghddisk() {
   $("#hddisk").load('../inc/hd_nums.php');
   }, 27000);
      $.ajaxSetup({ cache: false });
});
</script>


<div style="" id="hdisk">
<table style="width:960px;height:220px;border:none;"> 
<tr>
<td> 
<div id="hddisk">
       
</div>
</td>

<td style="padding:20px 20px 0 0"> 

<div id="container2" style="background:#d8e5f2;position:relative;width: 200px; height: 200px; margin: 0 auto"></div>              
    
</td>

</tr>
</table>

</div><!--end hd -->