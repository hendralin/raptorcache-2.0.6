<?php 
error_reporting(0);
session_start();
include_once "../main/auth.php";
require "../class/Database.php";

$db = Database::getInstance();
$db->getConnection();
$sql = "SELECT DATE_FORMAT(date_ssl,'%d/%m/%Y') as date_ssl, count_files, file_size, eco_size, hits FROM `raptor`.`ssl` group by date_ssl DESC LIMIT 12";
$result = $db->execute($sql);

$rows = array();
while($r = mysqli_fetch_array($result)) {
	$row[0] = $r['date_ssl'];
	$row[1] = $r['eco_size'];
	array_push($rows,$row);
}

print json_encode($rows, JSON_NUMERIC_CHECK);

$db->disconnectDB();

?> 
