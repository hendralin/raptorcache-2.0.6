<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
 
require "global/above.php"; 
 ?>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script>

<style type="text/css">
	a.editRule{
		cursor: pointer;
	}
	a.editRule:hover {
		color: blue;
	}
</style>

<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<?php 
	if (isset($_GET['accion_fw'])) {
		echo "<div id='loading' style='margin-left:10px; display:none;'><div style='display:inline-block;' class='icon-widget r-spin'></div> {$alert_fw}</div>";
		shell_exec( "sudo bash /etc/raptor/fw.sh" ); 		
		echo "<script>case_alert('loading', 'Raptor_Firewall', '2000');</script>";	 
	}
?>
<div id='case_advice' style='margin:10px;width:964px;display:block;'><?php echo $advice_fw; ?><span style='font-weight:600;float:right;cursor:pointer;' class='close'><span class='icon-times'></span></div>
<script>
	$('.close').click(function(){
		$('#case_advice').fadeOut('slow');
	});	
</script>

<div class="tab_config">

	<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
	  <tr><th colspan=7 class="tabtit"><img style="vertical-align:bottom;" src="<?php echo get_view_link(); ?>/images/imgpng/firewall-icon.png" alt=""> Firewall</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
		
	<?php 
	spl_autoload_register(function ($className) {
		if (file_exists("models/". $className . '.php')) {
			include "models/". $className . '.php';
		} 		   
	});

		$file_route = "/etc/raptor/fw.sh";
		$file = new FileRp($file_route);
		$location = $file->getFileLocation();						
		$file->showRules();	
		
	?>  
	  
	<span class="btn-default"><button class="newRule"><span class="icon-plus"></span>&nbsp;New Rule</button></span>&nbsp;
	<span class="btn-default"><button class="firRule"><span class="icon-plus"></span>&nbsp;Filter Rule</button></span>&nbsp;
	<a id="restart" rel="" name="" href="Raptor_Firewall?accion_fw=fire_restart"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Firewall</button></a>

	<div class="editRuleDiv" title="Edit Rule"></div>

	<div class="newRuleDiv" title="New Rule"></div>	

	<div class="firRuleDiv" title="New Filter Rule"></div>	
	
</div>

</div>

</div>
 
<?php require "global/form/modal.php"; ?>

 </body>
 </html>



