<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();

require "global/above.php"; 
?>

<div id="tbod"><!-- TBOD --> 


<div style="height:168px;margin-left:45%;padding-top:12%;"><div id="getpage"><div class="icon-spinner r-spin"></div>&nbsp;&nbsp;<?php echo $loading; ?></div></div>

<?php
/**
 * url_link for menu
 */

$getLink = isset($_GET['url_link']) ? $_GET['url_link'] : null ;

if ($getLink != "") {
	echo '<script language="javascript">location.href="'.$getLink.'"</script>';
}

?>

</div><!-- END TBOD -->

<br>

</div><!-- END GERAL -->  

</body>
</html>
 