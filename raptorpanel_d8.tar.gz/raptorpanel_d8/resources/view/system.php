<?php
/**
 *
 * @author joemg http://www.raptorcache.org
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php"; 
 ?>

<div id="tbod"><!-- TBOD --> 

<div id="sys_state"><!-- VIT -->  
<?php include get_rp_path().'/inc/sys_state.php'; ?>
</div>

<div style="clear: both"></div>


<!--<div id="ln"><hr></div>-->
<div id="value_bandwd">
<?php include get_rp_path().'/inc/bdw.php'; ?>
</div>

  <div id="bandwd">
    <table> 
      <tr><td>
        <iframe src="../chart/bandwidth/index.php" ></iframe>
      </td></tr>
    </table>
  </div>

<!--<div id="ln"><hr></div>-->

<div id="memory"><!-- MEM-->
<?php include get_rp_path().'/inc/mmry.php'; ?>
</div><!-- END MEM-->

<br>

<!--<div id="ln"><hr></div>-->

<!-- HD -->
  <div id="tabhd">

<div id="hard_disk_system">  
<?php include get_rp_path().'/inc/hds.php'; ?>
</div>        

  </div>
<!--end HD -->

<br>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
