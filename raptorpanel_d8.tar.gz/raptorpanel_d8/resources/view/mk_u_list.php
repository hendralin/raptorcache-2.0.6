<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
session_start();    
require "global/above.php"; 

?>
<div id="tbod"> 

<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-list-alt"></span>&nbsp;Mikrotik - HTTPS Address List</th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<?php
require "class/Database.php";
require "models/Router.php";

$db = Database::getInstance();
$db->getConnection();
$rb = new Router($db);

if ($rb->conApiRouter()) {
  $rb->showListUsers();
  $connect_mk = "<span class='enabled_pl' style='text-shadow:none;'>ON</span>";
} else {
  $connect_mk = "<span class='disabled_pl' style='text-shadow:none;'>OFF</span>";
}
echo "<a id='go' class='conMk' name='conMk' href='#conMk'><button>{$connect_mk}&nbsp;Conect</button></a>&nbsp;";
if ($rb->conApiRouter()) {
echo "<a id='go' class='newUser' name='newUser' href='#newUser'><button><span class='icon-user'></span>&nbsp;New User</button></a>";
}
$rb->API->disconnect();
$db->disconnectDB();  
?>



  <div class="newUserDiv" title="<?php echo "New User"; ?>"></div> 
  <div class="conMkDiv" title="<?php echo "Conect Mikrotik"; ?>"></div>  


<script>
  $( function() {
    var newUser, addGw, addBr,
    newUser = $( ".newUserDiv" ).dialog({
      autoOpen: false,
      height: 190,
      width: 288,
      modal: true,
      open: function () {             
                $(".newUserDiv").load('../global/form/newUserMk.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#ip_mk_list').val()) {  
            alert('Please, insert IP');
            return false;  
          } else {
            $("#newUserForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".newUser" ).on( "click", function() {
      newUser.dialog( "open" );
    });   

    conMkUser = $( ".conMkDiv" ).dialog({
      autoOpen: false,
      height: 222,
      width: 288,
      modal: true,
      open: function () {             
                <?php echo "$('.conMkDiv').load('../global/form/conMk.php?ip_mk=$ip_mk&user_mk=$user_mk&pass_mk=$pass_mk');";  ?>                 
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#ip_mk').val()) {  
            alert('Please, insert IP Mikrotik');
            return false;  
          } else {
            $("#conMkForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".conMk" ).on( "click", function() {
      conMkUser.dialog( "open" );
    });    

  }); 
</script>  

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 

</div>

 </div>
 
 </body>
 </html>