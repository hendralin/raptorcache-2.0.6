<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();
?>

<?php require "global/above.php"; ?>

<?php 
$file = "/etc/raptor/raptor.conf";
$v_cache_limit = value_directive($file, "CACHE_LIMIT");
$v_min_object_size = value_directive($file, "MIN_OBJECT_SIZE");
 ?>

<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<?php 
if (isset($_GET['accion'])) {
    echo "<div id=\"loading\" style=\"margin-left:10px; display:none;\"><div style=\"display:inline-block;\" class=\"icon-widget r-spin\"></div> {$alert_change_ok}</div>";
    echo "<script>case_alert(\"loading\", \"Raptor_Conf\", \"1000\");</script>";
  }
?>

<div class="tab_config">
	<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
	  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span>&nbsp;Raptor.conf</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
	<table cellspacing='0' style="border-radius:0 0 3px 3px;border-top:none;">
	  <tr>
		<td id="confrp_td">
		  
			<div class="confrp">
				<form action="ajxrp.req" id="idForm" method="POST">
				  <table class="options">
				    <tr>
				      <td>CACHE_LIMIT</td>
				      <td><input name="cache_limit" id="cache_limit" type="text" value="<?php echo $v_cache_limit; ?>">&nbsp;%&nbsp;&nbsp;&nbsp;&nbsp;</td>
				    </tr> 
				    <tr>
				      <td>MIN_OBJECT_SIZE</td>
				      <td><input name="min_object_size" id="min_object_size" type="text" value="<?php echo $v_min_object_size; ?>">&nbsp;Bytes</td>
				    </tr>
				    <tr>
				      <td></td>
				      <td><span class="btn-default"><button id="enviar" name="rp_submit" type="button"><span class="icon-floppy-o"></span>&nbsp;<?php echo $bt_grd; ?></button></span></td>
				    </tr>   
				  </table>
				</form>
				<div id='case_float_alert' style=""></div>
			</div> 

		</td>
	  </tr>	  
	</table>
</div>

<script src="<?php echo get_view_link(); ?>/js/form.ajx.js"></script>
<script>
	var x;
	x = $(document);
	x.ready(init);	
</script>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "global/below.php"; ?>
