<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php"; 
require "models/autoload.php";

$network = new Network();

?>

<div id="tbod"> 

<?php 
  include "global/alert_case.php"; 
?>

<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> <?php echo $net_ir; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>
<?php 
    $network->show_interfaces();
 ?>
</div>

<hr>	

<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> <?php echo $net_ip; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>
<?php 
    $network->show_ip_address_list();
 ?>

<script type="text/javascript">  
	$(function() {  
	  $('#form_ip').submit(comprobarCampos);  
	});  
	function comprobarCampos() {  
	  if(!$('#interface').val()) {  
	    alert('<?php echo $alert_iface; ?>');
	    return false;  
	  }		   		   
	}  
</script>

  <span class="btn-default"><button class="addIp"><?php echo "Change IP"; ?></button></span>
  <span class="btn-default"><button class="addGw"><?php echo "Gateway Mode"; ?></button></span>
  <span class="btn-default"><button class="addBr"><?php echo "Bridge Mode"; ?></button></span>
<?php 
$uppass = isset($_GET['error_add_ip']) ? $_GET['error_add_ip'] : null ;
if ($uppass == "no") {
	echo "<span id=\"alert_add_ip\" style=\";\">{$alert_no_ip}</span>";
}
 ?>	
 <script>
$(document).ready(function() { 
    setTimeout(function() { 
        $('#alert_add_ip').fadeOut('slow'); 
 	}, 3000); 
});
</script> 	

	<div class="addIpDiv" title="<?php echo "Change IP"; ?>"></div>	

	<div class="addGwDiv" title="<?php echo "Gateway Mode"; ?>"></div>	

	<div class="addBrDiv" title="<?php echo "Bridge Mode"; ?>"></div>	

<script>
  $( function() {
  	var addIp, addGw, addBr,
    addIp = $( ".addIpDiv" ).dialog({
      autoOpen: false,
      height: 332,
      width: 320,
      modal: true,
      open: function () {             
                $(".addIpDiv").load('../global/form/addIp.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#ip').val()) {  
            alert('Please, insert ACL Rule');
            return false;  
          } else {
            $("#addIpForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addIp" ).on( "click", function() {
      addIp.dialog( "open" );
    });   

    addGw = $( ".addGwDiv" ).dialog({
      autoOpen: false,
      height: 442,
      width: 320,
      modal: true,
      open: function () {             
                $(".addGwDiv").load('../global/form/addGw.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#ip_1').val()) {  
            alert('Please, insert ACL Rule');
            return false;  
          } else {
            $("#addGwForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addGw" ).on( "click", function() {
      addGw.dialog( "open" );
    });

    addBr = $( ".addBrDiv" ).dialog({
      autoOpen: false,
      height: 366,
      width: 320,
      modal: true,
      open: function () {             
                $(".addBrDiv").load('../global/form/addBr.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#ip').val()) {  
            alert('Please, insert ACL Rule');
            return false;  
          } else {
            $("#addBrForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addBr" ).on( "click", function() {
      addBr.dialog( "open" );
    });    

  });	
</script>

</div>

<hr>

<div class="tab_config">
	<table style="margin-top:8px;border-radius:3px 3px 0 0;width:300px;" >
	  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> IP Cache</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
  <form action='ipcache.req' method='GET'>
    <table style='width:300px;padding:10px;border-radius:2px;'>
      <tr>
        <td style='text-align:left;'><input name='ip_cache' type='text' value='<?php echo $network->get_ip_cache(); ?>' autocomplete='off'>&nbsp;&nbsp;<span class='validate_ip'></span></td>
      </tr>
      <tr><td class='ip_blank' style='display:none;'><span class='validate_ip'>! Insert IP Server</span></td></tr>
      <tr>
        <td style='text-align:left;'><span class='btn-default'><button><span class='icon-floppy-o'></span>&nbsp;<?php echo $bt_grd; ?></button></span></td>
      </tr>
    </table>
  </form>
<script>
  x = $('input[name="ip_cache"]');
  if (x.val() == "") {
    console.log("IP cache is blank");
    $( 'td.ip_blank' ).css({display:"block"});
  }
</script>

</div>

<hr>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>