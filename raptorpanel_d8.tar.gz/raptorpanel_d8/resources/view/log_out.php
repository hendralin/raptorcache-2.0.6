<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>       
	<meta name="charset" content="utf-8" />
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">    
	<link rel="shortcut icon" href="../public/images/favicon.png" />       
    <link rel="Stylesheet" href="../public/css/normalize.css" type="text/css">
    <link rel="stylesheet" href="../public/css/style.css" type="text/css" /> 
    <link rel="stylesheet" href="../public/css/raptor.css" type="text/css" />
    <script type="text/javascript" src="../public/js/rpengine.js"></script>
</head>

<?php 
$action = isset($_GET['action']) ? $_GET['action'] : null ;

if ($action == "reboot") {
  $time = 10000;
  $msn = "Restarting Server...";
  $shut = "
    $.ajax({
      type: \"POST\",
      url: 'log_out.req',
      data: {action:\"reboot\"}, //send data if needed
      //success:function(){ }
    }); ";  
}
if ($action == "halt") {
  $time = 1000;  
  $msn = "ShutDown Server...";
  $shut = "
    $.ajax({
      type: \"POST\",
      url: 'log_out.req',
      data: {action:\"halt\"}, //send data if needed
      //success:function(){ }
    }); ";   
} 
if ($action == "" || $action == null) {
  $time = 1000;  
  $msn = "Exiting...";
  $shut = "
    $.ajax({
      type: \"POST\",
      url: 'log_out.req',
      //success:function(){ }
    }); "; 
}

 ?>

<body>
	<div style="display: flex; justify-content: center; margin-top: 38vh"><div id="loading" style="display:none;"><div style="display:inline-block;" class="icon-spinner r-spin"></div>&nbsp;&nbsp;<?php echo $msn; ?></div></div>
    <script>
    $(document).ready( function() { 
      <?php echo $shut; ?>
      $("#loading").fadeIn('slow', function() {
          setTimeout(function() { 
              $('#loading').fadeOut('fast', function() { 
                window.location = "init";
              });           
        }, <?php echo $time; ?>);       
      });    
    });
    </script>
</body>
</html>


