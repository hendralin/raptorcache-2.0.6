<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php";  

require "models/FileSq.php";
$sq = new FileSq();
$sq->get_dns_nameservers();
?>

<?php
$path_sq = "/etc/squid3/squid.conf";
if (isset($_POST["content"])) {
    $content = ($_POST["content"]);
    $fp = fopen($path_sq,"r") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error, open the file");
    fclose($fp) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error, close the file");
}
?>

<div id="tbod"> 

<?php 
	$alert_msg = $bt_restart.' Squid'; 
	include_once "global/form/restart.php"; 
?>		
<div id="case_float_alert"></div>

<?php 
	include "global/alert_case.php"; 
?>

<div class="tab_config">
	<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
	  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span>&nbsp;Squid.conf</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
	<table cellspacing='0' style="border-radius:0 0 3px 3px;border-top:none;">
	  <tr>
	<td id="confrp_td">
	  
	<div class="confrp">

		<form style="padding-bottom:8px;" action="sqconf.req" method="POST">
			<table class="options">
				<tr>
					<td>DNS NAMESERVERS 1</td>
					<td><input name="dns_nameservers1" type="text" value="<?php echo $sq->get_dns1(); ?>"></td>
				</tr>
				<tr>
					<td>DNS NAMESERVERS 2</td>
					<td><input name="dns_nameservers2" type="text" value="<?php echo $sq->get_dns2(); ?>"></td>
				</tr>					
				<tr>
					<td></td>
					<td><button id="enviar" name="dns_submit" style="" type="submit" title=""><span class="icon-floppy-o"></span>&nbsp;<?php echo $bt_grd; ?></button></td>
				</tr>		
			</table>
		</form>


	<?php 
		$sq->show_localnet();  
	 ?>						
	<div style="width:140px;"><span class="btn-defult"><button class="addAcl"><span class="icon-plus"></span>&nbsp;<?php echo "<span style='vertical-align:top;'>".$bt_agr." ACL</span>"; ?></button></span></div>

	<div class="small-1-1-Div" title="<?php echo $bt_agr." ACL Localnet"; ?>"></div>	

<script>
  $( function() {
  	var smallDiv, 
    smallDiv = $( ".small-1-1-Div" ).dialog({
      autoOpen: false,
      height: 160,
      width: 320,
      modal: true,
      open: function () {             
                $(".small-1-1-Div").load('../global/form/small-1-1.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#acl_ln').val()) {  
            alert('Please, insert ACL Rule');
            return false;  
          } else {
            $("#small-1-1-Form").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addAcl" ).on( "click", function() {
      smallDiv.dialog( "open" );
    });   
  });	
</script>

	<div id="ln"><hr></div>

	<div style="padding:10px 10px 0 0;text-align:right;"><a id="restart" href="#" onclick="restart('shut_rp.req')"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Squid</button></a></div>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
	<script>
	  $(function() {
	    $( "#conf_txt" ).accordion({
	    	active: false,	
			collapsible: true, 
	      
	    });
	  });
	</script>
		<br>
		<div id="conf_txt" style="margin-left:10px;margin-bottom:10px;">
			<h3 style="text-align:left;color:#454545;">View Config</h3>
			<div>
				<textarea style="font-size:12px;" readonly rows="25" name="content"><?php readfile($path_sq); ?></textarea>
			</div>
		</div>

	</div> 

	</td>
	  </tr>
	  
	 </table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
