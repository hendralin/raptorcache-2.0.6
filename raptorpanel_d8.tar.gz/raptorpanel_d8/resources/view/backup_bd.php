<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php"; 
 ?> 

<?php 
if ($_GET['accion']=="add_backrp") {
	echo "<div id=\"loading\" style=\"margin-left:10px;\"><div style=\"display:inline-block;\" class=\"icon-widget r-spin\"></div> &nbsp;Backup Database</div>";
  exec( "sudo mysqldump -uroot raptor -praptor > /var/backup_raptor_db/backup_raptor_`date +%Y-%m-%d_%H:%M`.sql" );
?>
<script>
$(document).ready(function() { 
    setTimeout(function() { 
        $('#loading').fadeOut('slow'); 
 	}, 2000); 
	window.location="Backup_Database"; 	
});
</script>
<?php	 
}
 ?>
<div id="tbod"> 

<div class="tab_report">
<table class="sortable" style="margin-top:8px;border-radius:3px 3px 0 0;" >
	<tr><th colspan=7 class="tabtit"><span class="icon-database-1"></span> Backup Database</th></tr>
	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>
<table id="sorter" class="sortable" cellspacing='0' style="border-radius:0 0 3px 3px;border-top:none;">
  <tr>
<th style="border-right:none;"><div id="bd" style="text-align:left;">
<a href="Backup_Database?accion=add_backrp"><button type="submit" title="" value="" ><span class="icon-floppy-o"></span> Backup</button></a>
</div>
</th>
</tr>  
  
<?php
$files = array(); 
$dir = "/var/backup_raptor_db/"; 
if ($opendir = opendir($dir)) 
{ 
     while (($file = readdir($opendir)) !== FALSE)  
     { 
          if ($file!="."&&$file!="..") 
               $files[] = $file; 
     } 
} 
natsort($files);
foreach($files as $file) 
{ 
     echo "<div><tr class=\"row\"><td>$file</td></tr></div>"; 
}  
?>
  
 </table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
