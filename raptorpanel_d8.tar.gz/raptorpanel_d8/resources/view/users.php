 <?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php"; 
 ?>

	
<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<?php 
if ($_GET['add'] == "no") {
	echo "<div id=\"error\" style=\"display:none;\"> {$alert_add_us_er}</div>";		
  echo "<script>case_alert(\"error\", \"Users_Config\", \"1000\");</script>";
} 
else if ($_GET['changePass'] == "no") {
  echo "<div id=\"error\" style=\"display:none;\"> {$alert_chg_us_er}</div>";     
  echo "<script>case_alert(\"error\", \"Users_Config\", \"1000\");</script>";
}
else if ($_GET['accion'] == 1) {
    echo "<div id=\"loading\" style=\"display:none;\"><div class=\"icon-widget r-spin\"></div> {$alert_change_ok}</div>";
    echo "<script>case_alert(\"loading\", \"Users_Config\", \"1000\");</script>";
  }
 ?>


<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-users"></span> Usuarios</th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<table class="sortable" id="sorter" style="border-radius:0 0 3px 3px;border-top:none;">
<tr>
	<th>Login</th>
	<th>Email</th>
	<th><?php echo $prof; ?></th>
	<th style="border-right:none;"></th>
</tr>

<?php 

require 'class/Database.php';
require 'class/Sanitize.php';
require 'models/User.php';

$db = Database::getInstance();
$db->getConnection();

$objUser = new User($db);

	foreach ( $objUser->getArrUser() as $row ) {
		if ( $row['idprofile'] == 1 ) {
			$profile = "Admin";		
		}
		if ( $row['idprofile'] == 2 ) {
			$profile = "Invitado";
		}
		echo '<tr class="row">
					<td>'.utf8_decode($row['loginUser']).'</td>
			    	<td>'.$row['emailUser'].'</td>	  
			    	<td>'.$profile.'</td>
			    	<td style="width:60px;margin:0;padding:0;">';

		    if ( $row['loginUser'] != "admin" ) 
		      	echo '<a class="del_regx" href="users.req?idUser='.$row['idUser'].'">X</a>
		    		</td>';		       
		echo '</tr>';
	}

?>

</table>

<a class="btn-default"><button class="newUser"><?php echo $pu_new_user; ?></button></a>
<div class="newUserDiv" title="<?php echo $pu_new_user; ?>"></div>

<a class="btn-default"><button class="changePass"><?php echo $pu_change_pw; ?></button></a>
<div class="changePassDiv" title="<?php echo $pu_change_pw; ?>"></div>	

</div>

<?php $db->disconnectDB(); ?>

<script>
  $( function() {
  	var newUser, changePass,
    newUser = $( ".newUserDiv" ).dialog({
      autoOpen: false,
      height: 260,
      width: 320,
      modal: true,
      open: function () {             
                $(".newUserDiv").load('../global/form/newUser.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#userName').val()) {  
            alert('Please, insert Username');
            return false;  
          } else {
            $("#newUserForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".newUser" ).on( "click", function() {
      newUser.dialog( "open" );
    });  

    changePass = $( ".changePassDiv" ).dialog({
      autoOpen: false,
      height: 226,
      width: 340,
      modal: true,
      open: function () {             
                $(".changePassDiv").load('../global/form/changePassUser.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#user').val()) {  
            alert('Please, insert Username');
            return false;  
          } else {
            $("#changePassForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".changePass" ).on( "click", function() {
      changePass.dialog( "open" );
    });  

  });	
</script>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 

</div>

 </div>
 
 </body>
 </html>