<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
require "global/above.php"; 

?>

    <link rel="stylesheet" type="text/css" href="<?php echo get_view_link(); ?>/css/dataTables.css">
    <script type="text/javascript" language="javascript" src="<?php echo get_view_link(); ?>/js/dataTables.js"></script>
    <script type="text/javascript" language="javascript" >
      $(document).ready(function() {
        var dataTable = $('#statistic-grid').DataTable( {
          "processing": true,
          "serverSide": true,
          "ajax":{
            url :"../inc/c_request.php",
            type: "post",
            error: function(){
              $(".statistic-grid-error").html("");
              $("#statistic-grid").append('<tbody class="statistic-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
              $("#statistic-grid_processing").css("display","none");
              
            }
          }
        } );
      } );
    </script>

<div id="tbod"> 

  <div class="tab_report">
    <table class="sortable" style="margin-top:8px;border-radius:3px 3px 0 0;" >
      <tr><th colspan=7 class="tabtit"><span class="icon-graph"></span>&nbsp;<?php echo $rp_repdreq; ?></th></tr>
      <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
    </table>
    <iframe src="../chart/chart_req.php" ></iframe>
        <table id="statistic-grid"  cellpadding="0" cellspacing="0" border="0" class="display" width="100%">
            <thead>
              <tr>
                <th></th>
                <th><?php echo $rp_date; ?></th>
                <th><?php echo $rp_files; ?></th>
                <th><?php echo $rp_eco; ?></th>
                <th><?php echo $rp_hits; ?></th>
                <th><?php echo $rp_porcent; ?></th>
              </tr>
            </thead>
        </table>
  </div>

  <div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "global/below.php"; ?>