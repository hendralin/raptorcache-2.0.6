<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();

require "global/above.php"; 

require 'models/autoload.php';
$rp = new UpdateRp();

?>

  <div id="tbod"><!-- TBOD --> 

  <script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>

<?php 

if ($rp->get_host_conection()) { 
  if ($rp->update_status() == true) {
    echo "<div style='height:204px;margin-left:32%;padding-top:8%;'><div id='case_update' style='display:none;'><div style='display:inline-block;' class='icon-refresh r-spin'></div>&nbsp;&nbsp;{$str_update}&nbsp;{$str_available}</div></div>";   
    echo "<script>
    $(document).ready( function() { 
      $('#case_update').fadeIn('slow', function(){
        window.location = 'Update';    
      });    
    });
    </script>";  
  } else {
    echo "<div style='height:168px;margin-left:45%;padding-top:12%;'><div id='loading'><div style='display:inline-block;' class='icon-spinner r-spin'></div>&nbsp;".$loading."</div></div>";
    echo "<script>
    $(document).ready( function() { 
      $('#loading').fadeIn('slow', function(){
        window.location = 'System';    
      });    
    });
    </script>";     
  }
} else {
  echo "<div style='height:168px;margin-left:45%;padding-top:12%;'><div id='loading'><div style='display:inline-block;' class='icon-spinner r-spin'></div>&nbsp;".$loading."</div></div>";  
  echo "<script>
  $(document).ready( function() { 
    $('#loading').fadeIn('slow', function(){
      window.location = 'System';    
    });    
  });
  </script>";   
}

?>

  </div><!-- END TBOD -->

  <br>

  </div><!-- END GERAL -->  

  </body>
</html>
