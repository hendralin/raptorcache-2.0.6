 <?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
 
require "global/above.php"; 
require "models/autoload.php";

$cron = new Cron();
$cron->get_values_shutdown();
?>
	
<div id="tbod"> 

<?php 
  include "global/alert_case.php"; 
  if ($_GET['accion_cr'] == 'cron_restart') {
    echo "<div id='loading' style='display:none;'><div class='icon-widget r-spin'></div>&nbsp;{$alert_restart}&nbsp;Cron</div>";    
    exec("sudo chmod 644 /etc/crontab");
    exec("sudo /etc/init.d/cron force-reload && sudo /etc/init.d/cron restart");    
    echo "<script>case_alert('loading', 'Scheduler', '1000');</script>"; 
  }    
 ?>

<div class="tab_config">
	<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  	<tr><th colspan=7 class="tabtit"><span class="icon-cog"></span> Scheduler</th></tr>
  	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>

<table cellspacing='0' style="border-radius:0 0 3px 3px;border-top:none;">
 	<tr><td id="confrp_td">  
		<div class="confrp">

			<form action="cron.req" method="POST" style="padding: 10px 0 2px 0">
       		<table class="options">		
            <tr>
              <td class='label'>Clean Raptor</td>
              <td style='width:64px'><input style='width:32px' name='clean' id='clean' type='number' maxlength='2' value='<?php echo $cron->get_value_clean(); ?>' required /></td>
              <td><span class='btn-default'><button><span class='icon-floppy-o'></span>&nbsp;<?php echo $bt_grd; ?></button></span></td>
            </tr>
       		</table>
       </form>
		<div id="ln"><hr></div>

<form action="cron.req" method="POST">
  <table class="options">
<?php 
if ($cron->get_stat_shutdown() == true) {
  echo "
  <tr>
    <td class='label'>Shutdown</td>
    <td colspan='2'>	
    	<div class='container_switch'>
        <label class='switch'>
          <input type='checkbox' id='shutdown1' name='status' class='switch-input' checked>
          <input type='hidden' name='stat_cron' value='1'>
          <span class='switch-label' data-off='Off' data-on='On' ></span>
          <span class='switch-handle'></span>
        </label>
      </div>
    </td>
  </tr>";
  echo "
  <tr>
    <td><input name='submit_shutdown' id='' type='hidden' value='{$cron->get_hour_shutdown()}' /></td>
    <td style='width:80px'>Hr.&nbsp;<input style='width:32px' name='h_shutdown' id='shutdown2' type='text' maxlength='2' value='{$cron->get_hour_shutdown()}' required /></td>
    <td style='width:80px'>Min.&nbsp;<input style='width:32px' name='m_shutdown' id='shutdown2' type='text' maxlength='2' value='{$cron->get_minute_shutdown()}' required /></td>
    <td><span class='btn-default'><button name='change_shutdown'><span class='icon
    -floppy-o'></span>&nbsp;{$bt_grd}</button></span></td>
  </tr>";       
} else {    
  echo "
  <tr>
    <td class='label'>Shutdown</td>   	
    <td>	
      <div class='container_switch'>
      <label class='switch'>
        <input type='checkbox' id='shutdown1' name='status' class='switch-input'>
        <input type='hidden' name='stat_cron' value='0'>
        <span class='switch-label' data-off='Off' data-on='On' ></span>
        <span class='switch-handle'></span>
      </label>
    	</div>
  	</td>	
    <td><input style='' name='submit_shutdown' id='' type='hidden' value='{$cron->get_hour_shutdown()}' />
  </tr>";           
} 
 ?>
  </table>
</form> 

<script>
$('#shutdown1').change(function() {
  $(this).closest("form").submit();
});	
$('#shutdown2').change(function() {
  $(this).closest("form").submit();
});	
</script>

		<div id="ln"><hr></div>

	<div style="padding:0 10px 10px 0;text-align:right;"><a id="restart" rel="" name="" href="Scheduler?accion_cr=cron_restart"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Cron</button></a></div>

		</div> 
	</td></tr>  
</table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>		