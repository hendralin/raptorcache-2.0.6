<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php"; 
 ?>

<div id="tbod"> 

<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-results-demographics"></span>&nbsp;<?php echo $num_cnx; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>
<table cellspacing='0' style="border-radius:0 0 3px 3px;border-top:none;">
  <tr>
<td id="confrp_td">
  
<pre style="font-size: 13px;color: #0e82b2;">
<?php system("netstat -plan|grep :3128 | awk {'print $5'} | cut -d: -f 1 | sort | uniq -c | sort -n | grep -v 0.0.0.0 | grep -v 127.0.0.1"); ?>
</pre>

</td>
  </tr>
  
 </table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
