<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

require "global/above.php"; 
 ?>

<div id="tbod"> 

<div class="tab_report">
<table class="sortable" style="margin-top:8px;border-radius:3px 3px 0 0;" >
	<tr><th colspan=7 class="tabtit"><span class="icon-list"></span>&nbsp;Log</th></tr>
	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<table class="sortable">
	<tr>
		<th class="log">HTTPS</th>
		<th class="sel_log">
			<form action="getlog.req" method="GET" class="link">                
                Type: <select style="font-weight:normal;" name="acs" id="acs" onchange="this.form.submit();">
                    <option value=""></option>
                    <option value="rpt_acc_lg">Access Log</option>
                    <option value="rpt_https_lg">HTTPS Log</option>
                    <option value="rpt_err_lg">Error Log</option>
                    <option value="rpt_sys_lg">Sys Log</option>
                </select>
            </form>

		</th>
	</tr>
</table>

<?php include "inc/logs_rp_https.php"; ?>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
