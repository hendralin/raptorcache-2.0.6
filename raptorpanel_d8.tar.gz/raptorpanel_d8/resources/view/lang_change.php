<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "global/above.php"; 
?>

<div id="tbod"> 

<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span> <?php echo $lng_ttitle; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

 <form action="lang_change.req" method="POST" name="NombreForm" >
	 <table>
		 <tr><td>&nbsp;</td></tr>
		 <tr>
		 	<td style="text-align:left;padding-left: 20px;">
			 	<select name="lang" id="lang" onchange="this.form.submit();">
<?php 
	if ($deflang == "Spanish"){
		$img_lg="spanish_flag";
	} else if ($deflang == "English"){
		$img_lg="usa_flag";
	} else if ($deflang == "Portugues"){
		$img_lg="brasil_flag";
	}

	include 'global/lang.php';
	if ($deflang == "Spanish") {
		echo "<option value='Spanish'>{$lng_es}&nbsp;</option>";
		echo "<option value='English'>{$lng_en}&nbsp;</option>";
		echo "<option value='Portugues'>{$lng_pt}&nbsp;</option>";	
	} else if ($deflang == "English") {
		echo "<option value='English'>{$lng_en}&nbsp;</option>";	
		echo "<option value='Spanish'>{$lng_es}&nbsp;</option>";
		echo "<option value='Portugues'>{$lng_pt}&nbsp;</option>";	
	} else if ($deflang == "Portugues") {
		echo "<option value='Portugues'>{$lng_pt}&nbsp;</option>";
		echo "<option value='Spanish'>{$lng_es}&nbsp;</option>";
		echo "<option value='English'>{$lng_en}&nbsp;</option>";	
	}
 ?> 		
			 	</select>
		 	</td>
		 </tr>
		 <tr>
		 	<td style="text-align:left;padding-left: 20px;"><img src="<?php echo get_view_link(); ?>/images/<?php echo $img_lg; ?>.png"></td>
		 </tr>
		 <tr><td>&nbsp;</td></tr>		 
	 </table>
 </form>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
