<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.3
 */

session_start();
 
require "global/above.php"; 
 ?>

<div id="tbod"> 

<div class="tab_config">
<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span><?php echo "&nbsp;&nbsp;Admin&nbsp;&nbsp;-".$m_dd; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>


<table cellspacing='0' style="border-radius:0 0 3px 3px;border-top:none;">
	<tr><td>



<?php 
include_once "main/functions.php";

require "global/lang.php";
require "lang/$deflang.php";
?>


<div id="hard_disk_mount">
<?php 
	$file = "/etc/fstab";
	$fileln = file($file);

	$content_row = "raptor";    
	$pos = 0;

	(int)$check_cache_dirx = exec("sudo cat /etc/fstab | grep 'raptor' | wc -l");

	foreach($fileln as $linea) {	        
		if (strstr($linea, $content_row)){
		 $row = $pos+1;   
	        $old_fstab = file_get_contents($file);
	        $l_fstab = explode("\n", $old_fstab);
	        $l_fstab_ex = $l_fstab[($row-1)];	
	        $tmp_cache_dir_mount = explode("/usr/local/raptor/", ltrim($l_fstab_ex));
	        $tmp_cache_dir_mount = explode("ext4", $tmp_cache_dir_mount[1]);
	        $cache_dir_mount = trim($tmp_cache_dir_mount[0]);
	        
	        for ( $i = 0; $i < $check_cache_dirx ; $i++) {
	        	$c_dir = "cache".$i;
	        	if ($cache_dir_mount == $c_dir) {
	        		break;
	        	} else {
	        		if ($cache_dir_mount != $c_dir) {
	        		$new_num_cache_dir = $check_cache_dirx + 1;
	        		$new_cache_dir = "/usr/local/raptor/cache".$new_num_cache_dir;
	        		break 2;
	        		}
	        	}
	        }
		}
		else{
		}
	   $pos++;
	}

require "models/HardDisk.php";

$hd = new HardDisk();

for ($i=0; $i < $hd->getCountDisk(); $i++) {

echo "<div id='hdall'>";
echo "<table class='tg'>";

	$name_disk = explode("/dev/", $hd->arr_dev_disk[$i]);
	$name_sdx = $name_disk[1];

	$smt = $hd->getSmartool($name_sdx);	
 	$mountHd = $hd->getMountHd($name_sdx);
 	if ($mountHd == "System") {
 		$systemDisk = 1;
 		$mountHd = "<span style='color:#2ec2d0'>System</span>";
 	} 
 	elseif ($mountHd == "No Mount") {
 		$systemDisk = 0;
 		$mountHd = "<span style='color:#FF0000'>No Mount</span>";
 	}
 	else {
 		$systemDisk = 0;
 		$mountHd = "<span style='color:#5daf48'>".$mountHd."</span>";
 		$cacheDir = $hd->getMountHd($name_sdx);
 	} 	

 ?>  

<?php
	if ($_GET['format'] == trim($hd->arr_dev_disk[$i])) {
		$disk_format = $_GET['format'];
		$check = exec("sudo cat /etc/fstab | grep ".$disk_format." | grep -v grep | wc -l");
		if ($check == 0) {
		echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;'><div style='display:inline-block;' class='icon-widget r-spin'></div> Formating...</div>";
		exec("sudo dd if=/dev/zero of=".$disk_format." bs=1M count=1");
		exec("sudo mkfs.ext4 -F -v -m .1 -b 4096 ".$disk_format."");
		} else {
			echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;display:none;'><div style='display:inline-block;' class='icon-widget r-spin'></div> No se puede formatear! el disco esta montado</div>";			
		}
	?>
	<script>
	$(document).ready(function() { 
		$("#loading").fadeIn("slow", function(){
		    setTimeout(function() { 
		        $('#loading').fadeOut('slow'); 
		        window.location="Mount_Disk"; 
		 	}, 4000); 
		}); 	
	});
	</script>
	<?php	 
	} 
	else if ($_GET['mount'] == trim($hd->arr_dev_disk[$i])) {
		$disk_mount = $_GET['mount'];
		$check = exec("sudo cat /etc/fstab | grep ".$disk_mount." | grep -v grep | wc -l");

		if ($check == 0) {
			$check_cache_dir = exec("sudo cat /etc/fstab | grep '\/usr/local\/raptor\/cache1' | wc -l");
			if ($check_cache_dir == 0) { 
				$new_cache_dir_mount = "/usr/local/raptor/cache1";			
				exec("sudo echo '".$disk_mount." ".$new_cache_dir_mount."  ext4  noatime,async,nosuid  0  0' >> /etc/fstab");
				if (!file_exists($new_cache_dir_mount))
					exec("sudo mkdir ".$new_cache_dir_mount."");													
				exec("sudo mount ".$new_cache_dir_mount."");			
				echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;'><div style='display:inline-block;' class='icon-widget r-spin'></div> Mounting Hard Disk...</div>";
			} else {
				exec("sudo echo '".$disk_mount." ".$new_cache_dir."  ext4  noatime,async,nosuid  0  0' >> /etc/fstab");
				if (!file_exists($new_cache_dir))
					exec("sudo mkdir ".$new_cache_dir."");
				exec("sudo mount ".$new_cache_dir."");
				echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;'><div style='display:inline-block;' class='icon-widget r-spin'></div> Mounting Hard Disk...</div>";				
			}
		} else {
			//if ($check_cache_dirx == 0) {
				echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;'>"." Hard Disk is Mount"."</div>";
			//}
		}
	?>
	<script>
	$(document).ready(function() { 
	    setTimeout(function() { 
	        $('#loading').fadeOut('slow'); 
	        window.location="Mount_Disk"; 
	 	}, 2000);  	
	});
	</script>
	<?php	 
	}
	else if ($_GET['umount'] == trim($hd->arr_dev_disk[$i])) {
			if (del_line($file_in = "/etc/fstab", $disk_umount = $_GET['umount']) == 1) {
				echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;'><div style='display:inline-block;' class='icon-widget r-spin'></div> Umount Hard Disk</div>";
				exec("sudo umount /usr/local/raptor/".$_GET['dirCache']."");
			} else {
				echo "<div id='loading' style='margin-left:20px;margin-bottom:4px;'>"." Not Umount Hard Disk"."</div>";
			}
		?>
	<script>
	$(document).ready(function() { 
	    setTimeout(function() { 
	        $('#loading').fadeOut('slow'); 
	        window.location="Mount_Disk"; 
	 	}, 2000);  	
	});
	</script>
	<?php	 
	}	
	else {
		$hd_stat = "";
	}
	?>
	  <tr>
	  	<th colspan="9" style="width:944px;border-left:none;text-align:left;"><?php echo $smt[0]."&nbsp;&nbsp; Model - ".$smt[1]; ?></th>
	  </tr>
	  <tr>    
	  	<td class="hd_head" style="width:48px;height:22px;width:22px"><div id="lghd_mnt"></div></td>     
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;width: 10%;"><font style="font-size:12px;color:#555;"><strong><?php echo $hd->arr_dev_disk[$i]; ?></strong></font></td> 
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;width: 10%;"><font style="font-size:12px;color:#555;"><strong><?php echo $smt[2]; ?></strong></font></td> 
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;width: 10%;"><?php echo $mountHd; ?></td> 
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;width: 36%;"><?php echo $hd->getUuid($name_sdx); ?></td> 		  	
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;"><?php if($systemDisk < 1) echo "<a class='' href='Mount_Disk?format={$hd->arr_dev_disk[$i]}' ><button><span class='icon-tasks'></span>&nbsp;Format</button></a>"; ?></td>
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;"><?php if($systemDisk < 1) echo "<a class='' href='Mount_Disk?mount={$hd->arr_dev_disk[$i]}' ><button><span class='icon-download-1'></span>&nbsp;Mount</button></a>"; ?></td>
	  	<td class="hd_head" style="border-left: 1px solid #afafaf;"><?php if($systemDisk < 1) echo "<a class='' href='Mount_Disk?umount={$hd->arr_dev_disk[$i]}&dirCache={$cacheDir}' ><button><span class='icon-upload-1'>&nbsp;</span>Umount</button></a>"; ?></td>
	  </tr>  	
	</table>
</div>

<?php 
} 
?>

</div>

	</td></tr>

	<tr><td>&nbsp;</td></tr>	
	
 </table>

<br>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
<script>
  $(function() {
    $( "#conf_txt" ).accordion({
      collapsible: true, 
      active: false
    });
  });
</script>
  <div id="conf_txt" style="margin-bottom:10px;">
    <h3 style="text-align:left;color:#454545;">Mount details</h3>
		<div id="lvmdisplay">
<?php
$fn = "/etc/fstab";
if (isset($_POST['content']))
{
    $content = ($_POST['content']);
    $fp = fopen($fn,"r") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file!");
    fputs($fp,$content);
    fclose($fp) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close the file!");
}
?>
    <textarea style="font-size:12px;" readonly rows="20" name="content"><?php readfile($fn); ?></textarea>
		</div>
  </div>


</div>

<div id="ln"><hr></div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 	

</body>
</html>
