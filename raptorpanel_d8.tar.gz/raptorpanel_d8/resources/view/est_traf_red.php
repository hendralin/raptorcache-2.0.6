<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
    
session_start();
require "global/above.php";

?>

<div id="tbod"> 

    <div class="tab_report">
        <table class="sortable" style="margin-top:8px;border-radius:3px 3px 0 0;" >
            <tr><th colspan=7 class="tabtit"><span class="icon-bar-chart"></span><?php echo $m_trf; ?></th></tr>
            <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
        </table>
        <table id="sorter" class="sortable" cellspacing='0'>
        <tr>
            <td style="margin:0;padding:0;">
                <div id="red">
                    <table> 
                      <tr><td style="padding:0">
                        <iframe style="width:970px;" src="../inc/vns/vns.php" ></iframe>
                      </td></tr>
                    </table>
                </div>
            </td>
        </tr>

        </table>

    </div>

    <div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "global/below.php"; ?>