<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.3
 */
 
require "global/above.php"; 
?>

<div id="tbod"> 

<div class="tab_report">
<table class="sortable" style="margin-top:8px;border-radius:3px 3px 0 0;" >
	<tr><th colspan=7 class="tabtit"><span class="icon-hdd-o"></span>&nbsp;I/O</th></tr>
	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<?php include RP_PATH."/inc/iost.php"; ?>

<tr><td>

<br>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
<script>
  $(function() {
    $( "#conf_txt" ).accordion({
      collapsible: true, 
      active: false
    });
  });
</script>
  <div id="conf_txt" style="margin-bottom:10px;">
    <h3 style="text-align:left;color:#454545;">Help Reporting</h3>
		<div class="lvmdisplay">
      <p><strong>%user</strong><br><?php echo $io_r_user; ?></p>
      <p><strong>%nice</strong><br><?php echo $io_r_nice; ?></p>
      <p><strong>%sys</strong><br><?php echo $io_r_sys; ?></p>
      <p><strong>%iowait</strong><br><?php echo $io_r_iowait; ?></p>
      <p><strong>%idle</strong><br><?php echo $io_r_idle; ?></p>
      <hr>
      <p><strong>%Dev</strong><br><?php echo $io_r_dev; ?></p>
      <p><strong>%tps</strong><br><?php echo $io_r_tps; ?></p>
      <p><strong>%Blk_read/s</strong><br><?php echo $io_r_blk_read_s; ?></p>
      <p><strong>%Blk_wrtn/s</strong><br><?php echo $io_r_blk_wrtn_s; ?></p>
      <p><strong>%Blk_read</strong><br><?php echo $io_r_blk_read; ?></p>
      <p><strong>%Blk_wrtn</strong><br><?php echo $io_r_blk_wrtn; ?></p>
      <p><strong>%kB_read/s</strong><br><?php echo $io_r_kb_read_s; ?></p>
      <p><strong>%kB_wrtn/s</strong><br><?php echo $io_r_kb_wrtn_s; ?></p>
      <p><strong>%kB_read</strong><br><?php echo $io_r_kb_read; ?></p>
      <p><strong>%kB_wrtn</strong><br><?php echo $io_r_kb_wrtn; ?></p>
      <p><strong>%rrqm/s</strong><br><?php echo $io_r_rrqm_s; ?></p>
      <p><strong>%wrqm/s</strong><br><?php echo $io_r_wrqm_s; ?></p>
      <p><strong>%r/s</strong><br><?php echo $io_r_r_s; ?></p>
      <p><strong>%w/s</strong><br><?php echo $io_w_r_s; ?></p>
      <p><strong>%rsec/s</strong><br><?php echo $io_r_rsec_s; ?></p>
      <p><strong>%wsec/s</strong><br><?php echo $io_w_rsec_s; ?></p>
      <p><strong>%rkB/s</strong><br><?php echo $io_r_rkB_s; ?></p>
      <p><strong>%wkB/s</strong><br><?php echo $io_w_rkB_s; ?></p>
      <p><strong>%avgrq-sz</strong><br><?php echo $io_r_avgrq_sz; ?></p>
      <p><strong>%avgqu-sz</strong><br><?php echo $io_r_avgqu_sz; ?></p>
      <p><strong>%await</strong><br><?php echo $io_r_await; ?></p>
      <p><strong>%svctm</strong><br><?php echo $io_r_svctm; ?></p>
      <p><strong>%util</strong><br><?php echo $io_r_util; ?></p>   
		</div>
  </div>
  
	</td></tr>

</div>

<div id="ln"><hr></div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
