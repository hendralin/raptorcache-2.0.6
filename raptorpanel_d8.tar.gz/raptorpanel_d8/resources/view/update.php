 <?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
 
require "global/above.php"; 
?>
	
<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<?php 
$redirect = "
    setTimeout(function() { 
		$('#loading').fadeOut( 'slow', function() {
        	$('.rp_restart').css('display', 'inline-block');
            	setTimeout(function() { 
            		$('.rp_restart').fadeOut( 'slow', function() {
						window.location='Update';
            		});
            	}, 3000);
				});   					        	
 	}, 3000);	
";
if (isset($_GET['core'])) {
	$send_restart = "
	  $.ajax({
	    type: 'POST',
	    url: 'shut_rp.req'
	  });  ";
	if ($_GET['accion'] == "update") {
		$exec_update = "";
		$exec_update = shell_exec("sudo bash /etc/raptor/run.v/up_core_online.sh");
		//echo "<pre>".$rest."</pre>";		
		if ($exec_update != "" || $exec_update != NULL) {
			//if (preg_match("/Update_Core_Finish/", $rest)) {
				echo "<div id='loading'><div class='icon-widget r-spin'></div> Update Core</div>";
				echo "<div id='loading' class='rp_restart'style='display:none;'><div class='icon-widget r-spin'></div> Restarting Raptor</div>";
				echo "<script>
				$(document).ready(function() { 
					{$send_restart}{$redirect}
				});
				</script>";	
			//}	
		} else {
				echo "<div id='error'><div class='icon-widget r-spin'></div> Error Update...</div>";
				echo "<script>case_alert('error', 'Network_Config', '2000');</script>";				
		}
	}
} 
if (isset($_GET['panel'])) {
	if ($_GET['accion'] == "update-panel") {
			$rest = "";
			$rest = shell_exec("sudo bash /etc/raptor/run.v/up_panel_online.sh");
			//echo "<pre>".$rest."</pre>";		
		if ($rest != "" || $rest != NULL) {
			//if (preg_match("/Update_Panel_Finish/", $rest)) {
				echo "<div id='loading'><div class='icon-widget r-spin'></div> Update Webpanel</div>";
				echo "<div id='loading' class='rp_restart'style='display:none;'><div class='icon-widget r-spin'></div> Restarting Raptor</div>";
				echo "<script>
				$(document).ready(function() { 
				    {$redirect}
				});
				</script>";	
			//}	
		} else {
				echo "<div id='error'><div class='icon-widget r-spin'></div> Error Update...</div>";
				echo "<script>case_alert('error', 'Network_Config', '2000');</script>";				
		}
	}
} 
if (isset($_GET['services'])) {
	if ($_GET['accion'] == "update-services") {
			$rest = "";
			$rest = shell_exec("sudo bash /etc/raptor/run.v/up_services_online.sh");
			//echo "<pre>".$rest."</pre>";		
		if ($rest != "" || $rest != NULL) {
			//if (preg_match("/Update_Panel_Finish/", $rest)) {
				echo "<div id='loading'><div class='icon-widget r-spin'></div> Update Services</div>";
				echo "<div id='loading' class='rp_restart'style='display:none;'><div class='icon-widget r-spin'></div> Restarting Raptor</div>";
				echo "<script>
				$(document).ready(function() { 
				    {$redirect}
				});
				</script>";	
			//}	
		} else {
				echo "<div id='error'><div class='icon-widget r-spin'></div> Error Update...</div>";
				echo "<script>case_alert('error', 'Network_Config', '2000');</script>";					
		}
	}
} 
 ?>

<?php 

require 'models/autoload.php';
$rp = new UpdateRp();
$rp->get_host_conection();

?>

<div class="tab_config">
	<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  	<tr><th colspan=7 class="tabtit"><span class="icon-publish"></span> <?php echo "Update"; ?></th></tr>
  	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>

	<table>
		<tr>
			<td>
<?php 

$token = sha1(time());
echo $rp->show_alert_update();
echo "<table class='sortable' cellspacing='0' style='border-radius:2px;width:400px;margin-left:10px;'>";
	echo "<tr>
			<th>Module</th>
			<th>Versi&oacute;n</th>
			<th style='border-right:none;'></th>
			<th style='border-right:none;'></th>
		</tr>";
	echo "<tr class='row'>
			<td style='padding:6px'>"."Core Raptor"."</td>
			<td>{$rp->get_core_up_v()}</td>
			<td class='update'>";
			if ($rp->update_core == true) { 
				echo "<a href='Update?accion=update&core=1&token={$token}' title='update'><span class='icon-cog'></span></a>";
			} else { 
				echo "<span style='opacity:0.4'><span class='icon-cog'></span></span>";
			}
			echo "</td>
			<td class='update'><a id='go' class='coreLog' name='coreLog' href='#coreLog'><span class='icon-file-text-o'></span></a>
			</td></tr>";      
	echo "<tr class='row'>
			<td style='padding:6px'>"."Webpanel Raptor"."</td>
			<td>{$rp->get_panel_up_v()}</td>
			<td class='update'>";        					  
			if ($rp->update_panel == true) { 
				echo "<a href='Update?accion=update-panel&panel=1&token={$token}' title='update'><span class='icon-cog'></span></a>";
			} else { 
				echo "<span style='opacity:0.4'><span class='icon-cog'></span></span>";
			}        					  
			echo "</td>
			<td class='update'><a id='go' class='panelLog' name='panelLog' href='#panelLog'><span class='icon-file-text-o'></span></a>
			</td></tr>";      
	echo "<tr class='row'>
			<td style='padding:6px'>"."Services"."</td>
			<td>{$rp->get_services_up_v()}</td>
			<td class='update'>";        					  
			if ($rp->update_services == true) { 
				echo "<a href='Update?accion=update-services&services=1&token={$token}' title='update'><span class='icon-cog'></span></a>";
			} else { 
				echo "<span style='opacity:0.4'><span class='icon-cog'></span></span>";
			}        					  
			echo "</td>
			<td class='update'><a id='go' class='servicesLog' name='servicesLog' href='#servicesLog'><span class='icon-file-text-o'></span></a>
			</td></tr>";      
echo "</table>";
 ?>
			</td>
		</tr> 			
		<tr>
			<td style="padding-left:20px;text-align:left;">
				<a class="btn-default" href="Update_Manual"><button><span class="icon-triangle-right"></span>&nbsp;Update Manual</button></a>
			</td>
		</tr>		
		<tr><td>&nbsp;</td></tr>		
	</table>

	<div class="coreLogDiv" title="Core changelog"></div>	
	<div class="panelDiv" title="WebPanel changelog"></div>	
	<div class="servicesDiv" title="Services changelog"></div>	


<script>
  $( function() {
  	var coreLog, paneLog, servicesLog,
    coreLog = $( ".coreLogDiv" ).dialog({
      autoOpen: false,
      height: 460,
      width: 488,
      modal: true,
      open: function () {             
                $(".coreLogDiv").load('../global/form/logUpdate.php?log=core');                   
            },       
      buttons: false,
      close: function() {
      }
    }); 
    $( ".coreLog" ).on( "click", function() {
      coreLog.dialog( "open" );
    });   

    paneLog = $( ".panelDiv" ).dialog({
      autoOpen: false,
      height: 460,
      width: 488,
      modal: true,
      open: function () {             
                $(".panelDiv").load('../global/form/logUpdate.php?log=panel');                   
            },       
      buttons: false,
      close: function() {
      }
    }); 
    $( ".panelLog" ).on( "click", function() {
      paneLog.dialog( "open" );
    });  

    servicesLog = $( ".servicesDiv" ).dialog({
      autoOpen: false,
      height: 460,
      width: 488,
      modal: true,
      open: function () {             
                $(".servicesDiv").load('../global/form/logUpdate.php?log=services');                   
            },       
      buttons: false,
      close: function() {
      }
    }); 
    $( ".servicesLog" ).on( "click", function() {
      servicesLog.dialog( "open" );
    });          

  });	
</script>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 



</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
