<?php
/**
 * @author JoeMG http://www.raptorcache.org
 * @copyright 2017 Raptorcache
 * @package Raptorcache
 * @version 1.4
 * @since 1.0
 */

@session_start();
if (isset($_SESSION['user'])) {
	header("location:admin/System");
}

$err = isset($_GET['error']) ? $_GET['error'] : null ;

require "global/lang.php";
require "lang/$deflang.php";

?>
<!DOCTYPE html>

<html lang='es'>
<head>
<link rel="shortcut icon" href="images/favicon.png" />
    <meta charset="UTF-8" /> 
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">      
    <title><?php echo $loginPanel; ?></title>
    <link rel="stylesheet" type="text/css" href="public/css/init.css" />
    <script type="text/javascript" src="public/js/rpengine.js"></script>	    
<style>
	#lang {
	    position: absolute;
	    bottom: 0;
	    right: 0;
	    margin: 15px 20px;
	}
	#lang select {
		color: #9d9e9e;
		background-color: #fff;
		padding: 4px 6px;
		border: 1px solid rgba(0,0,0,0.15);
		border-radius: 2px;
		cursor: pointer;
	}
</style>

<script>	
var x = $(document);
x.ready(ini);

function ini() {
	var x = $('input[type=submit]');
	x.click(loading);
}

function loading() {
	var x = $('.submit-button');
	var y = $('.icon-load');
	x.css("display", "none");
	y.css("display", "flex");
}
</script>

</head>
<body>

<script src="public/js/alrt.js"></script>
<?php 
    if($err == 1){
    	echo "<div id='error' class='login-auth-error' style='display:none'><p>".$cantIdent."</div>";
    	echo "<script>case_alert(\"error\", \"/\", \"1000\");</script>";
    } 
?>

<?php 
if ($_POST['lang'] != "") {       
    $archivo = fopen("global/lang.php","w");    
    $cadena = "<?php
    
\$deflang=\"".$_POST['lang']."\";\r\n
?>
";  
    fputs($archivo,$cadena);     
    fclose($archivo);  
    header("location: index.php");
} 

 ?>

<div id="wrapper">
	<form name="login-form" class="login-form" action="session_init.php" method="post">
		<div class="header">
			<img src="public/images/logo-cache-init.png" >
		</div>	
		<div class="content">
			<input name="usern" type="text" class="input username" placeholder="<?php echo $ident; ?>" />		
			<input name="passwd" type="password" class="input password" placeholder="<?php echo $ident2; ?>" />		
		</div>
		<div class="footer">
			<div class="submit-button" style="display: block;" ><input type="submit" name="submit" value="<?php echo $enter; ?>" /></div>		
			<div class="icon-load" style="display: none; justify-content: center;">
				<div class="spinner">
					<div class="double-bounce1"></div>
					<div class="double-bounce2"></div>
				</div>
			</div>
		</div>	
	</form>
</div>

<div id="lang">
	<form action="admin/lang_change.req" method="POST" name="NombreForm" >
		<input type="hidden" name="init" value="1">
	 	<select name="lang" id="lang" onchange="this.form.submit();">
<?php 
include 'global/lang.php';
if ($deflang == "Spanish") {
	echo "<option value='Spanish'>{$lng_es}&nbsp;</option>";
	echo "<option value='English'>{$lng_en}&nbsp;</option>";
	echo "<option value='Portugues'>{$lng_pt}&nbsp;</option>";	
} else if ($deflang == "English") {
	echo "<option value='English'>{$lng_en}&nbsp;</option>";	
	echo "<option value='Spanish'>{$lng_es}&nbsp;</option>";
	echo "<option value='Portugues'>{$lng_pt}&nbsp;</option>";	
} else if ($deflang == "Portugues") {
	echo "<option value='Portugues'>{$lng_pt}&nbsp;</option>";
	echo "<option value='Spanish'>{$lng_es}&nbsp;</option>";
	echo "<option value='English'>{$lng_en}&nbsp;</option>";	
}
 ?>		 		
		</select>
	</form>	
</div>

</body>
</html>
