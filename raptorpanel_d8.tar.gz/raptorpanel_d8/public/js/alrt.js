  function case_alert(div_alert, redirect, time) { 
  	var x;
  	x = $("#"+div_alert);
    x.fadeIn('slow', function(){
        setTimeout(function() { 
            x.fadeOut('slow', function(){
              window.location = redirect; 
            });           
      }, time);       
    });  
  };