
function restart_rp()
{
  if (confirm('Esta seguro')) {   
    $.ajax({
           async: true,
           type: "POST",
           dataType: "html",        
           contentType: "application/x-www-form-urlencoded",         
           url: "shut_rp.req",
           data: "1",
           beforeSend: initSubmit,
           success: responseMessage,
           timeout: 4000,
           error: submitError
         }); 
    return false;
  }
}

function init()
{
  var x;
  x = $('form button[type=button]');
  x.click(submitForm);
}
function submitForm()
{
  var pathForm = $(this).parent().parent().parent().parent().parent().parent('form');
  var url = pathForm.attr('action');
  var method = pathForm.attr('method');
  var form = pathForm.serialize();
  $.ajax({
           async: true,
           type: method,
           dataType: "html",        
           contentType: "application/x-www-form-urlencoded",
           url: url,
           data: form,
           beforeSend: initSubmit,
           success: responseMessage,
           timeout: 4000,
           error: submitError
         }); 
  return false;
}
function initSubmit()
{
  var x = $("#case_float_alert");
  //x.html('<img src="/public/images/ajax_loader.gif">');
}
function responseMessage(menssage)
{
  $("#case_float_alert").html(menssage); 
}
function submitError()
{
  $("#case_float_alert").text('Problem in the server...');
} 

/**
 * 
 */

function fadeLoad() {
  var x;
  x = $('.float_alert');
  x.fadeIn(1000, fadeOff);
} 

function fadeOff() {
  var x;
  x = $('.float_alert');
  setTimeout(function() {
    x.fadeOut(1000, function() {
      $( ".float_alert" ).remove();
    });
  }, 2000);   
}