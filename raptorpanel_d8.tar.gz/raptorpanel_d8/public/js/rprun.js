
 $(document).ready(function act() {
   if ($("#sys_state").length > 0) {  
      setInterval(function vital() {
         $("#sys_state").load('../inc/sys_state.php');
      }, 6807);
      setInterval(function bandwd() {
         $("#value_bandwd").load('../inc/bdw.php');
      }, 3317);      
      setInterval(function gmem() {
         $("#memory").load('../inc/mmry.php');
      }, 13000);
      setInterval(function ghddisk() {
         $("#hard_disk_system").load('../inc/hds.php');
      }, 17000); 
   }   

   else if ($("#hard_disk_view").length > 0) { 
      setInterval(function ghal() {
         $("#hard_disk_view").load('../inc/hd.php');
      }, 4000);
   }   

   else if ($("#log_ajx_acc").length > 0) { 
      setInterval(function log() {
         $("#log_ajx_acc").load('../inc/logs_rp_acc.php');
      }, 4000);
   } 

   else if ($("#log_ajx_https").length > 0) { 
      setInterval(function log() {
         $("#log_ajx_https").load('../inc/logs_rp_https.php');
      }, 4000);
   }     

   else if ($("#ping_dns").length > 0) { 
      setInterval(function pdns() {
         $("#ping_dns").load('../inc/ping_dns.php');
      }, 2000);
   } 

   else if ($("#io").length > 0) {
      setInterval(function io() {
         $("#io").load('../inc/iost.php');
      }, 2000);
   }     

   $.ajaxSetup({ cache: false });   
});
