<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */

include "main/auth.php";
include "main/settings.php";
//include "main/functions.php";
require "global/lang.php";
require "lang/$deflang.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $wpv; ?></title>       
	<meta name="charset" content="utf-8" />
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">    
	<link rel="shortcut icon" href="<?php echo get_view_link(); ?>/images/favicon.png" />       
    <link rel="Stylesheet" href="<?php echo get_view_link(); ?>/css/normalize.css" type="text/css">
    <link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/style.css" type="text/css" /> 
    <link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/raptor.css" type="text/css" />
    <script type="text/javascript" src="<?php echo get_view_link(); ?>/js/rpengine.js"></script>	
    <script type="text/javascript" src="<?php echo get_view_link(); ?>/js/rprun.js"></script>

<script type="text/javascript">
  function closePanel() {
    if(confirm("Exit the WebPanel?")) {
      window.location = 'Exit';
    } else {
      return false;
    }
  } 
</script>
</head>

<body>

<div id="all"><!-- ALL -->  

  <div id="headerTop">
    <div class="contTopLeft"> 
        <div id="logoTopLeft"></div>
    </div>
    <div class="contTopRight">
      <ul class="infoUser">
        <li><div id="logoTopRight"></div>&nbsp;<?php echo "v.".$verwp; ?></li>    
        <li><span style="font-size: 1em;" class="icon-user"></span>&nbsp;<?php echo $_SESSION['user']; ?></li>    
        <li><?php echo name_distri(); ?> / <?php echo date('d-m-Y  h:i a'); ?></li>    
        <li><?php echo proc(); ?>&nbsp;-&nbsp;<?php echo num_proc(); ?>&nbsp;cores&nbsp;<?php echo arquitect(); ?> &nbsp;/&nbsp;<?php echo sizeFormat(mem_total()); ?>&nbsp;RAM</li>    
      </ul>
    </div>
  </div>

<nav>
  <ul id="nav">
      <li class="top" ><a href="Getpage?url_link=System"  class="top_link" ><span><?php echo $m_sys; ?></span></a></li>

        <li class="top" ><a href="#"  class="top_link"><span class="down"><?php echo $m_est; ?></span></a>
      <ul class="sub">
        <li><a href="Getpage?url_link=Domains"><?php echo $m_dom; ?></a></li>    
        <li><a href="Getpage?url_link=Storage"><?php echo $m_alm; ?></a></li>                       
        <li><a href="Getpage?url_link=Request"><?php echo $m_ahr; ?></a></li>                       
        <li><a href="Getpage?url_link=Threads"><?php echo "&nbsp;&nbsp;Threads"; ?></a></li>                       
        <li><a href="Getpage?url_link=Network_Traffic"><?php echo $m_trf; ?></a></li>                        
        <li><a href="Getpage?url_link=SSL">&nbsp;&nbsp;HTTPS</a></li>                   
        <li><a href="Getpage?url_link=SUMMARY_SSL"><?php echo '&nbsp;&nbsp;'.$vns_res.' HTTPS'; ?></a></li>                   
        <li><a href="Getpage?url_link=SUMMARY_HTTP"><?php echo '&nbsp;&nbsp;'.$vns_res.' HTTP'; ?></a></li>                   
      </ul>
        </li>

<?php if($_SESSION['idprofile']==1) echo ' 
    <li class="top" ><a href="#"  class="top_link"><span class="down">Raptor</span></a>
      <ul class="sub">
        <li><a href="Getpage?url_link=Raptor_Conf">&nbsp;&nbsp;Raptor.conf</a></li>
        <li><a href="Getpage?url_link=Raptor_List">'.$m_listpl.'</a></li>                         
        <li><a href="Getpage?url_link=Raptor_WhiteList">&nbsp;&nbsp;Whitelist</a></li>                                          
        <li><a href="Getpage?url_link=Raptor_BlackList">&nbsp;&nbsp;Blacklist</a></li>              
        <li><a href="Getpage?url_link=Raptor_Firewall">&nbsp;&nbsp;Firewall</a></li>                          
      </ul>
    </li>';
?>    
           
<?php if($_SESSION['idprofile']==1) echo ' 
    <li class="top"><a href="#" class="top_link"><span class="down">Squid</span></a>
      <ul class="sub">
        <li><a href="Getpage?url_link=Squid_Conf">&nbsp;&nbsp;Squid.conf</a></li>                             
      </ul>
    </li>';
?>    

    <li class="top" ><a href="#" class="top_link"><span class="down"><?php echo $m_util; ?></span></a>                     
        <ul class="sub">
        <li><a href="#" ><?php echo $m_dd; ?><span style="padding-left:38px;"><span class="icon-caret-right"></span></span></a>
          <ul>
            <li><a href="Getpage?url_link=Monitor_Hard_Disk" >&nbsp;&nbsp;<?php echo $hd_monitoring; ?></a></li>            
            <li><a href="Getpage?url_link=Monitor_Hard_Disk_IO" >&nbsp;&nbsp;<?php echo "I/O"; ?></a></li>            
          </ul>
        </li>          
        <li><a href="Getpage?url_link=Log_Access_HTTP" >&nbsp;&nbsp;Logs</a></li>      
        <li><a href="Getpage?url_link=Num_Conection_Users" ><?php echo $m_nconex; ?></a></li>
        <li><a href="Getpage?url_link=Ping_DNS" >&nbsp;&nbsp;Ping DNS</a></li>                    
        <li><a href="Getpage?url_link=Backup_Database" >&nbsp;&nbsp;Backup BD</a></li>                    
        <?php if($_SESSION['idprofile']==1) echo '<li><a href="Getpage?url_link=Update" >&nbsp;&nbsp;Update</a></li>'; ?>         
        <li><a href="Getpage?url_link=Licence" >&nbsp;&nbsp;Licence</a></li>            
        <?php if($_SESSION['idprofile']==1) echo '<li><a href="Getpage?url_link=Shutdown">&nbsp;&nbsp;Shutdown</a></li>'; ?>                
      </ul> 
    </li>                                                               

<?php if($_SESSION['idprofile']==1) echo '                      
        <li class="top" ><a href="#" class="top_link"><span class="down">'.$m_config.'</span></a>
            <ul class="sub">
              <li><a href="Getpage?url_link=Network_Config">&nbsp;&nbsp;Network</a></li>
              <li><a href="Getpage?url_link=DNS_Config">&nbsp;&nbsp;DNS</a></li>
              <li><a href="Getpage?url_link=Mount_Disk" >&nbsp;&nbsp;Mount Disk</a></li>
              <li><a href="Getpage?url_link=Scheduler" >&nbsp;&nbsp;Scheduler</a></li>          
              <li><a href="Getpage?url_link=Mikrotik_List" >&nbsp;&nbsp;Mikrotik List</a></li>              
              <li><a href="Getpage?url_link=Users_Config" >&nbsp;'.$vit_us.'</a></li>
              <li><a href="Getpage?url_link=Language_Config" >'.$m_lang.'</a></li>
            </ul>
        </li>';
?>        
                     
        <li class="top" ><a href="#" onclick="closePanel();" class="top_link"><span><?php echo $m_exit; ?></span></a></li>

  </ul>
</nav>
