<?php 
if (isset($_GET['locat_route'])) {
  $locat_route = $_GET['locat_route'];
} else {
  header('Location: '.'Raptor_Firewall');  
}
if (isset($_GET['location'])) {
  $location = $_GET['location'];
} 
 ?>

  <form id="newRuleForm" action="mod_lst.req" method="POST">
    <table class="tab_modal in-large" cellspacing='0'>     
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td><input id="new_regex" type="hidden" name="new_regex" value="" /></td></tr>
      <tr><td><input id="location" type="hidden" name="location" value="<?php echo $location; ?>" /></td></tr>
      <tr><td><input id="file" type="hidden" name="file" value="<?php echo $locat_route; ?>" /></td></tr>
      <tr><td class="lb-in-large">Name:&nbsp;&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input style="min-width: 820px;width: 100%;height: 20px;" id="name" type="text" name="name" value="" required></td></tr>
      <tr><td class="lb-in-large">Rule:&nbsp;&nbsp;</td><td class="in-large"><input style="min-width: 820px;width: 100%;height: 20px;" id="nameregex" name="nameregex" value="" required></td></tr>        
    </table>
  </form>
 