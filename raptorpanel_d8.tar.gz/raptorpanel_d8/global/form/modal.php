<script>

  $( function() {
    var editRule, newRuleDiv, firRuleDiv, addDomDiv, form,
      emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
      name = $( "#name" ),
      nameRegex = $( "#nameregex" ),
      email = $( "#email" ),
      password = $( "#password" ),
      allFields = $( [] ).add( name ).add( email ).add( password ),
      tips = $( ".validateTips" );
 
    function updateTips( t ) {
      tips
        .text( t )
        .addClass( "ui-state-highlight" );
      setTimeout(function() {
        tips.removeClass( "ui-state-highlight", 1500 );
      }, 500 );
    }
 
/*    function checkLength( o, n, min, max ) {
      if ( o.val().length > max || o.val().length < min ) {
        o.addClass( "ui-state-error" );
        updateTips( "Length of " + n + " must be between " + min + " and " + max + "." );
        return false;
      } else {
        return true;
      }
    } */
 
    function checkRegexp( o, regexp, n ) {
      if ( !( regexp.test( o.val() ) ) ) {
        o.addClass( "ui-state-error" );
        updateTips( n );
        return false;
      } else {
        return true;
      }
    }
 
    function addUser() {
      var valid = true;
      allFields.removeClass( "ui-state-error" );
/*    valid = valid && checkLength( name, "username", 3, 16 );
      valid = valid && checkLength( email, "email", 6, 80 );
      valid = valid && checkLength( password, "password", 5, 16 );*/
 
/*      valid = valid && checkRegexp( name, /^[a-z]([0-9a-z_\s])+$/i, "Username may consist of a-z, 0-9, underscores, spaces and must begin with a letter." );
      valid = valid && checkRegexp( email, emailRegex, "eg. ui@jquery.com" );
      valid = valid && checkRegexp( password, /^([0-9a-zA-Z])+$/, "Password field only allow : a-z 0-9" );*/
 
      if ( valid ) {
        //$("#newRuleForm").submit();
        // window.location.href = 'newPage.html';
        //dialog.dialog( "close" );
      }
      return valid;
    } 

    editRule = $( ".editRuleDiv" ).dialog({
      autoOpen: false,
      height: 192,
      width: 930,
      modal: true,
      open: function () {            	
                var locat_route, location;
                  locat_route = "<?php echo $file_route; ?>";
                  location = "<?php echo $location; ?>";
                $(".editRuleDiv").load('../global/form/editRule.php?id='+dat+'&locat_route='+locat_route+'&location='+location);                   
            },
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#namerule').val() || !$('#rule').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#editRuleForm").submit();
          }      
        } 
      },
      close: function() {
/*        form[ 0 ].reset();*/
        allFields.removeClass( "ui-state-error" );
      }
    }); 
/*    form = editRule.find( "form" ).on( "submit", function( event ) {
      event.preventDefault();
      addUser();
    });*/ 
    $( ".editRule" ).on( "click", function() {
      editRule.dialog( "open" );
    });

    newRuleDiv = $( ".newRuleDiv" ).dialog({
      autoOpen: false,
      height: 192,
      width: 930,
      modal: true,
      open: function () {             
                var locat_route, location;
                  locat_route = "<?php echo $file_route; ?>";
                  location = "<?php echo $location; ?>";
                $(".newRuleDiv").load('../global/form/newRule.php?locat_route='+locat_route+'&location='+location);                   
            },      
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val() || !$('#nameregex').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#newRuleForm").submit();
          }       
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".newRule" ).on( "click", function() {
      newRuleDiv.dialog( "open" );
    });

    firRuleDiv = $( ".firRuleDiv" ).dialog({
      autoOpen: false,
      height: 256,
      width: 284,
      modal: true,
      open: function () {             
                $(".firRuleDiv").load('../global/form/firRule.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val() || !$('#src').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#firRuleForm").submit();
          }          
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".firRule" ).on( "click", function() {
      firRuleDiv.dialog( "open" );
    });    

    addDomDiv = $( ".addDomDiv" ).dialog({
      autoOpen: false,
      height: 192,
      width: 284,
      modal: true,
      open: function () {    
                var locat_route, location;
                  locat_route = "<?php echo $file_route; ?>";
                  location = "<?php echo $location; ?>";
                $(".addDomDiv").load('../global/form/addDom.php?locat_route='+locat_route+'&location='+location);                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val() || !$('#domain').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#addDomForm").submit();
          }          
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".addDomain" ).on( "click", function() {
      addDomDiv.dialog( "open" );
    });     

  });

</script>