<?php 
if (isset($_GET['id'])) {
  $val = $_GET['id'];
} else {
  header('Location: '.'Raptor_Firewall');
}
if (isset($_GET['locat_route'])) {
  $locat_route = $_GET['locat_route'];
} else {
  header('Location: '.'Raptor_Firewall');  
}
if (isset($_GET['location'])) {
  $location = $_GET['location'];
} 
$rule = file_get_contents($locat_route);
$rule = explode("\n", $rule);
$rule = trim($rule[($val)]);
$rule = explode("#name#", $rule);
$disRule = substr($rule[0],0,5);

if ($disRule == "##-##") {
  $ruleDis = explode("-##", $rule[0]);
  $rule[0] = $ruleDis[1];
} 
 ?>

  <form id="editRuleForm" action="mod_lst.req" method="GET">
    <table class="tab_modal in-large" cellspacing='0'>
      <tr><td><input id="idrule" type="hidden" name="idrule" value="<?php echo $val; ?>" /></td></tr>
      <tr><td><input id="edit_regex" type="hidden" name="edit_regex" value="" /></td></tr>
      <tr><td><input id="location" type="hidden" name="location" value="<?php echo $location; ?>" /></td></tr>
      <tr><td><input id="file" type="hidden" name="file" value="<?php echo $locat_route; ?>" /></td></tr>
      <tr><td class="lb-in-large">Name:&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input id="namerule" style="min-width: 820px;width: 100%;height: 20px;" type="text" name="namerule" value="<?php echo $rule[1]; ?>" required/></td></tr>
      <tr><td class="lb-in-large">Rule:&nbsp;</td><td class="in-large"><input id="rule" style="min-width: 820px;width: 100%;height: 20px;" type="text" name="rule" value="<?php echo $rule[0]; ?>" required/></td></tr>         
    </table>
  </form>


