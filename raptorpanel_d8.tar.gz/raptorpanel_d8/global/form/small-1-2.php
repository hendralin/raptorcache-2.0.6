<?php 
if (!function_exists('num_eth')) {
	require_once "../../main/functions.php";
}	
?>
  <form action="network_add_dns.req" method="POST" id="small-1-2-Form" name="small-1-2-Form">
    <table class="tab_modal" cellspacing='0'>
		<tr><td>&nbsp;</td><td>&nbsp;<input type="hidden" id="dns1" name="dns1" value="<?php echo ip_dns_lo(); ?>" ></td></tr>     
		<tr><td><span>DNS 1:</span>&nbsp;&nbsp;</td><td><input id="dns2" type="text" name="dns2" placeholder="8.8.8.8" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>	
				<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 			 
		<tr><td><span>DNS 2:</span>&nbsp;&nbsp;</td><td><input id="dns3" type="text" name="dns3" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>
    </table>
  </form>

<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>