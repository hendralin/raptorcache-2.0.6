<?php 
require_once "../../global/lang.php";
require_once "../../lang/$deflang.php";
 ?>
	<form action="users.req" method="POST" id="newUserForm" name="newUserForm">
		<table class="tab_modal" cellspacing='0'>			
  			<tr><td>&nbsp;</td><td><input id="new_user_form" type="hidden" name="new_user_form" value="" /></td></tr> 
			<tr>
				<td><?php echo $pu_user; ?>&nbsp;</td>
				<td><input id="userName" name="userName" value="" required/></td>
			</tr>
			<tr><td>&nbsp;</td><td></td></tr>
			<tr>
				<td><?php echo $pu_pass; ?>&nbsp;</td>
				<td><input type="password" id="pass" name="pass" value="" required/></td>			
			</tr>
			<tr><td>&nbsp;</td><td></td></tr>			
			<tr>
				<td><?php echo $pu_user_profile; ?>&nbsp;</td>
		        <td>
		          <select name="perfil" id="perfil">
		            <option value="1">Admin</option>
		            <option value="2">Invitado</option>
		          </select>
		        </td>
			</tr>
			<tr><td>&nbsp;</td><td></td></tr>			
			<tr>
				<td>E-mail:&nbsp;</td>
				<td><input id="mail" name="mail" value="" /></td>
			</tr>
		</table>
	</form>