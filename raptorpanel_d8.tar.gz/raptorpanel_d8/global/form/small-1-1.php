  <form action="sqconf.req" method="POST" id="small-1-1-Form" name="small-1-1-Form">
    <table class="tab_modal" cellspacing='0'>
      <tr><td>&nbsp;</td><td>&nbsp;<input type="hidden" id="acl_submit" name="acl_submit" ></td></tr>       
      <tr><td>CIDR:&nbsp;</td><td><input id="acl_ln" type="text" name="acl_ln" placeholder="0.0.0.0/0" required /></td></tr> 
    </table>
  </form>