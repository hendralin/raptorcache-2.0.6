  <form action="mk_u_list_arm.req" method="POST" id="newUserForm" name="newUserForm">
    <table class="tab_modal in-short" style="border-radius: 3px;" cellspacing='0'>
      <tr><td>&nbsp;</td><td></td></tr>
      <tr><td><input id="add_user_mk" type="hidden" name="add_user_mk" value="add_user_mk" /></td></tr>
      <tr><td class="in-short">Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td><td class="in-medium"><input id="user_mk_list" type="text" name="user_mk_list" value="" required /></td></tr>
      <tr><td>&nbsp;</td><td></td></tr>
      <tr><td class="in-short">IP:</td><td class="in-medium"><input id="ip_mk_list" type="text" name="ip_mk_list" value="" placeholder="0.0.0.0" required /></td></tr>         
    </table>
  </form>