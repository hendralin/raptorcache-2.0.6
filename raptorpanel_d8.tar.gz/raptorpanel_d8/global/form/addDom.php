<?php 
if (isset($_GET['locat_route'])) {
  $locat_route = $_GET['locat_route'];
} else {
  header('Location: '.'Raptor_Firewall');  
}
if (isset($_GET['location'])) {
  $location = $_GET['location'];
} 
 ?>

	<form id="addDomForm" action="mod_lst.req" method="POST">
		<table class="tab_modal in-short" cellspacing='0'>		 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><input id="add_domain" type="hidden" name="add_domain" value="" /></td></tr>
			<tr><td><input id="location" type="hidden" name="location" value="<?php echo $location; ?>" /></td></tr>
			<tr><td><input id="file" type="hidden" name="file" value="<?php echo $locat_route; ?>" /></td></tr>
			<tr><td class="in-short">Name Rule:&nbsp;</td><td><input id="name" type="text" name="name" value="" required/></td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Domain:&nbsp;</td><td><input id="domain" type="text" name="domain" value="" placeholder="example.com" required/></td></tr>									 
		</table>
	</form>
