<?php 
require_once "../../global/lang.php";
require_once "../../lang/$deflang.php";

if (!function_exists('num_eth')) {
	require_once "../../main/functions.php";
}
 ?>

	<form action="network_add_br.req" method="POST" id="addBrForm" name="addBrForm">
		<table class="tab_modal in-short" cellspacing='0'>
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr>
				<td><?php echo "Eth 1"; ?></td>
				<td>
					<select name="interface_1" id="interface_1">
						<option value=""></option>
						<?php num_eth(); ?>
					</select>					
				</td>	
			</tr>	
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr>
				<td><?php echo "Eth 2"; ?></td>
				<td>
					<select name="interface_2" id="interface_2">
						<option value=""></option>
						<?php num_eth(); ?>
					</select>					
				</td>	
			</tr>
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><input id="name" type="hidden" name="enviar_regex"value="" /></td></tr>
			<tr><td><span>IP:</span></td><td><input id="ip" type="text" name="ip" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><span>Netmask:</span></td><td><input id="netmask" type="text" name="netmask" value="" placeholder="255.255.255.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><span>Network:</span></td><td><input id="network" type="text" name="network" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><span>Broadcast:</span></td><td><input id="broadcast" type="text" name="broadcast" value="" placeholder="0.0.0.255" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><span>Gateway:</span></td><td><input id="gateway" type="text" name="gateway" value="" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>
		</table>
	</form>

<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>
