<?php 
require_once "../../global/lang.php";
require_once "../../lang/$deflang.php";

if (!function_exists('num_eth')) {
	require_once "../../main/functions.php";
}
 ?>

<form action="network_add_gw.req" method="POST" id="addGwForm" name="addGwForm">
	<table class="tab_modal in-short" cellspacing='0'>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
		<tr>
			<td><?php echo $net_iface. " 1 "; ?>&nbsp;&nbsp;</td>
			<td>
				<select name="interface_1" id="interface_1">
					<option value=""></option>
					<?php num_eth(); ?>
				</select>					
			</td>	
		</tr>		
		<tr><td><input id="name" type="hidden" name="enviar_regex" value="" /></td></tr>
		<tr><td><span>IP:</span></td><td><input id="ip_1" type="text" name="ip_1" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Netmask:</span></td><td><input id="netmask_1" type="text" name="netmask_1" value="" placeholder="255.255.255.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Network:</span></td><td><input id="network_1" type="text" name="network_1" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Broadcast:</span></td><td><input id="broadcast_1" type="text" name="broadcast_1" value="" placeholder="0.0.0.255" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Gateway:</span></td><td><input id="gateway_1" type="text" name="gateway_1" value="" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 	 
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 

		<tr>
			<td><?php echo $net_iface. " 2 "; ?>&nbsp;&nbsp;</td>
			<td>
				<select name="interface_2" id="interface_2">
					<option value=""></option>
					<?php num_eth(); ?>
				</select>					
			</td>	
		</tr>		
		<tr><td><input id="name" type="hidden" name="enviar_regex" value="" /></td></tr>
		<tr><td><span>IP:</span></td><td><input id="ip_2" type="text" name="ip_2" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Netmask:</span></td><td><input id="netmask_2" type="text" name="netmask_2" value="" placeholder="255.255.255.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Network:</span></td><td><input id="network_2" type="text" name="network_2" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
		<tr><td><span>Broadcast:</span></td><td><input id="broadcast_2" type="text" name="broadcast_2" value="" placeholder="0.0.0.255" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 		 
	</table>				
</form>

<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>