
	<form id="firRuleForm" action="mod_lst.req" method="POST">
		<table class="tab_modal in-short" cellspacing='0'>		 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><input id="filter_rule" type="hidden" name="filter_rule" value="" /></td></tr>
			<tr><td><input id="location" type="hidden" name="location" value="Raptor_Firewall" /></td></tr>
			<tr><td><input id="file" type="hidden" name="file" value="/etc/raptor/fw.sh" /></td></tr>
			<tr><td class="in-short">Name Rule:&nbsp;</td><td><input id="name" type="text" name="name" value="" required/></td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Chain:&nbsp;</td><td>
				<select name="chain" id="chain">
					<option value="INPUT" select>INPUT</option>
					<option value="OUTPUT">OUTPUT</option>
					<option value="FORWARD">FORWARD</option>
				</select>
			</td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Src. Address:&nbsp;</td><td><input id="src" type="text" name="src" value="" placeholder="0.0.0.0/0" required/></td></tr>		
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Action:&nbsp;</td><td>
				<select name="action" id="action">
					<option value="ACCEPT" select>ACCEPT</option>
					<option value="DROP">DROP</option>
				</select>
			</td></tr>								 
		</table>
	</form>
