<?php 
require_once "../../global/lang.php";
require_once "../../lang/$deflang.php";

session_start(); 
require '../../class/Database.php';
require '../../class/Sanitize.php';
require '../../models/User.php';

$db = Database::getInstance();
$db->getConnection();

$sql = "SELECT * FROM user;";
$user = $db->execute($sql);


 ?>	
	<form action="users.req" method="POST" id="changePassForm" name="changePassForm">
		<table class="tab_modal" cellspacing='0'>
			<tr><td>&nbsp;</td><td><input id="change_user_form" type="hidden" name="change_user_form" value="" /></td></tr> 
			<tr>
				<td><?php echo $pu_user; ?>&nbsp;</td>
				<td>
					<select name="user" id="user">
						<option value=""></option>
					<?php 
						while ($row = mysqli_fetch_array($user)) {
							echo "<option value='".$row['loginUser']."'>".$row['loginUser']."</option>";
						}
					 ?>
					</select>
				</td>
			</tr>
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr>			
			<tr><td><?php echo $pu_change_pw_l; ?>&nbsp;</td><td><input id="oldpass" name="oldpass" type="password"/></td></tr>
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr>			
			<tr><td><?php echo $pu_change_pw_n; ?>&nbsp;</td><td><input id="newpass" name="newpass" type="password"/></td></tr>					 
		</table>
	</form>