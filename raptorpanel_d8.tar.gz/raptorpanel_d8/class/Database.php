<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

class Database {	
	private $_connection;
	private $_result;
	private static $_instance; //The single instance
	private $_host;
	private $_username;
	private $_password;
	private $_database;

	public static function getInstance() {
		if(!self::$_instance) { // If no instance then make one
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	private function __construct() {
		require 'config.php';
		$this->_host = $DBHOST;
		$this->_database = $DBNAME;	
		$this->_username = $DBUSER;
		$this->_password = $DBPASS;		
		$this->_connection = new mysqli($this->_host, $this->_username, 
			$this->_password, $this->_database);
	
		// Error handling
		if(mysqli_connect_error()) {
			trigger_error("Failed to conencto to MySQL: " . mysql_connect_error(),
				 E_USER_ERROR);
		}
	}

	private function __clone() { }

	public function getConnection() {
		return $this->_connection;
	}

	public function execute($sql)
	{
		return $this->_result = mysqli_query($this->_connection, $sql);
	}

	public function disconnectDB()
	{
		return mysqli_close($this->_connection);
	}

}

?>