<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.4.4
 */

	$BDTYPE = 'mysqli';
	$DBHOST = 'localhost';
	$DBNAME = 'raptor';
	$DBUSER = 'root';
	$DBPASS = 'raptor';

 ?>