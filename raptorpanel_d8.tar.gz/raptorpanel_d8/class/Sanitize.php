<?php 

class Sanitize 
{
	private $result;
	private $quotes;

	public function string_sanitize($string) 
	{
		$this->result = stripslashes($string);
		$this->quotes = array('\'', '"', '%');
		$this->result = str_replace($this->quotes, '', $this->result);
		$this->result = filter_var($this->result, FILTER_SANITIZE_STRING);
		return $this->result;
	}
}

 ?>