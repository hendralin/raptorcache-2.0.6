<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

require 'class/Database.php';
require 'class/Sanitize.php';

spl_autoload_register(function ($className) {
	if (file_exists("models/". $className . '.php')) {
		include "models/". $className . '.php';
	} 		   
});

$db = Database::getInstance();
$db->getConnection();
$user = new User($db);
$user->loginUser();
$db->disconnectDB();

?>