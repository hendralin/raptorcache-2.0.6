<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
error_reporting(0);

  $lang = "es";
  
  $listMont = array("","Ene.","Feb.","Marzo","Abril","Mayo","Junio","Julio","Ago.","Sept","Oct.","Nov.","Dic.");
  $listWeek = array("","Mon"=>"Lunes","Tue"=>"Martes","Wed"=>"Miércoles","Thu"=>"Jueves","Fri"=>"Viernes","Sat"=>"Sábado","Sun"=>"Domingo");

  $mysqlErr ="No se pudo establecer conexi&oacute;n con la Base de Datos.";

  $dia = array();
  
  $loginPanel        ="Login RaptorPanel";    
  $ident             ="Usuario";    
  $ident2            ="Contrase&ntilde;a";
  $ident3            ="";
  $prof              ="Perfil";
  $cantIdent         ="Usuario o contrase&ntilde;a incorrecta";         
  $identProblem1     ="Servidor inaccesible.";
  $identProblem2     ="Problema técnico."; 
  $identProblem3     ="Connection to LDAP server could not be established.";
  $enter             ="Entrar";

  $mysqlProblem1     ="No se pudo establecer conexi&oacute;n con la Base de Datos.";

  $loading           ="Cargando...";  

  $user              ="Usuario:";
//
  $m_sys             ="Sistema";
  $m_sys_cpu         ="CPU Usage";
  $m_sys_hd          ="Hard Disk";
  $m_sys_mem         ="Mem. RAM";
  $m_sys_red         ="Traf. RED";
//
  $m_est             ="&nbsp;&nbsp;Estad&iacute;sticas&nbsp;";
  $m_dom             ="&nbsp;&nbsp;Dominios&nbsp;";
  $m_ext             ="&nbsp;&nbsp;Extensiones&nbsp;";
  $m_alm             ="&nbsp;&nbsp;Almacenamiento&nbsp;";
  $m_ahr             ="&nbsp;&nbsp;Ahorro&nbsp;";
  $m_trf             ="&nbsp;&nbsp;Tr&aacute;fico de Red&nbsp;";
  $m_res             ="&nbsp;&nbsp;Resumen Total&nbsp;";
  $m_listpl          ="&nbsp;&nbsp;Raptor list&nbsp;";
  $m_onfpl           ="&nbsp;&nbsp;On / Off Plugins&nbsp;";
  $m_statepl         ="&nbsp;&nbsp;Ult. Activ. plugin&nbsp;";
  $m_cc              ="&nbsp;&nbsp;Contenido cach&eacute&nbsp;";
  $m_ud              ="&nbsp;&nbsp;Url denegados&nbsp;";
  $m_util            ="Utilitarios&nbsp;";
  $m_dd              ="&nbsp;&nbsp;Discos Duros&nbsp;";
  $m_nconex          ="&nbsp;&nbsp;N&deg; Conex. por IP&nbsp;";
  $m_ajus            ="Ajustes&nbsp;";
  $m_config          ="Configuraci&oacute;n&nbsp;";
  $m_lang            ="&nbsp;&nbsp;Language&nbsp;";
  $m_reg             ="Registro&nbsp;";
  $m_titlg           ="&nbsp;&nbsp;Enter your Language&nbsp;";
  $m_clg             ="&nbsp;&nbsp;Language:&nbsp;";
  $m_exit            ="&nbsp;&nbsp;Salir&nbsp;";
//
  $lang_rp           = "Espa&ntilde;ol";
//  
  $rp_repdate        ="Almacenamiento por D&iacute;as";
  $rp_repdreq        ="Ahorro por D&iacute;as";
  $rp_repdtrd        ="Threads por D&iacute;as";
  $rp_repext         ="Extensiones";
  $rp_reptot         ="Resumen Total";

  $rp_date           ="Fecha";
  $rp_files          ="Archivos";
  $rp_size           ="Tama&ntildeo";
  $rp_eco            ="Ahorro";
  $rp_hits           ="Hits";
  $rp_porcent        ="Eficacia";
  $rp_domain         ="Dominio";
  $rp_ext            ="Ext";
  $rp_ico            ="Ico";

  $rp_edidc          ="Directorio Cach&eacute";  
  $rp_edilc          ="L&iacute;mite Cach&eacute";  
  $rp_edmin          ="Min. Object Size";  
  $rp_edmax          ="Max. Object Size";  
  $rp_edyes          ="Si";  
  $rp_edno           ="No";  
//  
  $mem_memram        ="Memoria RAM";
  $mem_mt            ="Memoria Total";
  $mem_mu            ="Memoria Usada";
  $mem_ml            ="Memoria Libre";
  $mem_mp            ="Memoria Compart.";
  $mem_mb            ="Memoria Buffers";
  $mem_mc            ="Memoria Cach&eacute";
  $mem_st            ="Swap Total";
  $mem_su            ="Swap Usado";
  $mem_sl            ="Swap Libre";
//  
  $red_tr            ="Tr&aacute;fico de RED";
//  
  $vit_er            ="&nbsp;Estado de Raptor";
  $vit_es            ="&nbsp;Estado de Squid";
  $vit_con           ="&nbsp;Conexiones";
  $vit_us            ="&nbsp;Usuarios";
  $vit_dns           ="&nbsp;DNS Cach&eacute;";
  $vit_tact          ="&nbsp;Tiempo Activo";
  $vit_temp          ="&nbsp;Temperatura";
//
  $sysdisk           ="Espacio de Almacenamiento - RaptorCache";
  $sysdisk_nd        ="N&deg; Discos";
  $sysdisk_dsk       ="Disco";
  $sysdisk_smart     ="S.M.A.R.T.";
  $sysdisk_mod       ="Modelo ";
  $sysdisk_sp        ="Espacio ";
  $sysdisk_temp      ="Temp.";
  $sysdisk_cdir      ="Cach&eacute; Dir.";
  $sysdisk_et        ="Espacio Total ";
  $sysdisk_eu        ="Espacio Usado ";
  $sysdisk_el        ="Espacio Libre ";
  $sysdisk_oc        ="Obj. en Cach&eacute;";
  $sysdisk_u         ="% Usado";
  $sysdisk_l         ="% Libre";
//
  $sq_al_ac          ="Actualizar";
  $sq_den            ="Sitios Web Bloqueados";
  $rp_al_ac          ="Actualizar";
  $rp_actdes         ="Activar o Desactivar plugins";
  $hlp_ej            ="Para desactivar un plugin agregar <strong> # </strong> al inicio del regex, por ej.";
  $backup_bd         ="Backup Base de Datos";
  $c_user            ="Cambiar su Usuario y Password RaptorPanel";
  $hlp               ="Ayuda";
  $bt_agr            ="Agregar";
  $bt_act            ="Actualizar";
  $bt_agr_ip         ="Agregar IP";
  $bt_grd            ="Guardar";
  $bt_re             ="Reiniciar";
//  
  $vns_res           ="Resumen";
  $vns_hr            ="Horas";
  $vns_d             ="D&iacute;as";
  $vns_m             ="Meses";
  $vns_res2          ="Resumen";
  $vns_t10           ="Top 10 Dias";
  $vns_u24h          ="Ultimas 24 Horas";
  $vns_u30d          ="Ultimos 30 Dias";
  $vns_u12m          ="Ultimos 12 Meses";
  $vns_eh            ="Esta Hora";
  $vns_ed            ="Este Dia";
  $vns_em            ="Este Mes";
  $vns_em            ="Todo el Tiempo";
  $vns_td            ="Trafico de Datos";
  $vns_tt            ="Todo el Tiempo";
//
  $hd_title          ="Informaci&oacute;n de Discos Duros";
  $hd_sbtitle        ="Informaci&oacute;n del Disco";
  $hd_model          ="Modelo";
  $hd_test           ="Test";
  $hd_temp           ="Temperatura";
  $hd_size           ="Capacidad";
  $hd_speed          ="Lectura del Disco";
  $hd_life           ="Horas";
  $hd_monitoring     ="Monitoreo";
//
  $net_ir            ="Interfaces de Red";
  $net_ip            ="Direcciones IP";
  $net_iface         ="Interface:";
//  
  $lng_ttitle        ="Language";
  $lng_es            ="Espa&ntilde;ol";
  $lng_en            ="Ingles";
  $lng_pt            ="Portugues";
//  
  $bt_sysshut        ="Apagar Servidor";  
  $bt_sysreboot      ="Reiniciar Servidor";  
  $bt_rp_restart     ="Reiniciar Raptor";  
  $bt_restart        ="Reiniciando";  
  $alert_sysshut     ="Est&aacute; seguro de Apagar el Servidor?";  
  $alert_sysreboot   ="Est&aacute; seguro de Reiniciar el Servidor?";  
  $alert_rp_restart  ="Est� seguro de Reiniciar Raptor?"; 
  $alert_restarting  ="Est� seguro de Reiniciar?"; 
  $alert_change_ok   ="Se ha guardado los cambios"; 
  $alert_error       ="Error..."; 
  $alert_add_us_er   ="No se pudo ingresar el usuario";
  $alert_chg_us_er   ="No se pudo cambiar el password";
  $alert_up_file_ok  ="Se ha subido correctamente";
//
  $alert_submit      ="Est� seguro que quiere guardar los cambios?";
//
  $pu_title          ="Ingrese su Usuario y Contrase&ntilde;a WebPanel";
  $pu_user           ="Usuario:";
  $pu_pass           ="Contrase&ntilde;a:";
  $pu_new_user       ="Nuevo Usuario";
  $pu_user_profile   ="Perfil:";    
  $pu_change_pw      ="Cambio de Contrase&ntilde;a";
  $pu_change_pw_l    ="Contrase&ntilde;a Anterior:";
  $pu_change_pw_n    ="Nueva Contrase&ntilde;a:";
  $up_dns            ="Actualizar DNS";
  $num_cnx           ="Numero de Conexion";
  $alert_restart     ="Se ha reiniciado";
  $alert_fw          ="Se ha reiniciado el Firewall";
  $alert_no_ip       ="No se pudo ingresar el IP";
  $alert_iface       ="Elija una Interface de Red";
  $alertpu_uspass    ="Por favor, ingrese su Usuario y Contrase�a";
  $alertpu_us        ="Por favor, ingrese su Usuario";
  $alertpu_pass      ="Por favor, ingrese su contrase�a";
  $alertpu_len       ="Su contrase�a debe tener m�s de 4 caracteres";
  $alertpu           ="�Esta seguro de cambiar su Usuario y Contrase�a?";
//
  $alert_lang        ="No a ingresado su Idioma";  
  $alert_langok      ="Se ha cambiado su Idioma WebPanel";  
//
  $io_r_user         ="Muestra el porcentaje de utilizaci&oacute;n de la CPU que se produjo durante la ejecuci&oacute;n a nivel de usuario (aplicaci&oacute;n).";
  $io_r_nice         ="Muestra el porcentaje de utilizaci&oacute;n de la CPU que se produjo durante la ejecuci&oacute;n a nivel de usuario con buena prioridad.";
  $io_r_sys          ="Muestra el porcentaje de utilizaci&oacute;n de la CPU que se produjo durante la ejecuci&oacute;n a nivel de sistema (kernel).";
  $io_r_iowait       ="Muestra el porcentaje de tiempo empleado por la CPU esperando a las operaciones para completar.";
  $io_r_idle         ="Muestra el porcentaje de tiempo que la CPU est&aacute; inactivo.";

  $io_r_dev          ="Esta columna indica el nombre del dispositivo (o partici�n).";
  $io_r_tps          ="Indica el n&uacute;mero de transferencias por segundo.";
  $io_r_blk_read_s   ="Indica la cantidad de datos le&iacute;dos desde la unidad expresada en un n&uacute;mero de bloques por segundo.";
  $io_r_blk_wrtn_s   ="Indica la cantidad de datos escritos a la unidad expresado en un n&uacute;mero de bloques por segundo.";
  $io_r_blk_read     ="Total de n&uacute;meros leidos.";
  $io_r_blk_wrtn     ="Total de n&uacute;meros escritos.";
  $io_r_kb_read_s    ="Indica la cantidad de datos le&iacute;dos desde la unidad expresada en kilobytes por segundo.";
  $io_r_kb_wrtn_s    ="Indica la cantidad de datos escritos desde la unidad expresada en kilobytes por segundo.";
  $io_r_kb_read      ="El n&uacute;mero total de kilobytes leidos.";
  $io_r_kb_wrtn      ="El n&uacute;mero total de kilobytes escritos.";
  $io_r_rrqm_s       ="El n&uacute;mero de solicitudes de lectura por segundo.";
  $io_r_wrqm_s       ="El n&uacute;mero de solicitudes de escritura por segundo.";
  $io_r_r_s          ="El n&uacute;mero de solicitudes de lectura que se entregar&aacute; al dispositivo por segundo.";
  $io_w_r_s          ="El n&uacute;mero de solicitudes de escritura que se entregar&aacute; al dispositivo por segundo.";
  $io_r_rsec_s       ="El n&uacute;mero de sectores leidos desde el dispositivo por segundo.";
  $io_w_rsec_s       ="El n&uacute;mero de sectores escritos desde el dispositivo por segundo.";
  $io_r_rkB_s        ="El n&uacute;mero de kilobytes leidos desde el dispositivo por segundo.";
  $io_w_rkB_s        ="El n&uacute;mero de kilobytes escritos desde el dispositivo por segundo.";
  $io_r_avgrq_sz     ="El tama&ntilde;o medio (en sectores) de las solicitudes que fueron emitido al dispositivo.";
  $io_r_avgqu_sz     ="La longitud media de la cola de las solicitudes que se emiti&oacute; al dispositivo.";
  $io_r_await        ="El promedio de tiempo (en milisegundos) para las solicitudes de I/O emitida en el dispositivo para ser servido.";
  $io_r_svctm        ="El tiempo medio de servicio (en milisegundos) para I/O de peticiones que fueron emitidos en el dispositivo.";
  $io_r_util         ="Porcentaje de tiempo de CPU durante el cual las solicitudes de I/O fueron expedidas a la utilizaci&oacute;n del dispositivo (ancho de banda para el�dispositivo). Dispositivo de saturaci&oacute;n se produce cuando este valor es cerca de 100%.";
//
  $advice_fw         ="El orden de las reglas es importante, la regla \"Redirect 312x\" tiene que estar debajo de la regla de segmento de los usuarios";
//  
  $float_alert_ok    ="<div class='float_alert'><div class='spinner'><div class='dot1'></div><div class='dot2'></div></div><div class='alrt_msg'>{$alert_change_ok}</div></div>";
  $float_alert_er    ="<div class='float_alert'><div class='spinner'><div class='dot1'></div><div class='dot2'></div></div><div class='alrt_msg'>{$alert_error}</div></div>";
//
  $str_update        ="Actualizaci&oacute;n";
  $str_available     ="Disponible";
//
  $cop ="Copyright &copy; ".$cop_year." @ RaptorPanel ".$verwp." &copy; All Rights Reserved";
  $wpv = "RaptorPanel ".$verwp;
  
?>