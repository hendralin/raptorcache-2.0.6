<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
 error_reporting(0);
 
  $lang = "pt";
  
  $listMont = array("","Ene.","Feb.","Marzo","Abril","Mayo","Junio","Julio","Ago.","Sept","Oct.","Nov.","Dic.");
  $listWeek = array("","Mon"=>"Lunes","Tue"=>"Martes","Wed"=>"MiÃ©rcoles","Thu"=>"Jueves","Fri"=>"Viernes","Sat"=>"SÃ¡bado","Sun"=>"Domingo");

  $mysqlErr ="No se pudo establecer conexi&oacute;n con la Base de Datos.";

  $dia = array();
  
  $loginPanel        ="Login WebPanel";    
  $ident             ="Usu&aacute;rio";
  $ident2            ="Senha";
  $ident3            ="";
  $prof              ="Profile";  
  $cantIdent         ="Nome de usu&aacute;rio ou senha incorreta";
  $identProblem1     ="Servidor inacessivel.";
  $identProblem2     ="Problema tecnico."; 
  $identProblem3     ="Connection to LDAP server could not be established.";
  $enter             ="Entrar";

  $mysqlProblem1     ="Não foi possível estabelecer conexão com o banco de dados.";

  $loading           ="Carregando...";  

  $user              ="Usu&aacute;rio:";
//
  $m_sys             ="Sistema";
  $m_sys_cpu         ="CPU Usage";
  $m_sys_hd          ="Hard Disk";
  $m_sys_mem         ="Mem. RAM";
  $m_sys_red         ="Traf. RED";
//
  $m_est             ="&nbsp;&nbsp;Estad&iacute;sticas&nbsp;";
  $m_dom             ="&nbsp;&nbsp;Dominios&nbsp;";
  $m_ext             ="&nbsp;&nbsp;Extens&otilde;es&nbsp;";
  $m_alm             ="&nbsp;&nbsp;Armazenamento&nbsp;";
  $m_ahr             ="&nbsp;&nbsp;Economia&nbsp;";
  $m_trf             ="&nbsp;&nbsp;tr&aacute;fego de rede&nbsp;";
  $m_res             ="&nbsp;&nbsp;Resumen Total&nbsp;";
  $m_listpl          ="&nbsp;&nbsp;Raptor list&nbsp;";
  $m_onfpl           ="&nbsp;&nbsp;On / Off Plugins&nbsp;";
  $m_statepl         ="&nbsp;&nbsp;Ult. Activ. plugin&nbsp;";
  $m_cc              ="&nbsp;&nbsp;Conte&uacute;do cach&eacute&nbsp;";
  $m_ud              ="&nbsp;&nbsp;Url Negados&nbsp;";
  $m_util            ="Utilidade&nbsp;";
  $m_dd              ="&nbsp;&nbsp;Discos rigidos&nbsp;";
  $m_nconex          ="&nbsp;&nbsp;N&deg; Conex. por Usu&aacute;rio&nbsp;";
  $m_ajus            ="Defini&ccedil;&otilde;es&nbsp;";
  $m_config          ="Defini&ccedil;&otilde;es&nbsp;";
  $m_lang            ="&nbsp;&nbsp;Language&nbsp;";
  $m_reg             ="Registro&nbsp;";
  $m_titlg           ="&nbsp;&nbsp;Enter your Language&nbsp;";
  $m_clg             ="&nbsp;&nbsp;Language:&nbsp;";
  $m_exit            ="&nbsp;&nbsp;Deixar&nbsp;";
//
  $lang_rp           = "Espa&ntilde;ol";
//  
  $rp_repdate        ="Armazenamento dias";
  $rp_repdreq        ="dias de poupan&ccedil;a";
  $rp_repdtrd        ="dias de Threads";
  $rp_repext         ="relatório de extens&otilde;es";
  $rp_reptot         ="Resumo geral da resporte";

  $rp_date           ="Data";
  $rp_files          ="Registros";
  $rp_size           ="Tamanho";
  $rp_eco            ="Economia";
  $rp_hits           ="Hits";
  $rp_porcent        ="Eficacia";
  $rp_domain         ="Dominio";
  $rp_ext            ="Ext";
  $rp_ico            ="Ico";

  $rp_edidc          ="Diretorio Cach&eacute";
  $rp_edilc          ="L&iacute;mite Cache";  
  $rp_edmin          ="Min. Object Size";  
  $rp_edmax          ="Max. Object Size";  
  $rp_edyes          ="Si";  
  $rp_edno           ="No";  
//  
  $mem_memram        ="Memoria RAM";
  $mem_mt            ="Memoria Total";
  $mem_mu            ="Memoria Usada";
  $mem_ml            ="Memoria Livre";
  $mem_mp            ="Memoria Compart.";
  $mem_mb            ="Memoria Buffers";
  $mem_mc            ="Memoria Cach&eacute";
  $mem_st            ="Swap Total";
  $mem_su            ="Swap Usada";
  $mem_sl            ="Swap Livre";
//  
  $red_tr            ="Tr&aacute;fico de RED";
//  
  $vit_er            ="&nbsp;Estado de Raptor";
  $vit_es            ="&nbsp;Estado de Squid";
  $vit_con           ="&nbsp;Conex&otilde;es";
  $vit_us            ="&nbsp;Usuarios";
  $vit_dns           ="&nbsp;DNS Cach&eacute;";
  $vit_tact          ="&nbsp;Tiempo Ativo";
  $vit_temp          ="&nbsp;Temperatura";
//
  $sysdisk           ="Espa&ccedil;o para armazenamento - RaptorCache";
  $sysdisk_nd        ="N&deg; Discos";
  $sysdisk_dsk       ="Disco";
  $sysdisk_smart     ="S.M.A.R.T.";
  $sysdisk_mod       ="Modelo ";
  $sysdisk_sp        ="Espa&ccedil;o ";
  $sysdisk_temp      ="Temp.";
  $sysdisk_cdir      ="Cach&eacute; Dir.";
  $sysdisk_et        ="Espa&ccedil;o Total ";
  $sysdisk_eu        ="Espa&ccedil;o Usado ";
  $sysdisk_el        ="Espa&ccedil;o Livre ";
  $sysdisk_oc        ="Obj. en Cach&eacute;";
  $sysdisk_u         ="% Usado";
  $sysdisk_l         ="% Livre";
//
  $sq_al_ac          ="Atualizar";
  $sq_den            ="Sites da Web bloqueados";
  $rp_al_ac          ="Atualizar";
  $rp_actdes         ="Plugins Alternar";
  $hlp_ej            ="Para desabilitar um plugin adicionar<strong> # </strong> o in&itilde;cio da express&atilde;o regular por exemplo";
  $backup_bd         ="Backup Base de Datos";
  $c_user            ="Alterar seu nome de usu&aacute;rio e senha RaptorPanel";
  $hlp               ="Socorro";
  $bt_agr            ="Adicionar";
  $bt_act            ="Atualizar";
  $bt_agr_ip         ="Agregar IP";
  $bt_grd            ="Salvar";
  $bt_re             ="Restart";
//  
  $vns_res           ="Resumo";
  $vns_hr            ="Horas";
  $vns_d             ="D&iacute;as";
  $vns_m             ="Meses";
  $vns_res2          ="Resumen";
  $vns_t10           ="Top 10 Dias";
  $vns_u24h          ="Mais recente 24 Horas";
  $vns_u30d          ="Mais recente 30 Dias";
  $vns_u12m          ="Mais recente 12 Meses";
  $vns_eh            ="Esta Hora";
  $vns_ed            ="Este Dia";
  $vns_em            ="Este Mes";
  $vns_em            ="Durante todo o tempo";
  $vns_td            ="Dados de Tráfego";
  $vns_tt            ="Durante todo o tempo";
//
  $hd_title          ="informa&ccedil;&otilde;es de discos rigidos";
  $hd_sbtitle        ="informa&ccedil;&otilde;es de disco";
  $hd_model          ="Modelo";
  $hd_test           ="Test";
  $hd_temp           ="Temperatura";
  $hd_size           ="Capacidade";
  $hd_speed          ="Lendo o Disco";
  $hd_life           ="Horas";
  $hd_monitoring     ="Monitoring";    
//
  $net_ir            ="Interfaces de Red";
  $net_ip            ="Direcciones IP";
  $net_iface         ="Interface:";
//  
  $lng_ttitle        ="Language";
  $lng_es            ="Espa&ntilde;ol";
  $lng_en            ="Ingles";
  $lng_pt            ="Portugues";
//  
  $bt_sysshut        ="Desligar o Servidor";  
  $bt_sysreboot      ="Servidor Repor";  
  $bt_rp_restart     ="Raptor Repor";  
  $bt_restart        ="Restarting";
  $alert_sysshut     ="Tem certeza de Desligar o Servidor?";  
  $alert_sysreboot   ="Tem certeza de Servidor Repor?";  
  $alert_rp_restart  ="Tem certeza de Raptor Repor?";  
  $alert_restarting  ="Tem certeza de Repor?";    
  $alert_change_ok   ="Foi gravada mudan&ccedil;as";
  $alert_error       ="Error...";   
  $alert_add_us_er   ="N&atilde;o foi poss&iacute;vel entrar o usu&aacute;rio";
  $alert_chg_us_er   ="N&atilde;o foi poss&iacute;vel alterar a senha";  
  $alert_up_file_ok  ="Ele foi carregado corretamente";  
//
  $alert_submit      ="Tem certeza de que deseja salvar as altera&ccedil;&otilde;es?";
//
  $pu_title          ="Digite seu usu&aacute;rio e senha & ntilde; a WebPanel";
  $pu_user           ="User:";
  $pu_pass           ="Senha:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
  $pu_new_user       ="New User";  
  $pu_user_profile   ="Profile:";  
  $pu_change_pw      ="Change Password";
  $pu_change_pw_l    ="Old Password:";
  $pu_change_pw_n    ="New Password:";      
  $up_dns            ="Atualizar DNS";
  $num_cnx           ="N&aucute;mero de conexão";
  $alert_restart     ="Ele foi reiniciado";
  $alert_fw          ="Ele foi reiniciado o Firewall";
  $alert_no_ip       ="Não e possivel entrar no IP";
  $alert_iface       ="Escolha uma interface de rede";
  $alertpu_uspass    ="Digite seu usuário e senha";
  $alertpu_us        ="Digite seu usuário";
  $alertpu_pass      ="Digite seu senha";
  $alertpu_len       ="Sua senha deve ser mais do que 4 caracteres";
  $alertpu           ="¿Esta certo mudar seu usuário e senha?";
//
  $alert_lang        ="Eu não entrou o seu Idioma";  
  $alert_langok      ="Mudou de WebPanel língua";  
//  
  $io_r_user         ="Show the percentage of CPU utilization that occurred while executing at the user level (application).";
  $io_r_nice         ="Show the  percentage of CPU utilization that occurred while executing at the user level with nice priority.";
  $io_r_sys          ="Show the percentage of CPU utilization  that  occurred while executing at the system level (kernel).";
  $io_r_iowait       ="Show the  percentage of time that the CPU or CPUs were idle during which the system had an outstanding disk I/O request.";
  $io_r_idle         ="Show the  percentage of time that the CPU or CPUs were idle and the system did not have an outstanding disk  I/O request.";

  $io_r_dev          ="This column gives the device (or partition) name.";
  $io_r_tps          ="Indicate the number of transfers per second that were issued to the device.";
  $io_r_blk_read_s   ="Indicate the amount of data read from the drive expressed in a number of blocks per second.";
  $io_r_blk_wrtn_s   ="Indicate the amount of data written to the drive expressed in a number of blocks per second.";
  $io_r_blk_read     ="The total number of blocks read.";
  $io_r_blk_wrtn     ="The total number of blocks written.";
  $io_r_kb_read_s    ="Indicate the amount of data read from the drive expressed in kilobytes per second.";
  $io_r_kb_wrtn_s    ="Indicate the amount of data written to the drive expressed in kilobytes per second.";
  $io_r_kb_read      ="The total number of kilobytes read.";
  $io_r_kb_wrtn      ="The total number of kilobytes written.";
  $io_r_rrqm_s       ="The number of read requests merged per second that were issued to the device.";
  $io_r_wrqm_s       ="The number of write requests merged per second that were issued to the device.";
  $io_r_r_s          ="The number of read requests that were issued to the device per second.";
  $io_w_r_s          ="The number of write requests that were issued to the device per second.";
  $io_r_rsec_s       ="The number of sectors read from the device per second.";
  $io_w_rsec_s       ="The number of sectors written to the device per second.";
  $io_r_rkB_s        ="The number of kilobytes read from the device per  second.";
  $io_w_rkB_s        ="The number of kilobytes written to the device per second.";
  $io_r_avgrq_sz     ="The average size (in sectors) of the requests that were issued to the device.";
  $io_r_avgqu_sz     ="The average queue length of the requests that were issued to the device.";
  $io_r_await        ="The average time (in  milliseconds) for I/O requests issued to the device to be served.";
  $io_r_svctm        ="The average service time (in  milliseconds) for I/O requests that were issued to the device.";
  $io_r_util         ="Percentage of CPU time during which I/O requests were issued to the device (bandwidth utilization for the device). Device saturation occurs when this value is close to 100%.";
//
  $advice_fw         ="The order of the rules is important, the rule \"Redirect 312x\" It must be under of the segment rule of users";
//
  $str_update        ="Atualiza&ccedil;&atilde;o";
  $str_available     ="Dispon&iacute;vel";  
//
  $cop ="Copyright &copy; ".$cop_year." @ RaptorPanel ".$verwp." &copy; All Rights Reserved";
  $wpv = "RaptorPanel ".$verwp;
    
?>