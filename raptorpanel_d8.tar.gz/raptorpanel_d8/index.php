<?php
//error_reporting(-1);

spl_autoload_register(function ($className) {
	if (file_exists("bootstrap/". $className . '.php')) {
		include "bootstrap/". $className . '.php';
	} 		   
});

$app = new Start();
