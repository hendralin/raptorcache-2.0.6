<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
session_start();

require'models/Session.php';
$objses = new Session();
$objses->init();

$objses->destroy();

header("location: /");

 ?>