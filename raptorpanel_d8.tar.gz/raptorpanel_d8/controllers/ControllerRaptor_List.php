<?php

class Raptor_List extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/rplist');	
	}

}