<?php

class Index extends Controller {

	function __construct() {
		parent::__construct();
		//echo '4 We are contrller index /controllers/index.php<br>';
	/*
	Render View
	 */
		$this->view->render('index');	
	}

}