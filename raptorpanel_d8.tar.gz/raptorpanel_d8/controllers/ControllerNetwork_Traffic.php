<?php

class Network_Traffic extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/est_traf_red');	
	}

}