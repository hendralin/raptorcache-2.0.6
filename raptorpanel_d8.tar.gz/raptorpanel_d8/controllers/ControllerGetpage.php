<?php

class GetPage extends Controller {

	function __construct() {
		parent::__construct();
		//echo '4 We are contrller index /controllers/index.php<br>';
	/*
	Render View
	 */
		//$this->view->render('error');	
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().$name);	
	}

}