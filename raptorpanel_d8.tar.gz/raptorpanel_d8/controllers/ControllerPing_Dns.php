<?php

class Ping_Dns extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/ping_dns');	
	}

}