<?php

class Log_Out extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/log_out');	
	}

}