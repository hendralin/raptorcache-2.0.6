<?php 

class Route extends Controller {

	function __construct() {
		parent::__construct();
		//echo '4 We are controller index /controllers/system.php<br>';		
	}

	/*
	Render View
	 */	

	public function Index()
	{
		$this->view->render('index');	
	}

	public function getPage($name)
	{
		$this->view->render('admin/'.$name);	
	}

	public function init()
	{
		$this->view->render('admin/init');	
	}

}



