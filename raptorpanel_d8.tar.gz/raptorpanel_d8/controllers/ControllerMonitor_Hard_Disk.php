<?php

class Monitor_Hard_Disk extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/hard_disk');	
	}

}