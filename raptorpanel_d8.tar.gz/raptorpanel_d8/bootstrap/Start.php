<?php

class Start {

	function __construct() {

		$getUrl = isset($_GET['url']) ? $_GET['url'] : null ;

		if ($getUrl != "") {
			$pos = strpos($getUrl, '.req');
			if ($pos == true) { // request
				$url = rtrim($getUrl, '/');
				$url = explode('/', $url);
				require 'controllers/Request.php';
				$controller = new Request();
				$action = $url[1];
				$controller->getPage($action);				
				return;
			} else {
				require 'routes/web.php';
			}
		} else {
			$url[0] = "index";
			$url[1] = "";
		} 


		if ($url[0] != "" && $url[1] == "") {
			$file = 'controllers/Controller' . ucfirst($url[0]) . '.php';
		}
		else if ($url[0] != "" && $url[1] != "") {
			$file = 'controllers/Controller' . ucfirst($url[1]) . '.php';
		}
		

		if (file_exists($file)) {
			require $file;
		} else {
			require 'controllers/ControllerError.php';
			$controller = new Error();
			return;
		}

		
		$action = ucfirst($url[0]); // Admin


		if ($url[1] != "") {
			$controller = new $url[1]();	
		} else {
			/**
			 * [$controller description]
			 * @var [type] obj init index
			 */
			$controller = new $action;
			return;
		}
		

		if ($action == "Admin") {
			$action = $url[1];
			$controller->getPage($action);
		} else {
			$controller->$action();
		}	
		
	}

}