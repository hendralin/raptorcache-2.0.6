<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */

class Controller {

	function __construct() {
		//echo '3 Main controller /lib/Controller.php<br />';
		include "main/functions.php";
		$this->view = new View();
	}

}