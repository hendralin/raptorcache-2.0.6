<?php

class View {
/*
	function __construct() {
		echo '2 This is the view /lib/View.php<br>';
	}
 */
	public function render($name)
	{
		require 'public/' . $name . '.php'; //directory View
	}

}