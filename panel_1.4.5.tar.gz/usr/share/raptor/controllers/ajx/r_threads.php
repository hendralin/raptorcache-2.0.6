<?php 

	if (!function_exists('get_rp_path')) {
		require '/usr/share/raptor/main/functions.php';
	}
	require_once get_rp_path().'/models/autoload.php';

	use Raptor\Models\NetStat;

	$net = new NetStat();

	$json = array(
		"psauxT" => $net->open_threads_netstat()
	);

	print json_encode($json);	

 ?>