<?php 

	if (!function_exists('get_rp_path')) {
	    require '/usr/share/raptor/main/functions.php';
	}
	require_once get_rp_path().'/models/autoload.php';

	use Raptor\Models\SyState;

	$sys = new SyState();

	$iostat_cpu = $sys->io_cpu();
	$iostat_cpu = explode(" ", ltrim($iostat_cpu));


	$json = array(
		"user"   => $iostat_cpu[0],
		"nice"   => $iostat_cpu[1],
		"system" => $iostat_cpu[2],
		"wait"   => $iostat_cpu[3],
		"steal"  => $iostat_cpu[4],
		"idle"   => $iostat_cpu[5]
	);

	print json_encode($json);	

 ?>