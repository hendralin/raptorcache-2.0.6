<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}

require_once get_rp_path().'/main/auth.php';
require get_rp_path().'/class/Database.php';

$db = Database::getInstance();
$db->getConnection();

require '/usr/share/raptor/models/req/upHttps.php';

$requestData = $_REQUEST;

$columns = array( 

	0 => 'd_down', 
	1 => 'd_down', 
	2 => 'thread_usage'
);

$sql = "SELECT DATE_FORMAT(d_down,'%d/%m/%Y') as d_down, thread_usage";
$sql.=" FROM `raptor`.`http`";
$query         = $db->execute($sql);
$totalData     = mysqli_num_rows($query);
$totalFiltered = $totalData; 

if( !empty($requestData['search']['value']) ) {   
	$sql.=" HAVING d_down LIKE '".$requestData['search']['value']."%' ";    
}
$query         = $db->execute($sql);
$totalFiltered = mysqli_num_rows($query);  
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";	
$query = $db->execute($sql);

$data = array();
while( $row = mysqli_fetch_array($query) ) { 
	$nestedData = array(); 
	
	$nestedData[] = "<div style='text-align:center;'><img src='".get_view_link()."/images/imgpng/date.png' style='height:16px;vertical-align:bottom' alt='' /></div>";
	$nestedData[] = $row["d_down"];
	$nestedData[] = $row["thread_usage"];
	
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),    
			"recordsTotal"    => intval( $totalData ),  
			"recordsFiltered" => intval( $totalFiltered ), 
			"data"            => $data   
			);

echo json_encode($json_data);  

$db->disconnectDB();

?>
