<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}

require_once get_rp_path().'/main/auth.php';
require get_rp_path().'/class/Database.php';

$db = Database::getInstance();
$db->getConnection();

require '/usr/share/raptor/models/req/upHttps.php';

$requestData = $_REQUEST;

$columns = array( 
	0 => 'd_req', 
	1 => 'd_req', 
	2 => 'file_size',
	3 => 'requested_size',
	4 => 'hit_http',
	5 => 'percent'
);

$sql = "SELECT DATE_FORMAT(d_req,'%d/%m/%Y') as d_req, file_size, requested_size, hit_http, percent";
$sql.=" FROM `raptor`.`http`";
$query         = $db->execute($sql);
$totalData     = mysqli_num_rows($query);
$totalFiltered = $totalData; 
/*
$sql = "SELECT DATE_FORMAT(d_req,'%d/%m/%Y') as d_req,COUNT(*) as files,sum(file_size) as sizes,sum(requested_size) as eco, sum(requested_size/file_size) as hits ";
$sql.=" FROM raptor WHERE 1=1 group by d_req ";
 */
if( !empty($requestData['search']['value']) ) {   
	$sql.=" HAVING d_req LIKE '".$requestData['search']['value']."%' ";    
}
$query         = $db->execute($sql);
$totalFiltered = mysqli_num_rows($query);  
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."  LIMIT ".$requestData['start']." ,".$requestData['length']."   ";	
$query = $db->execute($sql);

$data = array();
while( $row = mysqli_fetch_array($query) ) { 
	$nestedData = array(); 
	//$percent    = round(($row['eco']/$row['sizes'])*100,2);
	//$percent    = round(($row["percent"]) * 100, 2);
	
	$nestedData[] = "<div style='text-align:center;'><img src='".get_view_link()."/images/imgpng/date.png' style='height:16px;vertical-align:bottom' alt='' /></div>";
	$nestedData[] = $row["d_req"];
	$nestedData[] = sizeFormat($row["file_size"]);
	$nestedData[] = sizeFormat($row["requested_size"]);
	$nestedData[] = $row["hit_http"];
	$nestedData[] = $row["percent"].' %';
	
	$data[] = $nestedData;
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),    
			"recordsTotal"    => intval( $totalData ),  
			"recordsFiltered" => intval( $totalFiltered ), 
			"data"            => $data   
			);

echo json_encode($json_data);  

$db->disconnectDB();

?>
