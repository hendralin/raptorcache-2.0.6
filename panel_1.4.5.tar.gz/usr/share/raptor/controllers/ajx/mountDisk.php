<?php

if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}

require_once get_rp_path().'/models/autoload.php';
use Raptor\Models\HardDiskMount;

$hdm = new HardDiskMount();

if (isset($_POST['format']) && ($_POST['format'] != "")) {
    $disk_format = $_POST['format'];
    if ($hdm->formatDisk($disk_format) == 1 && $hdm->getDirCacheMount($disk_format) == "") {
        echo " Formating <strong>{$disk_format}</strong>";
    } else {
        echo " It can not be formatted <strong>{$disk_format}</strong>";
    }
}

else if (isset($_POST['mount']) && ($_POST['mount'] != "")) {
    $disk_mount = $_POST['mount'];
    if ( strlen($hdm->getDirCacheMount($disk_mount)) > 0 ) {
        echo " Disk is Mounted...{$new_cache_dir}";
    } else {
        if ($hdm->setMountDisk($disk_mount) == 1 && $disk_mount != "") {
            $cacheDir = explode("/", $hdm->getNewCacheDir());
            $cacheDir = end($cacheDir);
            echo " Mounting <strong>{$disk_mount} - {$cacheDir}</strong>";
        } else {
            echo " Not Mount Hard Disk <strong>{$disk_mount}</strong>";
        }
    }
}

else if (isset($_POST['umount']) && ($_POST['umount'] != "")) {
    $disk_umount = $_POST['umount'];
    $dirCache = $hdm->getDirCacheMount($disk_umount);
    if ($hdm->setUmountDisk($disk_umount) == 1 && $dirCache != "") {
        $cacheDir = explode("/", $dirCache);
        $cacheDir = end($cacheDir);
        echo " Umount Hard Disk <strong>{$disk_umount} - {$cacheDir}</strong>";
    } else {
        echo " Not Umount Hard Disk <strong>{$dirCache}</strong>";
    }
}

?>