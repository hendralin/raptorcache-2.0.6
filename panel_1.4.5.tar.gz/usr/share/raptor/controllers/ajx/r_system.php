<?php 

	if (!function_exists('get_rp_path')) {
	    require '/usr/share/raptor/main/functions.php';
	}
	require_once get_rp_path().'/models/autoload.php';

	use Raptor\Models\SyState;
	use Raptor\Models\NetStat;
	use Raptor\Models\MemoryRam;

	$sys = new SyState();
	$net = new NetStat();

	$stat_cache_rp = $sys->stat_cache("8080");
	$stat_cache_sq = $sys->stat_cache("3128");
	$io_cpu = percC($sys->io_cpu());

	$avg = $sys->system_load();
	 
	$cpu_usage = $sys->cpu_bar();

	$mem = new MemoryRam();
	$mem_value = $mem->getValuesRam();

	$json = array(
		"psauxT" => $net->open_threads_netstat(),
		"stat_cache_rp" => $stat_cache_rp,
		//"version_rp" => $sys->version_rp(),
		"stat_cache_sq" => $stat_cache_sq,
		//"version_sq" => $sys->version_sq(),
		"cnx_us" => $net->cnx_us(),
		"open_threads_netstat" => $net->open_threads_netstat(),
		"num_us" => $net->num_us(),
		"cnx_dns" => $net->cnx_dns(),
		"uptime" => $sys->uptime(),
		"cpu_temp" => $sys->cpu_temp(),
		"io_cpu" => $io_cpu,
		"avg_1m" => $avg['1m'],
		"avg_5m" => $avg['5m'],
		"avg_15m" => $avg['15m'],
		"cpu_usage0" => $cpu_usage[0],
		"cpu_usage1" => $cpu_usage[1],
		"mem_value" => $mem_value[4]
	);

	print json_encode($json);	

 ?>