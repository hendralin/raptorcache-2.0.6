<?php

class Num_Conection_Users extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/num_conec_us');	
	}

}