<?php

//namespace Raptor\Controllers;
use Raptor\Models\FileRp;

class Raptor_Conf extends Controller 
{

	public function __construct() 
	{
		parent::__construct();
	}

	private function saveAction()
	{
		require 'models/autoload.php';

		$value_cache_limit = empty($_POST['cache_limit']) ? "80" : $_POST['cache_limit'];   
		$value_min_object_size = empty($_POST['min_object_size']) ? "2048" : $_POST['min_object_size'];

		$rp = new FileRp("/etc/raptor/raptor.conf");
		$rp->updateValueDirective("CACHE_LIMIT", $value_cache_limit);
		$rp->updateValueDirective("MIN_OBJECT_SIZE", $value_min_object_size);		
	}

	public function getPage($name)
	{		
		if ( isset($_SERVER['HTTP_X_REQUESTED_WITH']) && ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') ) {
			if (isset($_POST['tag']) && $_POST['tag'] !== '') {
				if ($_POST['tag'] == 'rpConf') {
					$this->saveAction();
				} else {
					echo "Error";
				}
			} else {
					echo "Error";
			}
    		return;
		}

		$file = "/etc/raptor/raptor.conf";
		$v_cache_limit = value_directive($file, "CACHE_LIMIT");
		$v_min_object_size = value_directive($file, "MIN_OBJECT_SIZE");

		$values = array("CACHE_LIMIT" => $v_cache_limit, "MIN_OBJECT_SIZE" => $v_min_object_size);

		$this->view->render(get_path_view().'/rpconf', $values);	
	}

}