<?php

use Raptor\Models\FileSq;

class Squid_Conf extends Controller 
{

	public function __construct() 
	{
		parent::__construct();
	}

	public function getPage($name)
	{

		require "models/autoload.php";

		$sq = new FileSq("/etc/squid3/squid.conf");
		$sq = array('dns1' => $sq->get_dns1(), 'dns2' => $sq->get_dns2(), 'localnet' => $sq->show_localnet());

		$this->view->render(get_path_view().'/sqconf', $sq);	
	}

}