<?php

use Raptor\Models\Statistic;

class Summary_Ssl extends Controller 
{

	public function __construct() 
	{
		parent::__construct();
	}

	public function getPage($name)
	{

        require 'class/Database.php';
        require 'models/Statistic.php';

        $db = Database::getInstance();
        $db->getConnection();
        $total = new Statistic($db);
        $total = array('SUMMARY_TOTAL_HTTPS' => $total->show_total_ssl()); 
        $db->disconnectDB();

		$this->view->render(get_path_view() . '/est_total_ssl', $total);	
	}

}