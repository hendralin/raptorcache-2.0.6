<?php

use Raptor\Models\FileRp;

class Raptor_List extends Controller 
{

	public function __construct() 
	{
		parent::__construct();
	}

	public function getPage($name)
	{
		require 'models/autoload.php';			
		$file = '/etc/raptor/raptor.lst';
		$tblShowRules = new FileRp($file);						
		$tblShowRules = array('file_route' => $file, 'table_rules_lst' => $tblShowRules->showRules());

		$this->view->render(get_path_view().'/rplist', $tblShowRules);	
	}

}