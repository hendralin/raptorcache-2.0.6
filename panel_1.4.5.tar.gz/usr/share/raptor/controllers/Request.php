<?php 

class Request extends Controller {

	public function __construct() 
	{
		parent::__construct();	
	}

	public function getPage($name)
	{
		$this->view->renderRQ(get_path_req(). '/' .$name);			
	}

}


