<?php

class Log_Error extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/logs_rp_err');	
	}

}