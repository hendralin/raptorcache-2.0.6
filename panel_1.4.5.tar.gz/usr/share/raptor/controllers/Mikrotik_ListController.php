<?php

class Mikrotik_List extends Controller {

	function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view().'/mk_u_list');	
	}

}