<?php 

	spl_autoload_register('_autoload');
	function _autoload($classname) {
		$namespace = explode("\\" , $classname)[0];
		if ($namespace == 'Raptor') {
			$classname = str_replace ('\\', '/', $classname);	    
			$classname = explode("/", $classname);
			$filename = end($classname) . ".php";
			require_once( __DIR__ . '/' .  $filename);
		} 
	}

 ?>