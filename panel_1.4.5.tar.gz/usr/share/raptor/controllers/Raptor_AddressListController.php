<?php

use Raptor\Models\AddressList;

class Raptor_AddressList extends Controller
{
    
    public function __construct()
    {
        parent::__construct();
    }
    
    public function getPage($name)
    {
		require_once 'models/autoload.php';
		$tblList = new AddressList();
		$list_name = $tblList->getListName();
        $getList = isset($_GET['list']) ? $_GET['list'] : NULL;
        if ($getList != NULL) {
            $listItems = $tblList->getListItems($_GET['list']);
        } else {
            $listItems = NULL;
        }
        
        $tblList = array('list_name' => $list_name, 'name' => $getList, 'list_items' => $listItems);
        
        $this->view->render(get_path_view().'/addressList', $tblList);
    }
    
}