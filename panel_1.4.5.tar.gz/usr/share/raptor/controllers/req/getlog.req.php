<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();

require "public/global/above.php"; 
?>

<div id="tbod"><!-- TBOD --> 


<div style="height:168px;margin-left:45%;padding-top:12%;"><div id="loading"><div style="display:inline-block;" class="icon-spinner r-spin"></div>&nbsp;&nbsp;<?php echo $loading; ?></div></div>

<?php

switch ($_GET['acs']) {
	case 'rpt_acc_lg':
			echo "<script language=\"javascript\">location.href=\"Log_Access_HTTP\"</script>";		
		break;
	case 'rpt_https_lg':
			echo "<script language=\"javascript\">location.href=\"Log_Access_HTTPS\"</script>";		
		break;
	case 'rpt_err_lg':
			echo "<script language=\"javascript\">location.href=\"Log_Error\"</script>";		
		break;
	case 'rpt_sys_lg':
			echo "<script language=\"javascript\">location.href=\"Log_System\"</script>";		
		break;						
}

 

?>

</div><!-- END TBOD -->

<br>

</div><!-- END GERAL -->  

</body>
</html>
 