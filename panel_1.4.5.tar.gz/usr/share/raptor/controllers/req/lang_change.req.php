<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

if ( !function_exists('set_value_config') ) {
    require '/usr/share/raptor/main/functions.php';
}

if ( isset($_POST['lang']) ) {       
	$lang = $_POST['lang'];
	set_value_config('main/settings.php', 'deflang', $lang);
}

echo "<script>window.location='Language_Config';</script>";

 ?>