<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
session_start();
if (isset($_POST)) {
	shell_exec("sudo shutdown -h now");
    echo "<div>Raptor</div>";     
}	
 ?>