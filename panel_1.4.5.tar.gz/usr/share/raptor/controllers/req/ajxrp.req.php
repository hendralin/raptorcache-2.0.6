<script src="<?php echo get_view_link(); ?>/js/form.ajx.js"></script>
<script>
	var x;
	x = $(document);
	x.ready(fadeLoad);
</script>
<style>
 
</style>
<?php

/**
 *
 * @package Raptorcache
 * @since 1.5
 */
 
 session_start();

//include_once '/usr/share/raptor/main/functions.php';
include_once dir_path().'/global/lang.php';
include_once dir_path()."/lang/$deflang.php";

$file = "/etc/raptor/raptor.conf";
$content = file_get_contents($file);

if ($_POST['cache_limit'] != "") {  

  $value_cache_limit = empty($_POST['cache_limit']) ? "80" : $_POST['cache_limit'];   
  $value_min_object_size = empty($_POST['min_object_size']) ? "2048" : $_POST['min_object_size'];

  $row_cache_limit = search_string($file, "CACHE_LIMIT");
  $row_cache_limit = $row_cache_limit['string']; 
  $name_cache_limit = explode(" ", $row_cache_limit);
  $new_line_cl      = $name_cache_limit[0]." ".$value_cache_limit;
 
  	$put1 = file_put_contents($file, str_replace($row_cache_limit, $new_line_cl, $content));

  $row_min_object_size  = search_string($file, "MIN_OBJECT_SIZE");
  $row_min_object_size = $row_min_object_size['string'];
  $name_min_object_size = explode(" ", $row_min_object_size);
  $new_line_moz         = $name_min_object_size[0]." ".$value_min_object_size;
  $content = file_get_contents($file);
  	$put2 = file_put_contents($file, str_replace($row_min_object_size, $new_line_moz, $content));

  	if ($put1 == true && $put2 == true) {
  			echo $float_alert_ok;
  	} else {
  		echo  $float_alert_er;
  	}
} else {
	echo  $float_alert_er;
}

?>