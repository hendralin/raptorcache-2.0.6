<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

require "global/above.php"; 
 ?>

<div id="tbod"> 

<div class="tab_report">
<table class="sortable" style="margin-top:8px;border-radius:3px 3px 0 0;" >
	<tr><th colspan=7 class="tabtit"><span class="icon-list"></span>&nbsp;</th></tr>
	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<table class="sortable">
	<tr>
	<td>
<?php
$fn_net = "/etc/network/interfaces";
if (isset($_POST['content_net'])) {	
    $content_net = ($_POST['content_sq']);
    $fp_net = fopen($fn_net,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_net, $content_net);
    fclose($fp_net) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
$fn_dns = "/etc/resolv.conf";
if (isset($_POST['content_dns'])) {	
    $content_dns = ($_POST['content_sq']);
    $fp_dns = fopen($fn_dns,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_dns, $content_dns);
    fclose($fp_dns) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
$fn_rp = "/etc/squid3/squid.conf";
if (isset($_POST['content_sq'])) {	
    $content_rp = ($_POST['content_sq']);
    $fp_rp = fopen($fn_rp,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_rp, $content_rp);
    fclose($fp_rp) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
$fn_fst = "/etc/fstab";
if (isset($_POST['content_fst'])) {	
    $content_fst = ($_POST['content_fst']);
    $fp_fst = fopen($fn_fst,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_fst, $content_fst);
    fclose($fp_fst) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
$fn_rgx = "/etc/raptor/brrgx.lst";
if (isset($_POST['content_rgx'])) {	
    $content_rgx = ($_POST['content_rgx']);
    $fp_rgx = fopen($fn_rgx,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_rgx, $content_rgx);
    fclose($fp_rgx) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
$fn_sts = "/etc/raptor/brsts.lst";
if (isset($_POST['content_sts'])) {	
    $content_sts = ($_POST['content_sts']);
    $fp_sts = fopen($fn_sts,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_sts, $content_sts);
    fclose($fp_sts) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
$fn_host = "/etc/raptor/host.lst";
if (isset($_POST['content_host'])) {	
    $content_host = ($_POST['content_host']);
    $fp_host = fopen($fn_host,"wb") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file");
    fputs($fp_host, $content_host);
    fclose($fp_host) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close file");
}
?>
<div style="text-align: left;">

	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_net"><?php readfile($fn_net); ?></textarea>
	<br>
	<input type="submit" value="send - ip">
	</form>
<hr>
	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_dns"><?php readfile($fn_dns); ?></textarea>
	<br>
	<input type="submit" value="send - dns">
	</form>
<hr>
	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_sq"><?php readfile($fn_rp); ?></textarea>
	<br>
	<input type="submit" value="send - sq">
	</form>
<hr>
	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_fst"><?php readfile($fn_fst); ?></textarea>
	<br>
	<input type="submit" value="send - fstab">
	</form>
<hr>
	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_rgx"><?php readfile($fn_rgx); ?></textarea>
	<br>
	<input type="submit" value="send - brrgx">
	</form>
<hr>
	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_sts"><?php readfile($fn_sts); ?></textarea>
	<br>
	<input type="submit" value="send - brsts">
	</form>
<hr>
	<form class="savecn" action="mnl_cnf.req" method="post">
	<textarea style="width: 800px;" rows="1" name="content_host"><?php readfile($fn_host); ?></textarea>
	<br>
	<input type="submit" value="send - host">
	</form>
<hr>

</div>
	&nbsp;</td>
	</tr>
</table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
