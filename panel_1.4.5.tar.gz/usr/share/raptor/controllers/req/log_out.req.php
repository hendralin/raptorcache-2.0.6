<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
session_start();

require 'models/Session.php';

use Raptor\Models\Session;

$objses = new Session();
$objses->init();

$objses->destroy();

if ($_POST['action'] == "reboot") {
	shell_exec("sudo shutdown -r now");
}
if ($_POST['action'] == "halt") {
	shell_exec("sudo shutdown -h now");
}

 ?>