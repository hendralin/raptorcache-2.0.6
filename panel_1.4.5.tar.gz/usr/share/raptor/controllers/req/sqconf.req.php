<?PHP
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();

use Raptor\Models\FileSq;

if ( isset($_POST['dns_submit']) ) {
	$dns1 = empty($_POST['dns_nameservers1']) ? "8.8.8.8" : $_POST['dns_nameservers1']; 
	$dns2 = empty($_POST['dns_nameservers2']) ? "8.8.4.4" : $_POST['dns_nameservers2'];	
	require 'models/autoload.php';
	$sq = new FileSq("/etc/squid3/squid.conf");
	$sq->setValueDNS($dns1, $dns2);
	header("location: Squid_Conf?accion=1");
	exit();	
}

if ( isset($_POST['acl_submit']) ) {
	$acl_localnet = $_POST['acl_ln'];
	require 'models/autoload.php';
	$sq = new FileSq("/etc/squid3/squid.conf");
	$sq->setValueLocalnet($acl_localnet);
	header("location: Squid_Conf?accion=1");	
	exit();
}

if ( isset($_GET['delete_line']) ) {
	$acl_localnet = "acl localnet src ".$_GET['delete_line'];    
	require 'models/autoload.php';
	$sq = new FileSq("/etc/squid3/squid.conf");
	$sq->deleteValueLocalnet($acl_localnet);		
	header("location: Squid_Conf?accion=1");
	exit();
}

header("location: Squid_Conf");

?>
