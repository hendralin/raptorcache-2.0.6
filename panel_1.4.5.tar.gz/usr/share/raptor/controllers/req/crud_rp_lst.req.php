<?php 
/**
 *
 * @package Raptorcache
 * @since 1.4
 */

session_start();

if ( isset($_POST['change_state']) ) {	
	$location = $_POST['location'];
	$file     = $_POST['file'];	
	$name     = $_POST['change_state'];
	$rule_name = "#name#".$name;    
  
	$content = file_get_contents($file);
	$row_regex    = explode("\n", $content);
	foreach ( $row_regex as $line ) {         
		if ( strpos($line, $rule_name) !== FALSE) {
			$row_regex = $line;
			$line_stat = substr($row_regex,0,5);   
			break;   
		}
	}
	if ( $line_stat == "##-##" ) { //enabled rule    
		$line_on  = explode("##-##", $row_regex);
		$line_on  = $line_on[1];
		file_put_contents($file, str_replace($row_regex, $line_on, $content));
		echo $location;
	} 
	else if ( $line_stat != "##-##" ) { //disabled rule    
		$line_off = "##-##".$row_regex; 
		file_put_contents($file, str_replace($row_regex, $line_off, $content));
		echo $location;
	}
	return;
}

if ( isset($_POST['move']) || isset($_POST['down']) ) {
		$location    =  $_POST['location'];
		$file        =  $_POST['file'];
		$regexName   =  $_POST["regex_name"]; 

		$content = file_get_contents($file);
		$fileln  = explode("\n", $content);

		$pos = 0;
		foreach ($fileln as $line) {     
			if ($line == "" || $line == NULL) {
				$content = "";
				$tmp = file($file);
				foreach ($tmp as $tmpline) {
					if (substr($tmpline, 0,8) == "\n") 
						continue;
					else 
						$content .= $tmpline;					
				}
				file_put_contents($file, $content); 				
				return;
			}    
			if (strpos($line, trim($regexName)) !== FALSE) {
				$row = $pos; 
				break;  
			}
			$pos++;
		} 
		if ($_POST['move'] == "up") {	
			$row_above = trim($fileln[$row-1]);
			if (ereg("^[a-zA-Z0-9\-_#]{1,10}", $row_above)) { 
				$reOrder = $fileln[$row] . "\n" . $row_above;			
				file_put_contents( $file, str_replace($fileln[$row-1]."\n", "", $content) );
				$lessContent = file_get_contents($file);
				$updateRow   = explode("\n", $lessContent);	
				file_put_contents( $file, str_replace($updateRow[$row-1], $reOrder, $lessContent) );
				echo $location;
			} 
		}
		if ($_POST['move'] == "down") {
			$row_below = trim($fileln[$row+1]);
			if (ereg("^[a-zA-Z0-9\-_#]{1,10}", $row_below)) {
				$reOrder = $row_below . "\n" . $fileln[$row];
				file_put_contents( $file, str_replace($fileln[$row+1]."\n", "", $content) );
				$lessContent     = file_get_contents($file);
				$updateRow   = explode("\n", $lessContent);		
				file_put_contents( $file, str_replace($updateRow[$row], $reOrder, $lessContent) );
				echo $location;			
			}					
		}	
	return;
}

if ( isset($_POST['new_regex']) ) {
	$location =  $_POST['location'];
	$file     =  $_POST['file'];
	
	$name     = ucfirst(trim($_POST['name']));
	$regex    = trim($_POST['nameregex']);

	if ($name == "" || $regex == "") {
		header("location: $location?error=1");
		return;
	}

	$existNameRule = false;
	$content = file_get_contents($file);
	$arr_content   = explode("\n", $content);	
	foreach ($arr_content as $linea) {	 
		$ruleNameTmp = explode("#name#", $linea);
		$ruleNameTmp = trim($ruleNameTmp[1]);
		
		if ($ruleNameTmp == $name) {
			$suffix = time();
			file_put_contents($file, $regex . " #name#". $name . "." . substr($suffix, -3) . PHP_EOL, FILE_APPEND);			
			$existNameRule = true;
			break;
		}	
	}

	if ($existNameRule == false) {
		file_put_contents($file, $regex . " #name#".$name. PHP_EOL, FILE_APPEND);
	}

	header("location: $location");
	return;
}

if ( isset($_POST['filter_rule']) ) {	
	$location =  $_POST['location'];
	$file     =  $_POST['file'];

	$name      = ucfirst(trim($_POST['name']));
	if ($name == "")
		header("location: $location?error=1");

	$chain     = trim($_POST['chain']);
	$src_dst   = trim($_POST['src_dst']);
	$address   = trim($_POST['address']);
	$in_interface  = trim($_POST['in_interface']);
	$out_interface = trim($_POST['out_interface']);
	$action    = " -j ". trim($_POST['action']);

	if ($src_dst != "") {
		$src_dst   = ($src_dst == "1")? " -s " : " -d ";
	} else {
		$address = "";
	}

	if ($in_interface == "" && $out_interface == "") {
		$interface = "";
	}
	else if ($in_interface != "" && $in_interface != "") {
		$interface = " -i " . $in_interface;
	}
	else if ($in_interface != "" && $out_interface == "") {
		$interface = " -i " . $in_interface;
	}
	else if ($in_interface == "" && $out_interface != "") {
		$interface = " -o " . $out_interface;
	}

	$existNameRule = false;
	$content = file_get_contents($file);
	$arr_content   = explode("\n", $content);	
	foreach ($arr_content as $linea) {	 
		$ruleNameTmp = explode("#name#", $linea);
		$ruleNameTmp = trim($ruleNameTmp[1]);
		
		if ($ruleNameTmp == $name) {
			$suffix = time();
			file_put_contents($file, "iptables -A " . $chain . $src_dst . $address . $interface . $action . " #name#". $name . "." . substr($suffix, -3) . PHP_EOL, FILE_APPEND);			
			$existNameRule = true;
			break;
		}	
	}

	if ($existNameRule == false) {
		file_put_contents($file, "iptables -A " . $chain . $src_dst . $address . $interface . $action . " #name#".$name. PHP_EOL, FILE_APPEND);
	}

	header("location: $location");
	return;
}

if ( isset($_POST['nat_rule']) ) {	
	$location =  $_POST['location'];
	$file     =  $_POST['file'];

	$name      = ucfirst(trim($_POST['name']));
	if ($name == "")
		header("location: $location?error=1");

	$chain     = trim($_POST['chain']);
	$address_list_name   = trim($_POST['address_list_name']);
	$in_interface  = trim($_POST['in_interface']);
	$out_interface = trim($_POST['out_interface']);
	$type_list     = trim($_POST['type_list']);
	$type_port     = trim($_POST['type_port']);
	$port_number   = trim($_POST['port_number']);
	$action        = " -j ". trim($_POST['action']);
	$to_port       = trim($_POST['to_port']);	

	if ($type_list != "") {
		if ($type_list == "1")
			$address_list_name =  " -m set --match-set " . $address_list_name ." src "; 
		else 
			$address_list_name =  " -m set --match-set " . $address_list_name ." dst "; 
	} else {
		$address_list_name = "";
	}	

	if ($type_port != "") {
		if ($type_port == "1")
			$num_port =  " -p tcp --sport " . $port_number ." "; 
		else 
			$num_port =  " -p tcp --dport " . $port_number ." "; 
	} else {
		$num_port = "";
	}

	if ($in_interface == "" && $out_interface == "") {
		$interface = "";
	}
	else if ($in_interface != "" && $in_interface != "") {
		$interface = " -i " . $in_interface;
	}
	else if ($in_interface != "" && $out_interface == "") {
		$interface = " -i " . $in_interface;
	}
	else if ($in_interface == "" && $out_interface != "") {
		$interface = " -o " . $out_interface;
	}

	if ($to_port != "") 
		$to_port = " --to-port " . $to_port;
	else 
		$to_port = "";

	$existNameRule = false;
	$content = file_get_contents($file);
	$arr_content   = explode("\n", $content);	
	foreach ($arr_content as $linea) {	 
		$ruleNameTmp = explode("#name#", $linea);
		$ruleNameTmp = trim($ruleNameTmp[1]);
		
		if ($ruleNameTmp == $name) {
			$suffix = time();
			file_put_contents($file, "iptables -t nat -A " . $chain . $address_list_name . $num_port . $interface . $action . $to_port . " #name#". $name . "." . substr($suffix, -3) . PHP_EOL, FILE_APPEND);			
			$existNameRule = true;
			break;
		}	
	}

	if ($existNameRule == false) {
		file_put_contents($file, "iptables -t nat -A " . $chain . $address_list_name . $num_port . $interface . $action . $to_port . " #name#".$name. PHP_EOL, FILE_APPEND);
	}

	header("location: $location");
	return;
}

if ( isset($_POST['add_domain']) ) {
	$location =  $_POST['location'];
	$file     =  $_POST['file'];

	$name      = ucfirst(trim($_POST['name']));
	$domain    = trim($_POST['domain']);
	$domain1   = explode(".", $domain);
	$dom_name  = $domain1[0];
	$com       = $domain1[1];

	if ($name == "" || $domain =="") {
		header("location: $location");
		exit();
	}

	$existNameRule = false;
	$content = file_get_contents($file);
	$arr_content   = explode("\n", $content);	
	foreach ($arr_content as $linea) {	 
		$ruleNameTmp = explode("#name#", $linea);
		$ruleNameTmp = trim($ruleNameTmp[1]);
		
		if ($ruleNameTmp == $name) {
			$suffix = time();
			file_put_contents($file, "\.{$dom_name}\.{$com} #name#". $name . "." . substr($suffix, -3) . PHP_EOL, FILE_APPEND);			
			$existNameRule = true;
			break;
		}	
	}

	if ($existNameRule == false) {
		file_put_contents($file, "\.{$dom_name}\.{$com} #name#".$name. PHP_EOL, FILE_APPEND);
	}

	header("location: $location");
	return;
}

if ( isset($_GET['edit_regex']) ) {
	$location    = $_GET['location'];
	$file        = $_GET['file'];
	$rule        = $_GET["rule"]; 
	$idrule      = $_GET["idrule"];
	$regexName   = "#name#".ucfirst($_GET["namerule"]); 

	$content   = file_get_contents($file);
	$row_regex = explode("\n", $content);
	$new_rule  = trim($rule)." ".trim($regexName);
	if ($rule != "") {
		file_put_contents($file, str_replace($row_regex[($idrule)], $new_rule, $content));
	}
	
	header("location: $location");
	return;
}

if ( isset($_POST['delete_line']) ) {
	$location  =  $_POST['location'];
	$file      =  $_POST['file'];
	$name_rule =  $_POST["delete_line"]; 

	$del_rule = "#name#".$name_rule; 
	if ($file != "" || $name_rule != "") {
		$content = file_get_contents($file);
		$file_arr_ln = explode("\n", $content);		
		foreach ( $file_arr_ln as $line ) {         
			if ( strpos($line, $del_rule ) !== FALSE ) {
				file_put_contents($file, str_replace($line."\n", "", $content));
				echo $location;
				return;
			}
		}	
	}
	return;
}

	
?>

