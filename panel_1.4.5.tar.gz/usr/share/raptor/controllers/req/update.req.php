<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
session_start();

function runExec($shellCommand)
{
	exec($shellCommand, $outputShellCommand, $response);
	if ($response === 0) {
		return $outputShellCommand;
	} else {
		return 0;
	}		
}	

$getStat = isset($_POST['update']) ? $_POST['update'] : NULL;

if ( $getStat != NULL ) {

	if ( $_POST['update'] == 'core' ) {
		$output = runExec("sudo bash /etc/raptor/run.v/up_core_online.sh");
		if ($output !== 0) {
			foreach ($output as $value) {
				if (strpos($value, "Error!") !== FALSE) {
					$msn = "Error Update Core";
					break;
				}
				if (strpos($value, "Update_Core_Finish") !== FALSE) {
					runExec("sudo bash /etc/raptor/run.v/shut_rp.sh");
					$version = explode(" ", $value); 
					$version = $version[1];
					$msn = "Finish Update&nbsp;Core&nbsp;" . $version;
					break;
				}				
			}
		} else {
			$msn = "Error Update...";
		}				
    	echo $msn;  
	}
	else if ( $_POST['update'] == 'panel' ) {
		$output = runExec("sudo bash /etc/raptor/run.v/up_panel_online.sh");
		if ($output !== 0) {
			foreach ($output as $value) {
				if (strpos($value, "Error!") !== FALSE) {
					$msn = "Error Update Panel";
					break;
				}				
				if (strpos($value, "Update_Panel_Finish") !== FALSE) {
					$version = explode(" ", $value); 
					$version = $version[1];
					$msn = "Finish Update&nbsp;Panel&nbsp;" . $version;
					break;
				}
			}
		} else {
			$msn = "Error Update...";
		}	
		echo $msn;
	}
	else if ( $_POST['update'] == 'services' ) {
		$output = runExec("sudo bash /etc/raptor/run.v/up_services_online.sh");
		if ($output !== 0) {
			foreach ($output as $value) {
				if (strpos($value, "Error!") !== FALSE) {
					$msn = "Error Update Services";
					break;
				}				
				if (strpos($value, "Update_Services_Finish") !== FALSE) {
					$version = explode(" ", $value); 
					$version = $version[1];
					$msn = "Finish Update&nbsp;Services&nbsp;" . $version;
					break;
				}
			}
		} else {
			$msn = "Error Update...";
		}	
		echo $msn;		
	}   
} else {
	echo "Error...";
}	

 ?>