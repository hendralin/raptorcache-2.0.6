<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */

function search_string($open_file, $string_search) {
  $file = $open_file;
  $fileln = file($file);  
  $pos = 0;
  foreach($fileln as $linea) { 
    if (strstr($linea, $string_search)){
     $num_row = $pos + 1;        
    }
    $pos++;
  } 
  $content = file_get_contents($file);
  $arr_lines = explode("\n", $content);
  $line_string = $arr_lines[($num_row - 1)];            
  return array('row' => $num_row, 'string' => $line_string);
}

require_once '/usr/share/raptor/class/Database.php';

$db = Database::getInstance();
$db->getConnection();

$current_date = exec('date +%Y-%m-%d');

$file = "/etc/raptor/fw.sh";
$search = "--dport 443 -j REDIRECT --to-port 3127";
$check = search_string($file, $search);
if (substr($check['string'], 0, 5) != "##-##") {

	$count_files =  $file_size = $eco_size = $hits = 0;

	$type = "ssl";
	$count_files = exec("sudo squidclient -h 127.0.0.1 mgr:info | grep 'on-disk objects' | awk '{print $1}'");
	$file_size = exec("sudo squidclient -h 127.0.0.1 mgr:storedir | grep 'Current Size:' | awk '{print $3}'");
	$file_size = intval($file_size) * 1024;

	$eco_size = exec("sudo squidclient -h 127.0.0.1 mgr:counters | grep 'client_http.hit_kbytes_out' | awk '{print $3}'");
	$eco_size = $eco_size * 1024;
	$hits = exec("sudo squidclient -h 127.0.0.1 mgr:counters | grep client_http.hits | awk '{print $3}'");

	$new_eco_size = $new_hits = "";

	$sql = "SELECT date_ssl FROM `raptor`.`ssl` WHERE date_ssl = '".$current_date."'  LIMIT 1; ";

	$result   = $db->execute($sql);
	$num_rows = mysqli_num_rows($result);	

	$up = $ins = "";

	if ($num_rows > 0) {			
		$up = "UPDATE `raptor`.`ssl` SET type = '".$type."', date_ssl = '".$current_date."', count_files = '".$count_files."', file_size = '".$file_size."', eco_size = '".$eco_size."', hits = '".$hits."' WHERE date_ssl ='".$current_date."'; ";
		if ($db->execute($up)) {
		//echo "_UPDATE_SSL";
		}
	} else {
		$ins = "INSERT INTO `raptor`.`ssl`(type, date_ssl, count_files, file_size, eco_size, hits) VALUES('".$type."', '".$current_date."', '".$count_files."', '".$file_size."','".$eco_size."','".$hits."'); ";
		if ($db->execute($ins)) {
		//echo "_INSERT_SSL";
		}		
	}
}

/**
 * 
 */

	$hit_http = $files = $count_user = $sizes = $d_req = $eco = $threads = $percent = "";
	$sql = "SELECT DATE_FORMAT(d_down,'%Y-%m-%d') as d_down, COUNT(*) as files, sum(file_size) as sizes, MAX(thread_usage) as threads FROM `raptor`.`raptor` WHERE d_down='".$current_date."'; ";
	$result = $db->execute($sql);
	foreach ($result as $row) {		
		$files      = $row['files'];
		$count_user = 0;		
		$sizes      = round($row['sizes'], 2);	
		$threads    = $row['threads'];					
	}

	$sql = "SELECT DATE_FORMAT(d_req,'%Y-%m-%d') as d_req, sum(requested_size/file_size) as hits, sum(requested_size) as eco, sum(requested_size)/sum(file_size) as percent FROM `raptor`.`raptor` WHERE d_req='".$current_date."'; ";
	$result = $db->execute($sql);
	foreach ($result as $row) {
		$d_req      = $row['d_req'];
		$hit_http   = round($row['hits'], 0);
		$eco        = $row['eco'];	
		$percent    = round(($row["percent"]) * 100, 2);
	}

	$sql = "SELECT d_down FROM `raptor`.`http` WHERE d_down ='".$current_date."' LIMIT 1; ";
	$result = $db->execute($sql);
	$num_rows = mysqli_num_rows($result);

	if ($num_rows > 0) {
		$up = "UPDATE `raptor`.`http` SET `hit_http` = '".$hit_http."', `file` = '".$files."', `file_size` = '".$sizes."',`d_req` = '".$d_req."', `requested_size` = '".$eco."', `thread_usage` = '".$threads."', `percent` = '".$percent."' WHERE d_down='".$current_date."';";
		if ($db->execute($up)) {
		//echo "_UPDATE_HTTP\n\n";
		}
	} else {
		$ins = "INSERT INTO `raptor`.`http` (`id`, `hit_http`, `file`, `count_user`, `file_size`, `d_down`, `d_req`, `requested_size`, `thread_usage`, `percent`) VALUES 
		                                   (NULL, '".$hit_http."', '".$files."', '".$count_user."', '".$sizes."', '".$current_date."', '".$d_req."', '".$eco."', '".$threads."', '".$percent."');";
		if ($db->execute($ins)) {
		//echo "_INSERT_HTTP\n\n";
		}		
	}
	echo "DONE\n";
$db->disconnectDB();

 ?>