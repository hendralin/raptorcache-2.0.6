<?php 

include_once '/usr/share/raptor/main/functions.php';

$file = "/etc/crontab";
$content = file_get_contents($file);

if (isset($_POST['clean'])) {
	$line_clean = search_string($file, "clean ");
	if ($_POST['clean'] > 0) {
		$value_clean = $_POST['clean'];
		$new_line_clean = "59              1               *       *               *       root    /etc/raptor/./clean " . $value_clean;	
		exec("sudo chmod 777 /etc/crontab");	
		file_put_contents($file, str_replace($line_clean['string'], $new_line_clean."\n", $content));
		exec("sudo chmod 644 /etc/crontab");
		header("location:Scheduler?accion=1");
	} else {
		header("location:Scheduler?error=1");;
	}
}

if (isset($_POST['submit_shutdown'])) { 
	exec("sudo chmod 777 /etc/crontab");

	$row_shutdown = search_string($file, "shutdown -h");
	$line_shutdown = $row_shutdown['string'];

	if (isset($_POST['change_shutdown'])) { //change
			$value_h_shutdown = ($_POST['h_shutdown'] > 23) ? "0" : $_POST['h_shutdown'];		
			$value_m_shutdown = ($_POST['m_shutdown'] > 59) ? "59" : $_POST['m_shutdown'];		
			$new_line_shutdown = $value_m_shutdown." ".$value_h_shutdown." * * * root shutdown -h now";
			file_put_contents($file, str_replace($row_shutdown['string'], $new_line_shutdown, $content));
			exec("sudo chmod 644 /etc/crontab");
			header("location:Scheduler?accion=1");
			
	}
	if ($_POST['stat_cron'] == 0) { //enabled
		$new_line_shutdown = explode("-##", $line_shutdown);
		$new_line = $new_line_shutdown[1];	
		echo $new_line;
		file_put_contents($file, str_replace($line_shutdown, $new_line, $content));
		header('location:Scheduler?accion=1');
	}   
	else if ($_POST['stat_cron'] == 1) { //disabled
			$new_line = "##-##".$line_shutdown;
			echo $new_line;
			file_put_contents($file, str_replace($line_shutdown, $new_line, $content));	
			header('location:Scheduler?accion=1');	
	}	
	exec("sudo chmod 644 /etc/crontab");
}


 ?>