<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

session_start();

if ($_GET['ip_cache'] != "") {

	require 'models/Network.php';
	
	$ipch = new Raptor\Models\Network();
	
	$ip_r = $_GET['ip_cache'];

 	$ipch->putIpCache("cache_peer ", $ip_r, "parent 8080 0 proxy-only no-digest");
	$ipch->putIpCache("allow host", $ip_r, "allow host_lst");
	$ipch->putIpCache("allow ext", $ip_r, "allow exts");
	$ipch->putIpCache("deny head_html", $ip_r, "deny head_html");
	$ipch->putIpCache("deny wth_lst", $ip_r, "deny wth_lst");
	$ipch->putIpCache("allow raptor_lst", $ip_r, "allow raptor_lst");
	$ipch->putIpCache("allow sys_lst", $ip_r, "allow sys_lst");
	$ipch->putIpCache("cache_peer_access", $ip_r, "deny all");

	header("location: Network_Config?accion=1"); 
} else {
	header("location: Network_Config?error=1");	
}


?>


