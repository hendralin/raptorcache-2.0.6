<?php 
/**
 *
 * @package Raptorcache
 * @since 1.0
 */

session_start();

$interface_r_1 = $_POST['interface_1'];
$ip_r_1 = $_POST['ip_1'];
$netmask_r_1 = $_POST['netmask_1'];
$network_r_1 = $_POST['network_1'];
$broadcast_r_1 = $_POST['broadcast_1'];
$gateway_r_1 = $_POST['gateway_1'];

$interface_r_2 = $_POST['interface_2'];
$ip_r_2 = $_POST['ip_2'];
$netmask_r_2 = $_POST['netmask_2'];
$network_r_2 = $_POST['network_2'];
$broadcast_r_2 = $_POST['broadcast_2'];

$dns_nameservers_r = exec("sudo cat /etc/resolv.conf | grep -v '##-##' | grep nameserver | head -1 | awk '{print $2}'");

	$dt = date('dhi');

	$tag = "#".$interface_r."#".$dt;

	# The loopback network interface
	$auto_lo = "auto lo";
	$iface_lo = "iface lo inet loopback";

	$allow_1 = "allow-hotplug ".$interface_r_1;
	$iface_1 = "iface ".$interface_r_1." inet static";
	$address_1 = "	address ".$ip_r_1;
	$netmask_1 = "	netmask ".$netmask_r_1;
	$network_1 = "	network ".$network_r_1;
	$broadcast_1 = "	broadcast ".$broadcast_r_1;
	$gateway_1 = "	gateway ".$gateway_r_1;

	$nb = "\n";

	$allow_2 = "allow-hotplug ".$interface_r_2;
	$iface_2 = "iface ".$interface_r_2." inet static";
	$address_2 = "	address ".$ip_r_2;
	$netmask_2 = "	netmask ".$netmask_r_2;
	$network_2 = "	network ".$network_r_2;
	$broadcast_2 = "	broadcast ".$broadcast_r_2;

	$nb = "\n";

	$file = fopen("/etc/network/interfaces", "w");

	fwrite($file, "# The loopback network interface" . PHP_EOL);
	fwrite($file, $auto_lo . PHP_EOL);
	fwrite($file, $iface_lo . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);
	fwrite($file, "# The primary network interface" . PHP_EOL);
	fwrite($file, $allow_1 . PHP_EOL);
	fwrite($file, $iface_1 . PHP_EOL);
	fwrite($file, $address_1 . PHP_EOL);
	fwrite($file, $netmask_1 . PHP_EOL);
	fwrite($file, $network_1 . PHP_EOL);
	fwrite($file, $broadcast_1 . PHP_EOL);
	fwrite($file, $gateway_1 . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);
	fwrite($file, "# The secondary network interface" . PHP_EOL);
	fwrite($file, $allow_2 . PHP_EOL);
	fwrite($file, $iface_2 . PHP_EOL);
	fwrite($file, $address_2 . PHP_EOL);
	fwrite($file, $netmask_2 . PHP_EOL);
	fwrite($file, $network_2 . PHP_EOL);
	fwrite($file, $broadcast_2 . PHP_EOL);
	fwrite($file, $gateway_2 . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);

	fclose($file);

header('location:Network_Config');

 ?>