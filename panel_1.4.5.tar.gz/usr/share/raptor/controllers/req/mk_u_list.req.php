<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
session_start();

if (!function_exists('en_str')) {
    require_once "main/functions.php";
}

require_once "class/Database.php";
require_once "models/Router.php";
use Raptor\Models\Router;
$db = Database::getInstance();
$db->getConnection();
$rb = new Router($db);

if ( isset($_POST['conn_mk']) ) {
	$ip_mk = $_POST['ip_mk'];
	$user_mk = $_POST['user_mk'];
	$pass_mk = $_POST['pass_mk'];

	if ( $rb->checkApiCon($ip_mk, $user_mk, $pass_mk) ) {
		$sql =	"TRUNCATE user_mk";
		$db->execute($sql);
	 	$sql  = "INSERT INTO user_mk(ip_mk, user_MK, pass_mk) VALUES('".$ip_mk."', '".$user_mk."','".en_str($pass_mk)."')";
		$stat = $db->execute($sql);
		$db->disconnectDB();
	 	if (!$stat) {
	  	echo "<script>window.location='Mikrotik_List?add=no';</script>";
		}
	}
	header("location: Mikrotik_List");
}

header("location: Mikrotik_List?error=1");

?>
