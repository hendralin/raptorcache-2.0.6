<?php 
/**
 *
 * @package Raptorcache
 * @since 1.4
 */

session_start();

$interface_r_1 = $_POST['interface_1'];
$interface_r_2 = $_POST['interface_2'];
$ip_r = $_POST['ip'];
$netmask_r = $_POST['netmask'];
$network_r = $_POST['network'];
$broadcast_r = $_POST['broadcast'];
$gateway_r = $_POST['gateway'];

	$dt = date('dhi');
	$tag = "#".$interface_r."#".$dt;

	# The loopback network interface
	$auto_lo = "auto lo";
	$iface_lo = "iface lo inet loopback";

	# Eth0 to Eth2 network switch
	$allow_br1  = "allow-hotplug ". $interface_r_1;
	$iface_br1  = "iface ".$interface_r_1. " inet manual";
	$pre_up_1   = "	pre-up ifconfig \$IFACE up";
	$pre_down_1 = "	pre-down ifconfig \$IFACE down";
	 
	$allow_br2  = "allow-hotplug ". $interface_r_2;
	$iface_br2  = "iface ".$interface_r_2." inet manual";
	$pre_up_2   = "	pre-up   ifconfig \$IFACE up";
	$pre_down_2 = "	pre-down ifconfig \$IFACE down";
	 
	# Setup an IP address for our bridge
	$auto_br  = "auto br0";
	$iface_br = "iface br0 inet static";
	#
	$iface     = "	bridge_ports ".$interface_r_1." ".$interface_r_2;
	$address   = "	address ".$ip_r;
	$netmask   = "	netmask ".$netmask_r;
	$network   = "	network ".$network_r;
	$broadcast = "	broadcast ".$broadcast_r;
	$gateway   = "	gateway ".$gateway_r;

	$nb = "\n";

	$file = fopen("/etc/network/interfaces", "w");

	fwrite($file, $auto_lo . PHP_EOL);
	fwrite($file, $iface_lo . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);


	fwrite($file, $allow_br1 . PHP_EOL);
	fwrite($file, $iface_br1 . PHP_EOL);
	fwrite($file, $pre_up_1 . PHP_EOL);
	fwrite($file, $pre_down_1 . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);

	fwrite($file, $allow_br2 . PHP_EOL);
	fwrite($file, $iface_br2 . PHP_EOL);
	fwrite($file, $pre_up_2 . PHP_EOL);
	fwrite($file, $pre_down_2 . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);

	fwrite($file, $auto_br . PHP_EOL);
	fwrite($file, $iface_br . PHP_EOL);
	//fwrite($file, $nb . PHP_EOL);
	fwrite($file, $iface . PHP_EOL);
	fwrite($file, $address . PHP_EOL);
	fwrite($file, $netmask . PHP_EOL);
	fwrite($file, $network . PHP_EOL);
	fwrite($file, $broadcast . PHP_EOL);
	fwrite($file, $gateway . PHP_EOL);
	fwrite($file, $nb . PHP_EOL);

	fclose($file);

header('location:Network_Config');

 ?>