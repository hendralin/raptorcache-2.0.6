<?php 
/**
 *
 * @package Raptorcache
 * @since 1.4
 */

session_start();

if ( isset($_POST['add_addressList_name']) ) {
	$nameList = isset($_POST['name']) ? $_POST['name'] : NULL;
	if ($nameList != NULL) {
		$shellCommand = "sudo ipset create ".$nameList." hash:net";
		exec($shellCommand, $outputShellCommand, $response);
		if ($response === 0)	
			header("location: Raptor_AddressList?accion=1");		
		else
			header("location: Raptor_AddressList?error=1");				
	} else {
		header("location: Raptor_AddressList?error=1");
	}
}	

if ( isset($_POST['add_addressList_item']) ) {
	$nameList = isset($_POST['list']) ? $_POST['list'] : NULL;
	$address = isset($_POST['address']) ? $_POST['address'] : NULL;
	if ($nameList != NULL && $address != NULL) {
		$shellCommand = "sudo ipset add " . $nameList . " " . $address;
		exec($shellCommand, $outputShellCommand, $response);
		if ($response === 0) {	
			shell_exec("sudo ipset save ".$nameList." -f /usr/local/raptor/address/iptables.".$nameList.".lst");
			header("location: Raptor_AddressList?list={$nameList}");		
		} else
			header("location: Raptor_AddressList?error=1");				
	} else {
		header("location: Raptor_AddressList?error=1");
	}
}

if ( isset($_POST['del_item']) ) {
	$nameList = isset($_POST['list']) ? $_POST['list'] : NULL;
	$address = isset($_POST['address']) ? $_POST['address'] : NULL;
	if ($nameList != NULL && $address != NULL) {	
		$shellCommand = "sudo ipset del " . $nameList . " " . $address;
		exec($shellCommand, $outputShellCommand, $response);
		if ($response === 0)	
			echo $nameList;
	} 
}	
