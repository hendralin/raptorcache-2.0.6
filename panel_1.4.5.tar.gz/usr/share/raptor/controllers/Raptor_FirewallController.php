<?php

use Raptor\Models\FileRp;

class Raptor_Firewall extends Controller 
{

	public function __construct() 
	{
		parent::__construct();
	}

	public function getPage($name)
	{
		require 'models/autoload.php';
		$file = '/etc/raptor/fw.sh';
		$tblShowRules = new FileRp($file);						
		$tblShowRules = array('file_route' => $file, 'table_rules_lst' => $tblShowRules->showRules());

		$this->view->render(get_path_view() . '/firewall', $tblShowRules);	
	}

}