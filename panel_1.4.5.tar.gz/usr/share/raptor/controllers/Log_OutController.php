<?php

require 'models/Session.php';
use Raptor\Models\Session;

class Log_Out extends Controller 
{

	public function __construct() 
	{
		parent::__construct();
	}

	public function getPage($name)
	{
		setcookie("url_link","", time()-3600, $cookiePath);
		unset($_COOKIE['url_link']);

		$objses = new Session();
		$objses->init();

		$objses->destroy();

		$this->view->render(get_path_view().'/log_out');	
	}

}