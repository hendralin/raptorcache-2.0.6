<?php

class GetPage extends Controller {

	public function __construct() {
		parent::__construct();
	}

	public function getPage($name)
	{
		$this->view->render(get_path_view(). '/' . $name);	
	}

}