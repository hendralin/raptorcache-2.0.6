<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
if (!function_exists('dir_path')) {
    include_once '/usr/share/raptor/main/functions.php';
}

require_once get_rp_path().'/main/settings.php';
require_once get_rp_path()."/lang/$deflang.php";
?>
        <table class="tabhdsys" style="" cellspacing="0" >   
          <tr>    
            <th>&nbsp;</th>
            <th><?php echo $sysdisk_dsk; ?></th>
            <th><?php echo $sysdisk_cdir; ?></th>
            <th><?php echo $sysdisk_et;; ?></th>
            <th><?php echo $sysdisk_eu;; ?></th>
            <th><?php echo $sysdisk_el; ?></th>
            <th><?php echo $sysdisk_u; ?></th>
            <th style="border-right:none"><?php echo $sysdisk_temp; ?></th>
          </tr>

<?php 

require_once get_rp_path().'/models/HardDisk.php';
use Raptor\Models\HardDisk;

$hd = new HardDisk();

for ($i=0; $i < $hd->getCountDisk(); $i++) {
  $name_disk = explode("/dev/", $hd->arr_dev_disk[$i]);
  $name_sdx = $name_disk[1];

  $mountHd = $hd->getMountHd($name_sdx);
  $spaceHd = $hd->getSpaceHd($name_sdx);
  $porcent = explode("%", $spaceHd[4]);
  $porcent = $porcent[0];
  if ($porcent != "") $suffix = "%"; else $suffix = "";
  if ($mountHd == 'System') {
    $mountHd = "<span style='color:#2ec2d0;'>".$mountHd."</span>";
    if ($porcent > 95) {
      $porcent = "<span style='color:rgb(252, 69, 69);font-weight:600;'>! {$porcent}{$suffix}</span>";
    } else {
      $porcent = "<span style='color:#2ec2d0;'>{$porcent}{$suffix}</span>";
    }
  } else {
    $mountHd = $mountHd; 
    $porcent = "<span style='color:#2ec2d0;'>{$porcent}{$suffix}</span>";
  }
?>
          <tr>  
            <td style="width:10px;" class="last"><?php echo ""; ?></td> 
            <td class="last"><?php echo $hd->arr_dev_disk[$i]; ?></td>                                        
            <td class="last"><?php echo $mountHd; ?></td>              
            <td class="last"><?php echo $spaceHd[1]; ?></td>              
            <td class="last"><?php echo $spaceHd[2]; ?></td>              
            <td style="color:#5daf48;" class="last"><?php echo $spaceHd[3]; ?></td>     
            <td class="last"><?php echo $porcent; ?></td>  
            <td class="last"><?php echo $hd->getTempHd($name_sdx); ?></td>          
          </tr> 
<?php 
}
?>
       </table>        
