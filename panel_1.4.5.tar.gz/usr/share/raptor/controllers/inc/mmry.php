<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
if (!function_exists('dir_path')) {
    include_once $_SERVER['DOCUMENT_ROOT'].'/main/functions.php';
}

require_once get_rp_path().'/main/settings.php';
require_once get_rp_path()."/lang/$deflang.php";

require_once get_rp_path().'/models/MemoryRam.php';
use Raptor\Models\MemoryRam;

$mem = new MemoryRam();
$mem_value = $mem->getValuesRam();
$swap_values = $mem->getValuesSwap();

  if ($mem_value[2] <= 8) {
    $mem_free = "<span style='color:#FF0000'>".sizeFormat($mem_value[1]). " (" . $mem_value[2] ."%)</span>";
  }    
  else if($mem_value[2] > 8 && $mem_value[2] < 15){
    $mem_free = "<span style='color:orange'>".sizeFormat($mem_value[1]). " (" . $mem_value[2] ."%)</span>";
  }     
  else {
    $mem_free = "<span style='color:#5daf48'>".sizeFormat($mem_value[1]). " (" . $mem_value[2] ."%)</span>";
  }

?>

  <div id="tabmem">
    <table class="tabhdsys" style="" cellspacing="0" >   
    <tr>
      <th><?php echo $mem_mt; ?></th>
      <th><?php echo $mem_mu; ?></th>
      <th><?php echo $mem_ml; ?></th>
      <th><?php echo $mem_mp; ?></th>
      <th><?php echo $mem_mb; ?></th>
      <th style="border-right:none"><?php echo $mem_mc; ?></th>
    </tr> 
    <tr>  
       <td><?php echo sizeFormat($mem_value[0]); ?></td>
       <td><?php echo sizeFormat($mem_value[3]) . " (".$mem_value[4]."%)"; ?></td>
       <td><?php echo $mem_free; ?></td>
       <td><?php echo sizeFormat($mem_value[5]) . $mem_value[6]; ?></td>
       <td><?php echo sizeFormat($mem_value[7]) . $mem_value[8]; ?></td>
       <td style="color:#2ec2d0;"><?php echo sizeFormat($mem_value[9]) . $mem_value[10]; ?></td>             
    </tr> 
    </table> 
  </div>

  <div id="tabmem2">
    <table class="tabhdsys" style="" cellspacing="0" >   
    <tr>
      <th><?php echo $mem_st; ?></th>
      <th><?php echo $mem_su; ?></th>
      <th style="border-right:none"><?php echo $mem_sl; ?></th>
    </tr> 
    <tr>  
       <td><?php echo sizeFormat($swap_values[0]); ?></td>
       <td><?php echo sizeFormat($swap_values[1]) . $swap_values[2]; ?></td>         
       <td><?php echo sizeFormat($swap_values[3]) . $swap_values[4]; ?></td>         
    </tr> 
    </table> 
  </div>
