<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();
if (!function_exists('dir_path')) {
    include_once $_SERVER['DOCUMENT_ROOT'].'/main/functions.php';
}

require_once get_rp_path().'/main/settings.php';
require_once get_rp_path()."/lang/$deflang.php";
?>

<div id="io">
	<table class="sortable">
		<tr><th class="sel_log">Input/Output Stat</th></tr>
	</table>
	<table class="sortable" style='border-top:none;' cellspacing='0'>	                  
		<tr>    
			<th>&nbsp;</th>
			<th>%user</th>
			<th>%nice</th>
			<th>%system</th>    
			<th>%iowait</th>
			<th>%steal</th>
			<th style="border-right:none;">%idle</th>
		</tr>	
<?php 
        $iostat_cpu = shell_exec("iostat -c -y 1 1 | grep -v 'Linux' | sed '/[0-9]/!d' | tail -1 | xargs");
        $iostat_cpu = explode(" ", ltrim($iostat_cpu));        
 ?>
		<tr>    
			<td class="iostat">AVG CPU</td>  
			<td id="user" class="iostat"><?php echo $iostat_cpu[0]; ?></td>
			<td id="nice" class="iostat"><?php echo $iostat_cpu[1]; ?></td>
			<td id="system" class="iostat"><?php echo $iostat_cpu[2]; ?></td>
			<td id="wait" class="iostat"><?php echo $iostat_cpu[3]; ?></td>
			<td id="steal" class="iostat"><?php echo $iostat_cpu[4]; ?></td>
			<td id="idle" class="iostat"><?php echo $iostat_cpu[5]; ?></td>
		</tr>
	</table>
	
	<table class="sortable" style='border-top:none;' cellspacing='0'>	                  
		<tr>    
			<th>Dev.</th>
			<th>rrqm/s</th>
			<th>wrqm/s</th>    
			<th>r/s</th>
			<th>w/s</th>
			<th>rkB/s</th>
			<th>wkB/s</th>			
			<th>await</th>
			<th>r_await</th>
			<th>w_await</th>
			<th>svctm</th>
			<th style="border-right:none;">%util</th>
		</tr>	
<?php 
	//$count_disk = shell_exec("sudo fdisk -l | grep -Ee '/dev/sd[a-z]:' | grep 'iB' | grep -v '/dev/dm-0' | grep -v '/dev/mapper/' | wc -l");
	$count_disk = shell_exec("sudo fdisk -l /dev/sd? | egrep '/dev/sd[a-z]:' | cut -d: -f1 | awk '{print $2}' | wc -l");
	//$dev_disk = shell_exec("sudo fdisk -l /dev/sd? | egrep '/dev/sd[a-z]:' | grep 'iB' | awk '{print $2}' | sed -e 's/://g'");
	$dev_disk = shell_exec("sudo fdisk -l /dev/sd? | egrep '/dev/sd[a-z]:' | cut -d: -f1 | awk '{print $2}'");
	$dev_disk = explode("\n", $dev_disk);
	$total_items = 0;
	for ( $i=0; $i < $count_disk ; $i++ ) {
		$name_disk = explode("/dev/", $dev_disk[$i]);
		$name_disk_sdx = $name_disk[1];
        $iostat = shell_exec("iostat -x -d -k -y 1 1 $name_disk_sdx | tail -2 | xargs");
        $iostat = explode(" ", $iostat);
		if ( round($iostat[13]) < 50 ) {
			$util = "<span style='color:#92C443;'>".$iostat[13]."</span>";
		} else if ( round($iostat[13]) < 80 ) {
			$util = "<span style='color:#f99e61;'>".$iostat[13]."</span>";		
		} else {
			$util = "<span style='color:#fb5050;'>".$iostat[13]."</span>";		
		}
 ?>
		<tr>    
			<td class="iostat">/dev/<?php echo $iostat[0]; ?></td>
			<td class="iostat"><?php echo $iostat[1]; ?></td>
			<td class="iostat"><?php echo $iostat[2]; ?></td>
			<td class="iostat"><?php echo $iostat[3]; ?></td>
			<td class="iostat"><?php echo $iostat[4]; ?></td>
			<td class="iostat"><?php echo $iostat[5]; ?></td>
			<td class="iostat"><?php echo $iostat[6]; ?></td>
			<td class="iostat"><?php echo $iostat[7]; ?></td>			
			<td class="iostat"><?php echo $iostat[10]; ?></td>
			<td class="iostat"><?php echo $iostat[11]; ?></td>
			<td class="iostat"><?php echo $iostat[12]; ?></td>
			<td class="iostat"><?php echo $util; ?></td>
		</tr>			  
<?php 
		$total_items++;
	}
	echo "<table class='t_footer' style='border:1px solid #afafaf;padding:3px 8px'><tr><td colspan='7'>{$total_items}&nbsp;" . (($total_items > 1) ? $txt='devices' : $txt='device') . "</td></tr></table>";
?>
	</table>
</div>