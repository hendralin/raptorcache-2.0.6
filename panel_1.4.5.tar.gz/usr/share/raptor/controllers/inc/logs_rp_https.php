<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
error_reporting(0);

echo "<table id='log_ajx_https' class='sortable body_log' cellspacing='0'>";
	echo "<tr>";
		echo "<th>&nbsp;</th>";
		echo "<th>Date/Time</th>";
		echo "<th>IP</th>";
		echo "<th>State</th>";
		echo "<th>Type</th>";
		echo "<th>Domain</th>";
		echo "<th>File</th>"; 
		echo "<th style='border-right:none;'>Size</th>";		
	echo "</tr>";

	exec("sudo bash /etc/raptor/upLogs.sh", $outputShellCommand, $response);

	if ( $response === 0 ) {
		$jumplog = file('/etc/raptor/jumplog');
		$logfile = file("/dev/shm/rptlgs");
		$pos = 0;
        for ( $i = sizeof($logfile); $i > 0; $i-- ) {   
        	if ($pos >= 60) 
        		continue;    
			foreach ($jumplog as $value) {
				if (strpos($logfile[$i - 1], trim($value)) !== FALSE) 
					continue 2;
			}				    	    
			$row = trim($logfile[$i - 1]);
			$rw = explode(" ", $row);
			$timestamp = $rw[0];
			$date = "<pre style='font-family:Verdana;font-size:12px;margin:0;padding:0;'>".date("d/m/Y", $timestamp)." ".date("H:i:s", $timestamp)."</pre>";
			$state = $rw[2];
			$type = "HTTPS";
			$url = explode("://" , $rw[5]);	
			if (strlen($url[1]) > 32) 
				$file = ".../ ".substr($url[1], -31);
			else
				$file = $url[1];			
			$urlhttps = explode("/", $url[1]);
			$urlhttps = explode(".", $urlhttps[0]);
			$countDom = count($urlhttps);
			if (strlen($urlhttps[$countDom-1]) == 2)
	        	$domain = $urlhttps[$countDom-3] . '.' . $urlhttps[$countDom-2] . '.' . $urlhttps[$countDom-1];
			else 	
				$domain = $urlhttps[$countDom-2] . '.' . $urlhttps[$countDom-1];
			$size_file = $rw[6];
			if ($size_file > 0) {         	
				if ($size_file < 1024)
					$size_file = $size_file." bytes";				
				else if ($size_file < (1024*1024))				
					$size_file = round($size_file/1024,2)." KiB";				
				else if ($size_file < (1024*1024*1024))				
					$size_file = round($size_file/(1024*1024),2)." MiB";				
				else if ($size_file < (1024*1024*1024*1024))				
					$size_file = round($size_file/(1024*1024*1024),2)." GiB";
				else	
					$size_file = round($size_file/(1024*1024*1024*1024),2)." TiB";				
			} else {
				$size_file = 0;
			}

			$ip = $rw[7];

			if ($state == 'TCP_HIT/200' || $state == 'TCP_MEM_HIT/200' || $state == 'MEM_HIT/200' || $state == 'TCP_HIT/206') {
				$state = 'HIT/200';
			echo "<tr class='row' >" ;
				echo "<td style='width:20px;' class='c_red'><span class='icon-upload'></td>";
				echo "<td style='width:140px;' class='c_red'>".$date."</td>";				
				echo "<td style='width:110px;' class='c_red'>".$ip."</td>";
				echo "<td style='width:72px;' class='c_red'>".$state."</td>";
				echo "<td style='width:72px;' class='c_red'>".$type."</td>";
				echo "<td style='width:160px;' class='c_red'>".$domain."</td>";
				echo "<td style='text-align:left;width:240px;' class='c_red'>".$file."</td>";
				echo "<td style='width:84px;' class='c_red'>".$size_file."</td>";
			echo "</tr>";
			} else if ($state == "MISS/206") {
			echo "<tr class='row' >" ;
				echo "<td style='width:20px;' class='c_green'><span class='icon-download'></td>";	
				echo "<td style='width:140px;' class='c_green'>".$date."</td>";					    
				echo "<td style='width:110px;' class='c_green'>".$ip."</td>";
				echo "<td style='width:72px;' class='c_green'>".$state."</td>";
				echo "<td style='width:72px;' class='c_green'>".$type."</td>";
				echo "<td style='width:160px;' class='c_green'>".$domain."</td>";
				echo "<td style='text-align:left;width:240px;' class='c_green'>".$file."</td>";
				echo "<td style='width:84px;' class='c_green'>".$size_file."</td>";
			echo "</tr>";
			} else if ($state == "MISS/302" || $state == "MISS/304" ||$state == "DELETED" || $state == "REDIRECT") {
			echo "<tr class='row' >" ;
				echo "<td style='width:20px;' class='c_orange'><span class='icon-download'></td>";	
				echo "<td style='width:140px;' class='c_orange'>".$date."</td>";					    
				echo "<td style='width:110px;' class='c_orange'>".$ip."</td>";
				echo "<td style='width:72px;' class='c_orange'>".$state."</td>";
				echo "<td style='width:72px;' class='c_orange'>".$type."</td>";
				echo "<td style='width:160px;' class='c_orange'>".$domain."</td>";
				echo "<td style='text-align:left;width:240px;' class='c_orange'>".$file."</td>";
				echo "<td style='width:84px;' class='c_orange'>".$size_file."</td>";
			echo "</tr>";
			} else {
				$state = "MISS/200";
			echo "<tr class='row'>";
				echo "<td style='width:20px;' class='c_blue'><span class='icon-download'></td>";		    
				echo "<td style='width:140px;' class='c_blue'>".$date."</td>";
				echo "<td style='width:110px;' class='c_blue'>".$ip."</td>";
				echo "<td style='width:72px;' class='c_blue'>".$state."</td>";
				echo "<td style='width:72px;' class='c_blue'>".$type."</td>";
				echo "<td style='width:160px;' class='c_blue'>".$domain."</td>";
				echo "<td style='text-align:left;width:240px;' class='c_blue'>".$file."</td>";
				echo "<td style='width:84px;' class='c_blue'>".$size_file."</td>";
			echo "</tr>";
			}
			$pos++;
        }
    }  else {
    	echo "<tr class='row'>";
			echo "<td style='width:20px;' colspan='7'>No data available</td>";
		echo "</tr>";		
    }  
        echo "</table>";
        
 ?>
