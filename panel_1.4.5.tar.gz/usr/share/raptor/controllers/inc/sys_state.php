<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

if (!function_exists('get_rp_path')) {
    require '/usr/share/raptor/main/functions.php';
    require_once '/usr/share/raptor/main/settings.php';
}

require_once get_rp_path()."/lang/{$deflang}.php";
require_once get_rp_path().'/models/autoload.php';

use Raptor\Models\SyState;
use Raptor\Models\NetStat;
use Raptor\Models\MemoryRam;

$sys = new SyState();
$net = new NetStat();

?>

<div id="tbsys">  

  <div class="cpustate1">        
        <table>                    
          <tr>
            <th><div id="im1a"></div><?php echo $vit_er; ?></th>
            <td><p id= "stat_cache_rp" class="first_block"><?php echo $sys->stat_cache("8080"); ?></p></td>
            <td><p id="version_rp" class="first_block"><?php echo $sys->version_rp(); ?></p></td>
          </tr>
          <tr>
            <th><div id="im2a"></div><?php echo $vit_es; ?></th>
            <td><p id="stat_cache_sq" class="first_block"><?php echo $sys->stat_cache("3128"); ?></p></td>
            <td><p id="version_sq" class="first_block"><?php echo $sys->version_sq(); ?></p></td>      
          </tr>        
          <tr>
            <th><div id="im3a"></div><?php echo $vit_con; ?></th>
            <td><p id="cnx_us" class="first_block"><?php echo $net->cnx_us(); ?></p></td>  
            <td><p id="open_threads_netstat" class="first_block"><?php echo $net->open_threads_netstat(); ?></p></td>          
          </tr>            
          <tr>
            <th><div id="im4a"></div><?php echo $vit_us; ?></th>
            <td><p id="num_us" class="first_block"><?php echo $net->num_us(); ?></p></td>
            <td></td>
          </tr>        
        </table>
  </div>

    <div class="cpustate2">        
      <table>                              
        <tr>
          <th><div id="im1b"></div><?php echo $vit_dns; ?></th>
          <td><p id="cnx_dns" class="first_block"><?php echo $net->cnx_dns(); ?></p></td>            
        </tr>       
        <tr>
          <th><div id="im2b"></div><?php echo $vit_tact; ?></th>
          <td><p id="uptime" class="first_block"><?php echo $sys->uptime(); ?></p></td>            
        </tr>
        <tr>
          <th><div id="im3b"></div><?php echo $vit_temp; ?></th>
          <td><p id="cpu_temp" class="first_block"><?php echo $sys->cpu_temp(); ?></p></td>            
        </tr>
        <tr>
          <th><div id="im4b"></div><?php echo "&nbsp;I/O"; ?></th>
          <td><p id="io_cpu" class="first_block"><?php echo percC($sys->io_cpu()); ?></p></td>            
        </tr>        
      </table>
    </div>

  <div class="sysbar">
    <table>
    <tr>
      <td class="bartitle">L.A.</td>
      <td>
        <div class="charts-round charts-container">
          <div class="charts-wrapper 1m">
            <span id="avg_1m" class="label"><?php echo $avg['1m']; ?>%</span>
            <span class="label-time">1 Min</span>
            <div class="charts-pie">
              <div class="left-side half-circle"></div>
              <div class="right-side half-circle"></div>
            </div>
            <div class="shadow 1m"></div>
          </div>
          <div class="charts-wrapper 5m">
            <span id="avg_5m" class="label"><?php echo $avg['5m']; ?>%</span>
            <span class="label-time">5 Min</span>
            <div class="charts-pie">
              <div class="left-side half-circle"></div>
              <div class="right-side half-circle"></div>
            </div>
            <div class="shadow 5m"></div>
          </div>          
          <div class="charts-wrapper 15m">
            <span id="avg_15m" class="label"><?php echo $avg['15m']; ?>%</span>
            <span class="label-time">15 Min</span>
            <div class="charts-pie">
              <div class="left-side half-circle"></div>
              <div class="right-side half-circle"></div>
            </div>
            <div class="shadow 15m"></div>
          </div>          
        </div>
      </td>
    </tr>

    <tr><td class="bartitle" style="">CPU</td>
        <td>
          <div class="graphcpu1">  
            <div id="cpubar" class="bar" style='width: <?php $cpu_usage = $sys->cpu_bar(); echo $cpu_usage[0]; ?>%;'> <?php echo $cpu_usage[1]; ?></div>
          </div>
        </td>
    </tr>

    <tr><td class="bartitle" style="">RAM</td>
    <?php 
          $mem = new MemoryRam();
          $mem_value = $mem->getValuesRam();
    ?>
        <td>
          <div class="graphm1">  
            <div id="membar" class="bar" style="width: <?php echo $mem_value[4]; ?>%;"> <?php echo $mem_value[4]; ?>%</div>
          </div>
        </td>
    </tr>

    </table>
  </div>

</div>
