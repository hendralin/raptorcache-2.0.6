<?php

use Raptor\Models\StoreHTTPS;

class Store_HTTPS extends Controller
{
    private $obj;

    public function __construct()
    {
        parent::__construct();
    }
    
	public function savePostAction()
	{
		print_r($_POST);


	}

    public function getPage($name)
    { 
        require 'models/autoload.php';
        $file = '/etc/raptor/idst.pl';
        $this->obj = new StoreHTTPS($file);

		if (isset($_POST['new_regex_pl']) && $_POST['new_regex_pl'] == '1') {			
			$file = $_POST['file'];
			$name = $_POST['name'];
			$regex = $_POST['regex'];
			$this->obj->insertRegex($file, $name, $regex);					
			header("location: Store_HTTPS");
		} 		
		if (isset($_POST['edit_regex_pl']) && $_POST['edit_regex_pl'] == '1') {	
			$file = $_POST['file'];
			$idregex = $_POST['idregex'];			
			$name = $_POST['name'];
			$regex = $_POST['regex'];
			$this->obj->editRegex($file, $idregex, $name, $regex);					
			header("location: Store_HTTPS");			
		}	

        $tblShowRegex = array('file_regex' => $file, 'table_regex_lst' => $this->obj->showRules());        
        $this->view->render(get_path_view() . '/' . $name, $tblShowRegex);		
    }
    
}