<?php 

class Sanitize 
{
	private $result;
	private $quit;

	public function string_sanitize($string) 
	{
		$this->result = stripslashes($string);
		$this->quit = array('\'', '"', '%');
		$this->result = str_replace($this->quit, '', $this->result);
		$this->result = filter_var($this->result, FILTER_SANITIZE_STRING);
		return $this->result;
	}
}

 ?>