<?php 

	$url = $getUrl;
	$url = rtrim($url, '/');
	$url = explode('/', $url);

	if (count($url) > 2) {
		header('location: /');
		exit();
	}

	$rolName = $url[0];
	if ($rolName == "" || $rolName == "i") {
		$rolName = "index";
	}
/*
 var $fileName eq Class Name Controller - ControllerSystem
 */
	$fileName = isset($url[1]) ? $url[1] : null ;
	if ($fileName != '' || $fileName != null) {
		switch ($url[1]) {
			case 'System':
				$fileName = 'system';	
				break;	
			case 'Getpage':
				$fileName = 'getpage';
				break;								
			case 'Domains':
				$fileName = 'domains';
				break;				
			case 'Storage':
				$fileName = 'storage';
				break;									
			case 'Request':
				$fileName = 'request';
				break;									
			case 'Threads':
				$fileName = 'threads';
				break;	
			case 'Network_Traffic':
				$fileName = 'network_Traffic';
				break;	
			case 'SSL':
				$fileName = 'ssl';
				break;			
			case 'SUMMARY_SSL':
				$fileName = 'summary_Ssl';
				break;		
			case 'SUMMARY_HTTP':
				$fileName = 'summary_Http';
				break;		
			case 'Raptor_Conf':
				$fileName = 'raptor_Conf';
				break;
			case 'Raptor_List':
				$fileName = 'raptor_List';
				break;	
			case 'Raptor_AddressList':
				$fileName = 'raptor_AddressList';
				break;					
			case 'Raptor_WhiteList':
				$fileName = 'raptor_WhiteList';
				break;	
			case 'Raptor_BlackList':
				$fileName = 'raptor_BlackList';
				break;	
			case 'Store_HTTPS':
				$fileName = 'store_HTTPS';
				break;				
			case 'Raptor_Firewall':
				$fileName = 'raptor_Firewall';
				break;	
			case 'Squid_Conf':
				$fileName = 'squid_Conf';
				break;	
			case 'Monitor_Hard_Disk':
				$fileName = 'monitor_Hard_Disk';
				break;
			case 'Monitor_Hard_Disk_IO':
				$fileName = 'monitor_Hard_Disk_IO';
				break;	
			case 'Log_Access_HTTP':
				$fileName = 'log_Access_HTTP';
				break;										
			case 'Log_Access_HTTPS':
				$fileName = 'log_Access_HTTPS';
				break;										
			case 'Log_Error':
				$fileName = 'log_Error';
				break;										
			case 'Log_System':
				$fileName = 'log_System';
				break;									
			case 'Num_Conection_Users':
				$fileName = 'num_Conection_Users';
				break;									
			case 'Ping_DNS':
				$fileName = 'ping_Dns';
				break;									
			case 'Backup_Database':
				$fileName = 'backupBd';
				break;																				
			case 'Update':
				$fileName = 'update';
				break;						
			case 'Update_Manual':
				$fileName = 'update_Manual';
				break;						
			case 'Licence':
				$fileName = 'licence';
				break;		
			case 'Shutdown':
				$fileName = 'shutdown';
				break;										
			case 'Network_Config':
				$fileName = 'network_Config';
				break;					
			case 'DNS_Config':
				$fileName = 'Dns_Config';
				break;				
			case 'Mount_Disk':
				$fileName = 'mount_Disk';
				break;		
			case 'Scheduler':
				$fileName = 'scheduler';
				break;									
			case 'Mikrotik_List':
				$fileName = 'mikrotik_List';
				break;								
			case 'Users_Config':
				$fileName = 'users_Config';
				break;				
			case 'Language_Config':
				$fileName = 'language_Config';
				break;			
			case '*Conf_Man_775_*':
				$fileName = 'mnl_cnf';
				break;						
			case 'Log_Out':
				$fileName = 'log_Out';
				break;	
		}		
	}	   

 ?>