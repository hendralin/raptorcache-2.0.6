<?php 

class Routes
{

	public static $_url = array();
	private static $_instance; //The single instance

	/**
	 * Extract the URL parameters from $from and copy to $to
	 */
	public static function parameterfy($from, $to)
	{
		if (preg_match_all('/\/\((.*?)\)/', $from, $matches))
		{
			$params = '';

			foreach ($matches[1] as $i => $match)
			{
				$i = $i + 1;
				$params .= "/\$$i";
			}

			$to .= $params;
		}

		return $to;
	}

	public function _methodIs($method)
	{
		return (isset($_SERVER['REQUEST_METHOD']) &&
					   ($_SERVER['REQUEST_METHOD'] == $method ||
					   		($_SERVER['REQUEST_METHOD'] == 'POST' &&
					   		isset($_POST['_method']) &&
					   		strtolower($_POST['_method']) == strtolower($method))));
	}

	public static function get()
	{
		if (self::_methodIs('GET'))
		{
			 print_r($_GET);
		}
	}

	public function __construct ()
	{
		$url = isset($_GET['url']) ? $_GET['url'] : null ;
		$url = rtrim($url, '/');
		self::$_url = explode('/', $url);
	}

	public static function getRoute($NavUrl, $filename)
	{
		if(!self::$_instance) { // If no instance then make one
			self::$_instance = new self();
		} 

		$urlRoleName = self::$_url[0];

		if ($urlRoleName == "" || $urlRoleName == "i") {
			$urlRoleName = "index";
			exit();
		}		

		if (is_array(self::$_url) && count(self::$_url) <= 2) {
			if (self::$_url[1] == $NavUrl) {
				self::$_url[1] = $filename;
				echo self::$_url[1];
			} else {
				echo "Error...";
			}								
		} else {
			header('location: /');
			exit();
		}	
	}

}

 ?>


