<?php
/**
*
* @package Main Raptorcache
* @since 1.4
*/

require "public/global/above.php";
?>

  <div id="tbod">

<?php

require get_rp_path().'/models/autoload.php';
use Raptor\Models\UpdateRp;
use Raptor\Models\FileRp;

$rp = new UpdateRp();

$cloud_version = "";

if ( $rp->isConnSocketServer(5) ) {
	$rp->getLocalVersion(new FileRp);
    $cloud_version = $rp->getCloudVersion();	
	$rp->check_update();
} else {
    $cloud_version = $rp->get_file_info();
    echo "<div id='case_error'>! {$serverErr}</div>";
}

?>

      <div id="case_restart_alert"></div>

      <div class="tab_config">
        <table class="t_head">
          <tr>
            <th colspan=7 class="tabtit"><span class="icon-publish"></span>
              <?php echo "Update"; ?>
            </th>
          </tr>
          <tr>
            <th colspan=7 class="tabtitleline">
              <hr>
            </th>
          </tr>
        </table>

        <table class="t_body">
          <tr>
            <td>
<?php

	$token = sha1(time());
	echo "<div id='alert_update' style='display:none;'></div>";
	echo "<table id='tbl_update' class='sortable' cellspacing='0' style='border-radius:2px;width:400px;margin-left:10px;'>";
	echo "<tr>
	<th>Module</th>
	<th>Versi&oacute;n</th>
	<th style='border-right:none;'></th>
	<th style='border-right:none;'></th>
	</tr>";
	echo "<tr class='row t_core'>
	<td style='padding:6px'>"."Core Raptor"."</td>
	<td>{$cloud_version['core']}</td>
	<td class='update'>";
	if ($rp->update_core == true) {
		echo "<a href='#' class='update_v' data-update='core' title='Update Core'><span class='icon-cog'></span></a>";
	} else {
		echo "<span class='unactive'><span class='icon-cog'></span></span>";
	}
	echo "</td>
	<td class='update'><a id='go' class='coreLog' name='coreLog' href='#coreLog'><span class='icon-file-text-o'></span></a>
	</td></tr>";
	echo "<tr class='row t_panel'>
	<td style='padding:6px'>"."Webpanel Raptor"."</td>
	<td>{$cloud_version['panel']}</td>
	<td class='update'>";
	if ($rp->update_panel == true) {
		echo "<a href='#' class='update_v' data-update='panel' title='Update Panel'><span class='icon-cog'></span></a>";
	} else {
		echo "<span class='unactive'><span class='icon-cog'></span></span>";
	}
	echo "</td>
	<td class='update'><a id='go' class='panelLog' name='panelLog' href='#panelLog'><span class='icon-file-text-o'></span></a>
	</td></tr>";
	echo "<tr class='row t_services'>
	<td style='padding:6px'>"."Services"."</td>
	<td>{$cloud_version['services']}</td>
	<td class='update'>";
	if ($rp->update_services == true) {
		echo "<a href='#' class='update_v' data-update='services' title='Update Services'><span class='icon-cog'></span></a>";
	} else {
		echo "<span class='unactive'><span class='icon-cog'></span></span>";
	}
	echo "</td>
	<td class='update'><a id='go' class='servicesLog' name='servicesLog' href='#servicesLog'><span class='icon-file-text-o'></span></a>
	</td></tr>";
	echo "</table>";

?>
            </td>
          </tr>
          <tr>
            <td style="padding-left:16px;text-align:left;">
              <a class="btn-default" href="Update_Manual">
                <button><span class="icon-triangle-right"></span>&nbsp;
                  <?php echo $str_update; ?> Manual</button>
              </a>
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table>

        <div class="coreLogDiv" title="Core changelog"></div>
        <div class="panelDiv" title="WebPanel changelog"></div>
        <div class="servicesDiv" title="Services changelog"></div>

	<?php require "public/global/form/rp.update.js.php"; ?>

        <script>

        </script>

        <link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
        <script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script>

      </div>

      <div id="footer">
        <p>
          <?php echo $cop; ?>
        </p>
      </div>

  </div>
  <!-- END TBOD -->

  <br>

  </div>
  <!-- ALL -->

  </body>

  </html>