<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();
?>

<?php require "public/global/above.php"; ?>


<div id="tbod"> 

<div id="case_alert"></div>

<div class="tab_config">
  <table class="t_head">
    <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span>&nbsp;Raptor.conf</th></tr>
    <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
  </table>
  <table class="t_body" cellspacing='0'>
    <tr>
    <td id="confrp_td">
      
    <div class="confrp">

    <form id="rpConf">
      <table class="options">
        <tr>
          <td>CACHE_LIMIT</td>
          <td>
            <input name="cache_limit" type="text" value="<?php echo $this->value["CACHE_LIMIT"]; ?>">&nbsp;%&nbsp;&nbsp;&nbsp;&nbsp;
          </td>
        </tr> 
        <tr>
          <td>MIN_OBJECT_SIZE</td>
          <td><input name="min_object_size" type="text" value="<?php echo $this->value["MIN_OBJECT_SIZE"]; ?>">&nbsp;Bytes</td>
        </tr>
        <tr>
          <td></td>
          <td><span class="btn-default-only"><button id="enviar" name="rp_submit" type="button" onclick="setConf('rpConf','Raptor_Conf')"><span class="icon-floppy-o"></span>&nbsp;<?php echo $bt_grd; ?></button></span></td>
        </tr>   
      </table>
    </form>

    <?php include 'public/global/set.ajx.php'; ?>

     </div> 

    </td>
    </tr>
    
  </table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "global/below.php"; ?>
