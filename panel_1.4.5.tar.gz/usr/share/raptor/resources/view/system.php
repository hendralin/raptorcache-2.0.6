<?php
/**
 *
 * @author joemg http://www.raptorcache.org
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 

require_once get_rp_path()."/lang/{$deflang}.php";
require_once get_rp_path().'/models/autoload.php';

use Raptor\Models\SyState;
use Raptor\Models\NetStat;
use Raptor\Models\MemoryRam;

$sys = new SyState();
$net = new NetStat();

$avg = $sys->system_load();

 ?>

<div id="tbod"><!-- TBOD --> 

<div id="sys_state"><!-- VIT -->  
<?php include get_rp_path().'/controllers/inc/sys_state.php'; ?>
</div>

<div style="clear: both"></div>


<!--<div id="ln"><hr></div>-->

  <div id="bandwd">
    <table> 
      <tr><td>
        <iframe src="../chart/bandwidth/index.php" ></iframe>
      </td></tr>
    </table>
  </div>

<!--<div id="ln"><hr></div>-->

<div id="memory"><!-- MEM-->
<?php include get_rp_path().'/controllers/inc/mmry.php'; ?>
</div><!-- END MEM-->

<br>

<!--<div id="ln"><hr></div>-->

<!-- HD -->
  <div id="tabhd">

<div id="hard_disk_system">  
<?php include get_rp_path().'/controllers/inc/hds.php'; ?>
</div>        

  </div>
<!--end HD -->

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- TBOD -->

<br>

</div><!-- ALL --> 

<script type="text/javascript" src="<?php echo get_view_link(); ?>/js/runSys.js"></script>  

</body>
</html>
