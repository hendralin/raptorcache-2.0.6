<?php
/**
*
* @package Main Raptorcache
* @since 1.4.4
*/

require "public/global/above.php";
?>

  <link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
  <script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script>

  <div id="tbod">
<?php
	include get_rp_path().'/public/global/alert_case.php'; 
?>
      <div class="tab_config">
        <table class="t_head">
          <tr>
            <th colspan=9 class="tabtit"><span class="icon-list-ul"></span>&nbsp;Address list</th>
          </tr>
          <tr>
            <th colspan=9 class="tabtitleline">
              <hr>
            </th>
          </tr>
        </table>
        <table class="sortable">
          <tr>
            <th class="log" style="width:32px;">List: </th>
            <th class="sel_log">
              <form action="Raptor_AddressList" method="GET" class="link">
                <select name="list" id="list" onchange="this.form.submit();">
                  <option value=""></option>
				  <?php
					$listName = $this->value["list_name"];
					foreach ($listName as $value) {
						echo "<option value=\"{$value}\">{$value}</option>";
					}
				  ?>
                </select>
              </form>

            </th>
          </tr>
        </table>
           <table class='sortable' cellspacing='0' style='border-top:none;'>
            <tr>
            <th>&nbsp;</th>
            <th style='text-align:left;'>Name</th>
            <th style='text-align:left;'>Address</th>
            <th style='text-align:left;width:320px;'>&nbsp;</th>
            <th style='border-right:none;padding: 2px 4px;'></th>
            </tr>
<?php
		$name = $this->value["name"];
		$arrline = $this->value["list_items"];
		if ($name != NULL) {
			$items = 0;
			for ($i=0; $i < count($arrline); $i++) {            
				echo "<tr class='row'>
				<td style='width:40px;'>"."</td>
				<td style='text-align:left;width:180px;'>".$name."</td>
				<td style='text-align:left;width:180px;'>".$arrline[$i]."</td>
				<td style='width:380px;'>&nbsp;</td>
				<td style='width:22px;'><a href='#' data-list='{$name}' data-address='{$arrline[$i]}' class='del_address'>X</a></td>
				</tr>";
				$items++;
			}
			echo "<table class='t_footer'><tr><td colspan='5'>{$items}&nbsp;" . (($items > 1) ? $txt='items' : $txt='item') . "</td></tr></table>";
		} else {
        	echo "<tr class='row'><td colspan='5'>Select Address List.</td></tr>";			
		}	
?>
        </table>
        	<span class="btn-default"><button class="addAddressName"><span class="icon-plus"></span>&nbsp;New Address List</button></span>&nbsp;
        	<span class="btn-default"><button class="addAddressItem"><span class="icon-plus"></span>&nbsp;Add Address Item</button></span>&nbsp;

        	<div class="addAddressNameDiv" title="New Address List"></div>
        	<div class="addAddressItemDiv" title="Add Address Item"></div>

    	</div>

	</div>

	</div>

  <?php require "public/global/form/rp.modal.js.php"; ?>
  <script src="<?php echo get_view_link(); ?>/js/rptbl.ajx.js"></script>

    </body>

    </html>