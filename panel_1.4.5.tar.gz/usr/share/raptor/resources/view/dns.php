<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require 'public/global/above.php'; 

require get_rp_path().'/models/autoload.php';
use Raptor\Models\Network;

$network = new Network();

?>

<div id="tbod"> 

<?php 
  include get_rp_path().'/public/global/alert_case.php'; 
  if (isset($_GET['accion-flush'])) {
    echo "<div id='loading' style='display:none;'><div class='icon-widget r-spin'></div> Flush Cache</div>";
    shell_exec( "sudo rndc flush" ); 
    echo "<script>case_alert('loading', 'DNS_Config', '1000');</script>";  
  } 
?>

<div class="tab_config">

		<table class="t_head" style="width:300px;" >
		  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> DNS Cache</th></tr>
		  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
		</table>

<?php 
echo '<form action="dns_ch.req" method="POST">';
echo '<table style="width:300px;padding:10px;border-radius:2px;">';
if ($network->isDNScache() == true) {
echo '<td>	
	<div style="margin:auto;" class="container_switch">
    <label class="switch">
      <input type="checkbox" id="dns" name="status" class="switch-input" checked>
      <input type="hidden" name="dns_cache_stat" value="1">
      <span class="switch-label" data-off="Off" data-on="On" ></span>
      <span class="switch-handle"></span>
    </label>
  	</div>
	</td>';
} else {    	
echo '<td>	
	<div style="margin:auto;" class="container_switch">
    <label class="switch">
      <input type="checkbox" id="dns" name="status" class="switch-input">
      <input type="hidden" name="dns_cache_stat" value="0">
      <span class="switch-label" data-off="Off" data-on="On" ></span>
      <span class="switch-handle"></span>
    </label>
  	</div>
	</td> ';	
}
echo '</table>'; 
echo '</form>'; 
 ?>
				
<script>
$('#dns').change(function() {
  $(this).closest("form").submit();
});	
</script>
		<a class="btn-default" href="DNS_Config?accion-flush=flush_dns"><button class="flushCache"><span>Flush Cache</span></button></a>

	<table class="t_head" style="width:300px;margin-top: 10px;" >
	  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> DNS</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
<?php 
$network->show_dns_address();
?>
  <span class="btn-default"><button class="addDNS"><span class="icon-refresh"></span> <?php echo $bt_act; ?></button></span>
	<div class="addDNS-Div" title="<?php echo $up_dns; ?>"></div>	

<script>
  $( function() {
    var smallDiv, 
    smallDiv = $( ".addDNS-Div" ).dialog({
      autoOpen: false,
      height: 192,
      width: 268,
      modal: true,
      open: function () {             
                $(".addDNS-Div").load('../public/global/form/addDNS.php');                   
            },       
      buttons: {
       "<?php echo $bt_grd; ?>": function() {
          if(!$('#dns2').val()) {  
            alert('Please, insert DNS');
            return false;  
          } else {
            $("#addDNS-Form").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addDNS" ).on( "click", function() {
      smallDiv.dialog( "open" );
    });   
  });   
</script>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 

</div>

<hr>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>