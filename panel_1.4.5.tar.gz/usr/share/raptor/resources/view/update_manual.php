 <?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
 
require "public/global/above.php"; 
?>

<?php
$up_bin_dir  = "/var/tmp/upld/";
$up_bin_file = $up_bin_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk    = 1;
$binFileType = pathinfo($up_bin_file,PATHINFO_EXTENSION);

?>
	
<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<?php 
if(isset($_GET['submit_update'])){
	if ($_GET['accion'] == "upload") {

			$rest = "";
			$rest = shell_exec("sudo bash /etc/raptor/run.v/up_manual.sh");
			//echo "<pre>".$rest."</pre>";
		
		if ($rest != "" || $resr != NULL) {
			if (preg_match("/FinishUpdate/", $rest)) {
				echo "<div id=\"loading\"><div class=\"icon-widget r-spin\"></div> Update Core</div>";
				echo "<div id=\"loading\" class=\"rp_restart\"style=\"display:none;\"><div class=\"icon-widget r-spin\"></div> Restarting Raptor</div>";
				echo "<script>
				$(document).ready(function() { 
				    setTimeout(function() { 
						$('#loading').fadeOut( 'slow', function() {
	                    	$('.rp_restart').css('display', 'inline-block');
		                    	setTimeout(function() { 
		                    		$('.rp_restart').fadeOut( 'slow', function() {
										window.location='Update_Manual';
		                    		});
		                    	}, 3000);
		  					});   					        	
				 	}, 3000);
				});
				</script>";	
				//$rest2 = shell_exec("sudo bash /etc/raptor/shut_r.sh");	
				//echo "<pre>".$rest2."</pre>";
			}	
		} else {
				echo "<div id=\"error\"><div class=\"icon-widget r-spin\"></div> Error Update...</div>";
				echo "<script>case_alert(\"error\", \"Network_Config\", \"2000\");</script>";					
		}
	}
} 
 ?>

<div class="tab_config">
	<table style="margin-top:8px;border-radius:3px 3px 0 0;" >
  	<tr><th colspan=7 class="tabtit"><span class="icon-publish"></span> <?php echo "Update Manual"; ?></th></tr>
  	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>

	<table>
		<tr><td style="padding-top:10px;">&nbsp;</td></tr>	
		<tr>
			<td style="padding-left:30px;">			
				<form action="Update_Manual" method="post" enctype="multipart/form-data">
    				<input type="file" name="fileToUpload" id="fileToUpload" style="background: #FFF; border:1px solid #AFAFAF;padding:0 10px 0 0"> 
					<button type="submit" name="submit_file"><span class="icon-upload-1"></span>&nbsp;Upload</button>
				</form>
			</td>
		</tr>			
		<tr>
			<td style="padding:10px 0 0 30px;">
<?php 
if (isset($_FILES["fileToUpload"]["name"]) && isset($_POST["submit_file"])) {
	// Check if file already exists
	if (file_exists($up_bin_file)) {
	    //echo "Sorry, file already exists.";
	    if(!isset($_GET['submit_update'])){
	/***** CHANGE DIR UPLD *******/	    	
	    	shell_exec("rm -f /var/tmp/upld/*.tar.gz");
		}
	    //$uploadOk = 0;
	}

	$uploadedFile = $_FILES["fileToUpload"]["name"];	
	// Check file size
	if ($_FILES["fileToUpload"]["size"] > 500000000) {
	    $err_msj = "<span style='color:#FF0000'>Fail, bad file.</span>";
	    $uploadOk = 0;
	}
	else if ($_FILES["fileToUpload"]["size"] < 50) {
	    $err_msj = "<span style='color:#FF0000'>No file.</span>";
	    $uploadOk = 0;
	}	
	else if (!preg_match("/raptor/", $uploadedFile)) {
	    $err_msj = "<span style='color:#FF0000'>Fail, no core file.</span>";
	    $uploadOk = 0;
	}	
	// Allow certain file formats
	else if($binFileType != "gz") {
	    $err_msj = "<span style='color:#FF0000'>Fail, no bin file.</span>";
	    $uploadOk = 0;
	}	
	// Check if $uploadOk is set to 0 by an error
	if ($uploadOk == 0) {
		echo $err_msj;
	    echo "<span style='color:#FF0000'> Your file was not uploaded.</span>";
	// if everything is ok, try to upload file
	} else {
	    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $up_bin_file)) {
	        echo "<b><span style='color:#5daf48'>{$alert_up_file_ok} ". basename( $_FILES["fileToUpload"]["name"]). "</span></b>";      
			echo '<form action="Update_Manual" method="GET">';
			echo '<input type="hidden" name="accion" id="accion" value="upload">';
			echo '<button class="up_manual" type="submit" name="submit_update" value="#%&@$#%&@$"><class class="icon-refresh"></class>&nbsp;Update</button>';
			echo '</form>';		        
	    } else {
	        echo "Error uploading your file.";
	    }
	}	
} else {
	if(isset($_POST["submit_file"])) {	
		echo "No submit file";
	}	
}
 ?>			

			</td>
		</tr>	

		<tr><td>&nbsp;</td></tr>		
	</table>


</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
