<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 
 ?> 

<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<div id='loading' style='display:none;'><div class='icon-widget r-spin'></div>&nbsp;Backup Database</div>
<?php 
  if ($_GET['accion']=="add_backrp") {
    shell_exec( "sudo mysqldump -uroot raptor -praptor > /var/backup_raptor_db/backup_raptor_`date +%Y-%m-%d_%H:%M`.sql" );    
    echo "<script>case_alert('loading', 'Backup_Database', '2000');</script>";   
  }
?>

  <div class="tab_report">
    <table class="sortable t_head">
    	<tr><th colspan=7 class="tabtit"><span class="icon-database-1"></span> Backup Database</th></tr>
    	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
    </table>
    <table id="sorter" class="sortable" cellspacing='0'>
      <tr>
        <th style="border-right:none;">
          <div id="bd" style="text-align:left;padding-bottom: 3px;">
            <a href="Backup_Database?accion=add_backrp"><button type="submit" title="" value="" ><span class="icon-floppy-o"></span> Backup</button></a>
          </div>
        </th>
      </tr>  
      
    <?php
    $files = array(); 
    $dir = "/var/backup_raptor_db/"; 
    if ($opendir = opendir($dir)) { 
         while (($file = readdir($opendir)) !== FALSE) { 
              if ($file!="."&&$file!="..") 
                   $files[] = $file; 
         } 
    } 
    natsort($files);
    if (count($files) > 0) {
      foreach($files as $fileDb) { 
           echo "<div><tr class=\"row\"><td>$fileDb</td></tr></div>"; 
      }  
    } else {
      echo "<div><tr class=\"row\"><td>No database files</td></tr></div>";      
    }

    ?>
      
     </table>

  </div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
