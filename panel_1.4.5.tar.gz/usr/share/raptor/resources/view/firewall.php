<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
 
require "public/global/above.php"; 
 ?>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script>

<div id="tbod"> 

<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>
<div id='loading' style='display:none;'><div class='icon-widget r-spin'></div> <?php echo $alert_fw; ?></div>
<?php 
	if (isset($_GET['accion_fw']) && $_GET['accion_fw'] == 'fire_restart') {
		shell_exec( "sudo bash /etc/raptor/fw.sh" ); 		
		echo "<script>case_alert('loading', 'Raptor_Firewall', '500');</script>";	 
	}
?>
	<div id='case_advice'><?php echo $advice_fw; ?><span style='font-weight:600;float:right;cursor:pointer;' class='close'><span class='icon-times'></span></div>
	<script>
		$('.close').on("click", function(){
			$('#case_advice').fadeOut('slow');
		});	
	</script>

		<div class="tab_config">
			<table class="t_head">
			  <tr><th colspan=7 class="tabtit"><img style="vertical-align:bottom;" src="<?php echo get_view_link(); ?>/images/imgpng/firewall-icon.png" alt=""> Firewall</th></tr>
			  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
			</table>				
			<?php 
				echo $this->value["table_rules_lst"];				
			?> 			  
			<span class="btn-default"><button class="newRule"><span class="icon-plus"></span>&nbsp;New Rule</button></span>&nbsp;
			<span class="btn-default"><button class="firRule"><span class="icon-plus"></span>&nbsp;Filter Rule</button></span>&nbsp;
			<span class="btn-default"><button class="natRule"><span class="icon-plus"></span>&nbsp;NAT Rule</button></span>&nbsp;
			<a id="restart" rel="" name="" href="Raptor_Firewall?accion_fw=fire_restart"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Firewall</button></a>

			<div class="editRuleDiv" title="Edit Rule"></div>

			<div class="newRuleDiv" title="New Rule"></div>	

			<div class="firRuleDiv" title="New Filter Rule"></div>	

			<div class="natRuleDiv" title="New NAT Rule"></div>	
			
		</div>

	</div>

</div>
 
<?php require "public/global/form/rp.modal.js.php"; ?>
<script src="<?php echo get_view_link(); ?>/js/rptbl.ajx.js"></script>

 </body>
 </html>



