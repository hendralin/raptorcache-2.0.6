<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
    
session_start();
require "public/global/above.php";

?>

<div id="tbod"> 

    <div class="tab_report">
        <table class="sortable t_head">
            <tr><th colspan=7 class="tabtit"><span class="icon-bar-chart"></span><?php echo $m_trf; ?></th></tr>
            <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
        </table>
        <table id="sorter" class="sortable" cellspacing='0'>
        <tr>
            <td style="border-radius: 0 0 3px 3px;border-bottom: none;">
                <div id="red">
                    <table> 
                      <tr><td style="border-bottom: none;">
                        <iframe style="width:970px;" src="../public/vns/vns.php" ></iframe>
                      </td></tr>
                    </table>
                </div>
            </td>
        </tr>

        </table>

    </div>

    <div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "global/below.php"; ?>