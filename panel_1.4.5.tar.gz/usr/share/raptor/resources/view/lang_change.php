<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 
?>

<div id="tbod"> 

<div class="tab_config">
<table class="t_head">
  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span> <?php echo $lng_title; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

 <form action="lang_change.req" method="POST" name="NombreForm" >
	 <table style="border-radius: 3px;">
		 <tr><td>&nbsp;</td></tr>
		 <tr>
		 	<td style="text-align:left;padding-left: 20px;">
			 	<select name="lang" id="lang" onchange="this.form.submit();">
<?php 
	foreach ($langs as $key => $selecLang) {
		if ($deflang == $selecLang) {
			unset($langs[$key]);						
			$langs = array($deflang => $selecLang) + $langs;
		}				
	}
	foreach ($langs as $key => $selecLang) {
		echo "<option value='{$key}'>{$selecLang}&nbsp;</option>";
	}		
 ?> 		
			 	</select>
		 	</td>
		 </tr>
		 <tr>
		 	<td style="text-align:left;padding-left: 20px;"><img src="<?php echo get_view_link(); ?>/images/flag_<?php echo strtolower($deflang); ?>.png"></td>
		 </tr>
		 <tr><td>&nbsp;</td></tr>		 
	 </table>
 </form>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
