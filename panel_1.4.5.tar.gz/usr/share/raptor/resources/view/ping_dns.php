<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 
 ?>

<div id="tbod"> 

<div class="tab_report">
<table class="sortable t_head">
	<tr><th colspan=7 class="tabtit"><span class="icon-network"></span>&nbsp;DNS</th></tr>
	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<table class="sortable" style="border-radius: unset;">
	<tr>
		<th class="sel_log">Ping DNS
			<!--<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="GET" class="link">                
                Address: <input type="text"><input type="submit" value="Enviar">
            </form>-->
		</th>		
	</tr>
</table>

<?php include get_rp_path()."/controllers/inc/ping_dns.php"; ?>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
