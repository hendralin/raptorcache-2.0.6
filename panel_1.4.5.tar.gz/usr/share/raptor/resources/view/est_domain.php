<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();
require "public/global/above.php"; 

?>
		<link rel="stylesheet" type="text/css" href="<?php echo get_view_link(); ?>/css/dataTables.css">
		<script type="text/javascript" language="javascript" src="<?php echo get_view_link(); ?>/js/dataTables.js"></script>
		<script type="text/javascript" language="javascript" >
			$(document).ready(function() {
				var dataTable = $('#statistic-grid').DataTable( {
					"processing": false,
					"serverSide": true,
/*					"initComplete": function() {
    					$("#statistic-grid_processing").css("display","none");
  					},*/
					"ajax":{
						url :"<?php echo get_view_link(); ?>/../controllers/ajx/c_domain.php",
						type: "post",
						beforeSend: function() {
							if ( $("#statistic-grid_processing").length == 0 ) {
								$("#statistic-grid").prepend('<tbody id="statistic-grid_processing"><tr><th colspan="7"><div id="loading_ajx"><div class="icon-spinner r-spin"></div>&nbsp;&nbsp;<?php echo $loading; ?></div></th></tr></tbody>');
							} else {
								$("#statistic-grid_processing").css("display","table-row-group");
							}
						},
						error: function(){
							$(".statistic-grid-error").html("");
							$("#statistic-grid").append('<tbody class="statistic-grid-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
							$("#statistic-grid_processing").css("display","none");							
						}
					}
				} );
			} );
		</script>

<div id="tbod"> 

	<div class="tab_report">
		<table class="sortable t_head">
			<tr><th colspan=7 class="tabtit"><span class="icon-list-ul"></span>&nbsp;<?php echo $rp_domain; ?>s</th></tr>
			<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
		</table>
		<table id="statistic-grid"  cellpadding="0" cellspacing="0" border="0" class="display" width="100%">
			<thead>
				<tr>
					<th>Icon</th>
					<th><?php echo $rp_domain; ?></th>
					<th><?php echo $rp_files; ?></th>
					<th><?php echo $rp_size; ?></th>
					<th>Eco</th>
					<th>Hits</th>
					<th><?php echo $rp_porcent; ?></th>
				</tr>
			</thead>
		</table>
	</div>

	<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "public/global/below.php"; ?>