<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
     
session_start();
require 'public/global/above.php';

?>

<div id="tbod"> 

    <div class="tab_report">
        <table class="sortable t_head">
            <tr><th colspan=7 class="tabtit"><span class="icon-graph"></span>&nbsp;<?php echo $rp_reptot; ?>&nbsp;HTTPS</th></tr>
            <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
        </table>
        <table id="sorter" class="sortable" cellspacing='0'>
            <tr>
            <th><img src="<?php echo get_view_link(); ?>/images/imgpng/dbr.png" /></th>
            <th><?php echo $rp_files; ?></th>
            <th><?php echo $rp_size; ?></th>
            <th><?php echo $rp_eco; ?></th>
            <th><?php echo $rp_hits; ?></th>
            <th style="border-right:none;text-align:right;">Eficacia</th>
            </tr>
        <?php 
            echo $this->value['SUMMARY_TOTAL_HTTPS'];
        ?>
        </table>
    </div>

    <div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

<?php require "public/global/below.php"; ?>
