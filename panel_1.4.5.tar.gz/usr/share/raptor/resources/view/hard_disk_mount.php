<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.3
 */

session_start();

require get_rp_path().'/main/settings.php';
require get_rp_path()."/lang/$deflang.php";

require "public/global/above.php"; 
 ?>

<div id="tbod"> 

<div id='loading' style='display:none;'></div>

<div class="tab_config">
	<table class="t_head">
	  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span><?php echo "&nbsp;&nbsp;Admin&nbsp;&nbsp;-".$m_dd; ?></th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>

	<table class="t_body" cellspacing='0'>
		<tr><td>

<div id="hard_disk_mount">
<?php 

require get_rp_path().'/models/autoload.php';
use Raptor\Models\HardDiskMount;

$hd = new HardDiskMount();
$devDisk = $hd->getListDevDisk();

for ($i=0; $i < $hd->getCountDisk(); $i++) {
	$name_disk = explode("/dev/", $devDisk[$i]);
	$name_sdx = $name_disk[1];

	$smt = $hd->getSmartool($name_sdx);	
 	$mountHd = $hd->getMountHd($name_sdx);
 	$systemDisk = false;
 	if ($mountHd == "System") {
 		$systemDisk = true;
 		$mountHd = "<span style='color:#2ec2d0'>System</span>";
 	} 
 	elseif ($mountHd == "No Mount") {
 		$mountHd = "<span style='color:#FF0000'>No Mount</span>";
 	}
 	else {
 		$mountHd = "<span style='color:#5daf48'>".$mountHd."</span>";
 		$cacheDir = $hd->getMountHd($name_sdx);
 	} 	
?>
	<div id='hdall'>
		<table class='tg'>
			<tr>
				<th colspan="9" class="mount_disk">
				<?php 
					echo ($smt[0]) ? $smt[0] : "" . "&nbsp;&nbsp;" . isset($smt[1]) ? 'Model - ' . $smt[1] : ""; 
				?>
				</th>
			</tr>
			<tr>    
				<td class="hd_head" style="width:48px;height:22px;width:22px"><div id="lghd_mnt"></div></td>     
				<td class="hd_head" style="border-left: 1px solid #afafaf;width: 10%;"><font style="font-size:12px;color:#555;"><strong><?php echo $devDisk[$i]; ?></strong></font></td> 
				<td class="hd_head" style="border-left: 1px solid #afafaf;width: 10%;"><font style="font-size:12px;color:#555;"><strong><?php echo $smt[2]; ?></strong></font></td> 
				<td class="hd_head" style="border-left: 1px solid #afafaf;width: 10%;"><?php echo $mountHd; ?></td> 
				<td class="hd_head" style="border-left: 1px solid #afafaf;width: 36%;"><?php echo $hd->getUuid($name_sdx); ?></td> 		  	
				<td class="hd_head" style="border-left: 1px solid #afafaf;"><?php if($systemDisk == false) echo "<a class='format' data-format='$devDisk[$i]' href='#'><button><span class='icon-tasks'></span>&nbsp;Format</button></a>"; ?></td>
				<td class="hd_head" style="border-left: 1px solid #afafaf;"><?php if($systemDisk == false) echo "<a class='mount' data-mount='$devDisk[$i]' href='#'><button><span class='icon-download-1'></span>&nbsp;Mount</button></a>"; ?></td>
				<td class="hd_head" style="border-left: 1px solid #afafaf;"><?php if($systemDisk == false) echo "<a class='umount' data-umount='$devDisk[$i]' href='#'><button><span class='icon-upload-1'>&nbsp;</span>Umount</button></a>"; ?></td>
			</tr>  	
		</table>
	</div>
<?php 
} 
?>
		</div><!--#hard_disk_mount -->

		</td></tr>

		<tr><td>&nbsp;</td></tr>	
	
 	</table><!--#t_body -->

<script src="<?php echo get_view_link(); ?>/js/mount.ajx.js"></script>

<br>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
<script>
  $(function() {
    $( "#conf_txt" ).accordion({
      collapsible: true, 
      active: false
    });
  });
</script>
  <div id="conf_txt" style="margin-bottom:10px;">
    <h3 style="text-align:left;color:#454545;font-size:12px;">Mount details</h3>
		<div id="lvmdisplay">
<?php
$fn = "/etc/fstab";
if (isset($_POST['content'])) {
    $content = ($_POST['content']);
    $fp = fopen($fn,"r") or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error open file!");
    fputs($fp, $content);
    fclose($fp) or die ("&nbsp;&nbsp;&nbsp;&nbsp;Error close the file!");
}
?>
    <textarea style="font-size:12px;" readonly rows="20" name="content"><?php readfile($fn); ?></textarea>
		</div>
  </div>


</div>

<div id="ln"><hr></div>

<div id="footer" style="margin-top:0;"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 	

</body>
</html>
