<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

error_reporting(0);
	
require "public/global/above.php"; 	
 ?>

<div id="tbod"> 

<div class="tab_report">
<table class="sortable t_head">
	<tr><th colspan=7 class="tabtit"><span class="icon-list"></span>&nbsp;Log</th></tr>
	<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<table class="sortable">
	<tr>
		<th class="log">Error Log</th>
		<th class="sel_log">
			<form action="getlog.req" method="GET" class="link">                
                Type: <select name="acs" id="acs" onchange="this.form.submit();">
                    <option value=""></option>
                    <option value="rpt_acc_lg">HTTP Log</option>
                    <option value="rpt_https_lg">HTTPS Log</option>
                    <option value="rpt_err_lg">Error Log</option>
                    <option value="rpt_sys_lg">Sys Log</option>
                </select>
            </form>

		</th>
	</tr>
</table>

<?php include get_rp_path()."/controllers/inc/logs_rp_err.php"; ?>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
