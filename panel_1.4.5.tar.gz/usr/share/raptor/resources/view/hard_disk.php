<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

session_start();
 
require "public/global/above.php"; 
 ?>

<div id="tbod"> 

<div class="tab_config">
<table class="t_head">
  <tr><th colspan=7 class="tabtit"><span class="icon-hdd-o"></span><?php echo $m_dd; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>


<table class="t_body" cellspacing='0'>
  <tr><td>

<?php include get_rp_path().'/controllers/inc/hd.php'; ?>

</td></tr>

<tr><td>

<br>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
<script>
  $(function() {
    $( "#conf_txt" ).accordion({
      collapsible: true, 
      active: false
    });
  });
</script>

  <div id="conf_txt" style="margin-bottom:10px;">
    <h3 style="text-align:left;color:#454545;">More details</h3>
		<div id="lvmdisplay">
<?php 
echo details_hd();
 ?>
		</div>
  </div>
  
	</td></tr>
	
 </table>

</div>


<div id="ln"><hr></div>

<div id="footer" style="margin-top:0;"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 	

</body>
</html>
