 <?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 
 ?>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script>

<div id="tbod"> 

<?php 
	$alert_msg = $bt_restart.' Raptor'; 
	include_once "public/global/form/restart.php"; 
?>		
	<div id="case_restart_alert"></div>

		<div class="tab_config">
			<table class="t_head">
			  <tr><th colspan=7 class="tabtit"><span class="icon-list-ul"></span>&nbsp;Store HTTPS</th></tr>
			  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
			</table>			
			<?php 
				echo $this->value["table_regex_lst"];
			?>  
			<span class="btn-default"><button class="newRegexPl"><span class="icon-plus"></span>&nbsp;New Regex</button></span>&nbsp;
			<a id="restart" href="#" onclick="restart('shut_rp.req')"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Raptor</button></a>

			<div class="editRegexPlDiv" title="Edit Regex Pl"></div>

			<div class="newRegexDiv" title="New Regex HTTPS"></div>	
		</div>

	</div>

</div>

<?php require "public/global/form/rp.modal.js.php"; ?>
<script src="<?php echo get_view_link(); ?>/js/rptbl.ajx.js"></script>
 
 </body>
 </html>