<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
 
require 'public/global/above.php'; 

require get_rp_path().'/models/autoload.php';
use Raptor\Models\FileRp;

$rp = new FileRp();

?>
	
<div id="tbod"> 

<div class="tab_config">
	<table class="t_head">
  		<tr><th colspan=7 class="tabtit"><span class="icon-key-1"></span> <?php echo "Licence"; ?></th></tr>
  		<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>

	<table class="t_body" style="padding: 20px 0;">
		<tr>
			<td style="width:80px;text-align:left;padding:4px 20px;">Raptor</td>
			<td style="text-align:left;padding:4px 20px;color:#2ec2d0"><?php echo $rp->get_core_version(); ?></td></tr>		
		<tr>
			<td style="width:80px;text-align:left;padding:4px 20px;">Licence</td>
			<td style="text-align:left;padding:4px 20px;">
			<?php 
				if ($rp->get_lic_name_raptor() != "") {
					if ($rp->get_lic_name_raptor() == "RnJlZQ..") {
						echo "<span style='color:#5daf48;'>".de_str($rp->get_lic_name_raptor())."</span>";
					} else {
						echo "<span style='color:#5daf48;'>".$rp->get_lic_name_raptor()."</span>";
					}					 
				} else {
					echo "<span style='color:red;'>".$rp->get_lic_name_raptor()."</span>"; 
				}	
			?>		
			</td>	
		</tr>	
		<tr>
			<td style="width:80px;text-align:left;padding:4px 20px;">Key</td>
			<td style="text-align:left;padding:4px 20px;color:#2ec2d0"><?php echo $rp->get_lic_key_raptor(); ?></td>
		</tr>							
	</table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
