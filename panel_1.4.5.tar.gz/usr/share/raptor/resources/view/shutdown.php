<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 
 ?>

<div id="tbod"> 

<?php 
	$alert_msg = $bt_restart.' Raptor'; 
	include_once "public/global/form/restart.php"; 
?>		
<div id="case_restart_alert"></div>

<div class="tab_config">
	
	<table class="t_head">
		<tr><th colspan=7 class="tabtit"><span class="icon-power-off"></span>&nbsp;Shutdown</th></tr>
		<tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
	<table cellspacing='0' class="t_body">
		<tr>
			<td id="confrp_td">

				<div id="shutdown">

				  <a href="#" onclick="restart('shut_down.req')"><img src="<?php echo get_view_link(); ?>/images/imgpng/halt.png" title="<?php echo $bt_sysshut; ?>" /></a>&nbsp;&nbsp;

				  <a href="#" onclick="restart('shut_restart.req')"><img src="<?php echo get_view_link(); ?>/images/imgpng/reboot.png" title="<?php echo $bt_sysreboot; ?>" /></a>&nbsp;&nbsp;

				  <a href="#" id="restart_raptor" onclick="restart('shut_rp.req')"><img src="<?php echo get_view_link(); ?>/images/imgpng/rp_restart.png" title="<?php echo $bt_rp_restart; ?>" /></a>

				</div>

			</td>
		</tr>
	  
	 </table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
