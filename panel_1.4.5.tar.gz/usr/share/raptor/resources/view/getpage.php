<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
session_start();

require "public/global/above.php"; 
?>

<div id="tbod"><!-- TBOD --> 


<div style="margin:12%;margin-bottom: 12%;display: flex; justify-content: center;"><div id="getpage"><div class="icon-spinner r-spin"></div>&nbsp;&nbsp;<?php echo $loading; ?></div></div>

<?php
/**
 * url_link for menu
 */

$getLink = isset($_GET['url_link']) ? $_GET['url_link'] : null ;

if ($getLink != "") {
	echo '<script language="javascript">location.href="'.$getLink.'"</script>';
}

?>

</div><!-- END TBOD -->

<br>

</div><!-- END GERAL -->  

</body>
</html>
 