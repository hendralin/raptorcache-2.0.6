<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require 'public/global/above.php'; 

require get_rp_path().'/models/autoload.php';
use Raptor\Models\Network;
use Raptor\Models\SyState;

$network = new Network();
$sys = new SyState();

?>

<div id="tbod"> 

<?php 
  include get_rp_path().'/public/global/alert_case.php'; 
?>

<div class="tab_config">
<table class="t_head">
  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> <?php echo $net_ir; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>
<table class="iface" cellspacing="0" style="border-radius:0 0 3px 3px;">
	<tr>
		<th>Iface</th>
		<th>MTU</th>
<?php
if ($sys->get_version_debian() == "jessie") 
	echo '<th>Met</th>';
?>
		<th>RX-OK</th>
		<th>RX-ERR</th>
		<th>RX-DRP</th>
		<th>RX-OVR</th>
		<th>TX-OK</th>
		<th>TX-ERR</th>
		<th>TX-DRP</th>
		<th>TX-OVR</th>
		<th style='border-right:none;'>Flag</th>
	</tr>
<?php 
	for ($i=0; $i < count($network->show_interfaces()); $i++) { 
		echo "<tr class='row'>";
		for ($j=0; $j < count($network->show_interfaces()[$i]); $j++) { 
			echo "<td>{$network->show_interfaces()[$i][$j]}</td>";	
		}	
		echo "</tr>";
	}
echo '</table>';	
 ?>
</div>

<hr>	

<div class="tab_config">
<table class="t_head">
  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> <?php echo $net_ip; ?></th></tr>
  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
</table>

<?php
if ($network->is_cidr()) {
?>
<table class="sortable" cellspacing="0" style="border-radius:0 0 3px 3px;">
	<tr>
		<th>Interface</th>
		<th>Address</th>
		<th>Gateway</th>
		<th style='border-right:none;'></th>
	</tr>		
<?php	
	for ($i=0; $i < count($network->get_ip_address()); $i++) { 		
		echo "<tr class='row'>";			
		foreach ($network->get_ip_address()[$i] as $key => $value) {
			if ($key == 'allow-hotplug')
			continue;			
			echo "<td>{$value}</td>";				
		}
		echo "<td><a class='del_regx' href='network_del_ip.req?num_eth={$network->get_ip_address()[$i]["allow-hotplug"]}'>X</a></td>"; // Delete interface
		echo "</tr>";			
	}
echo '</table>';
}
else {
?>
<table class="sortable" cellspacing="0" style="border-radius:0 0 3px 3px;">
	<tr>
	<th>Interface</th>
	<th>IP</th>
	<th>Netmask</th>
	<th>Network</th>
	<th>Broadcast</th>
	<th>Gateway</th>
	<th style='border-right:none;'></th>
</tr>
<?php	  
	for ($i=0; $i < count($network->get_ip_address()); $i++) { 		
		echo "<tr class='row'>";			
		foreach ($network->get_ip_address()[$i] as $key => $value) {
			if ($key == 'allow-hotplug')
			continue;			
			echo "<td>{$value}</td>";				
		}
		echo "<td><a class='del_regx' href='network_del_ip.req?num_eth={$network->get_ip_address()[$i]["allow-hotplug"]}'>X</a></td>"; // Delete interface
		echo "</tr>";			
	}
echo '</table>';
}	
 ?>
	<div class="btn-default">
		<button class="addIp"><span><?php echo "Change IP"; ?></span></button>
		<button class="addGw"><span><?php echo "Gateway Mode"; ?></span></button>
		<button class="addBr"><span><?php echo "Bridge Mode"; ?></span></button>
	</div>

<?php 
$uppass = isset($_GET['error_add_ip']) ? $_GET['error_add_ip'] : null ;
if ($uppass == "no") {
	echo "<span id='alert_add_ip'>! {$alert_no_ip}</span>";
}
 ?>	
 <script>
$(document).ready(function() { 
    setTimeout(function() { 
        $('#alert_add_ip').fadeOut('slow'); 
 	}, 3000); 
});
</script> 	

	<div class="addIpDiv" title="<?php echo "Change IP"; ?>"></div>	

	<div class="addGwDiv" title="<?php echo "Gateway Mode"; ?>"></div>	

	<div class="addBrDiv" title="<?php echo "Bridge Mode"; ?>"></div>	

<?php include get_rp_path().'/public/global/form/network.modal.js.php'; ?>

</div>

<hr>

<div class="tab_config">
	<table class="t_head" style="width:300px;" >
	  <tr><th colspan=7 class="tabtit"><span class="icon-sitemap"></span> IP Cache</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
  <form action='ipcache.req' method='GET'>
    <table style='width:300px;padding:10px;border-radius:2px;'>
      <tr>
        <td style='text-align:left;'><input name='ip_cache' type='text' value='<?php echo $network->getIpCache(); ?>' autocomplete='off'>&nbsp;&nbsp;<span class='validate_ip'></span></td>
      </tr>
      <tr><td class='ip_blank' style='display:none;'><span class='validate_ip'>! Insert IP Server</span></td></tr>
      <tr>
        <td style='text-align:left;'><span class='btn-default-only'><button><span class='icon-floppy-o'></span>&nbsp;<?php echo $bt_grd; ?></button></span></td>
      </tr>
    </table>
  </form>
<script>
  var x = $('input[name="ip_cache"]');
  if (x.val() == "") {
    console.log("IP cache is blank");
    $( 'td.ip_blank' ).css({display:"block"});
  }
</script>

</div>

<hr>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>