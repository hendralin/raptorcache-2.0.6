<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php";  


?>

<div id="tbod"> 

<?php 
	include_once get_rp_path().'/public/global/form/restart.php'; 
?>
<div id="case_restart_alert"></div>

<?php 
	include get_rp_path()."/public/global/alert_case.php"; 
?>

<div class="tab_config">
	<table class="t_head">
	  <tr><th colspan=7 class="tabtit"><span class="icon-cog"></span>&nbsp;Squid.conf</th></tr>
	  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
	</table>
	<table class="t_body" cellspacing='0'>
	  <tr>
	<td id="confrp_td">
	  
	<div class="confrp">

		<form style="padding-bottom:8px;" action="sqconf.req" method="POST">
			<table class="options">
				<tr>
					<td>DNS NAMESERVERS 1</td>
					<td><input name="dns_nameservers1" type="text" value="<?php echo $this->value['dns1']; ?>"></td>
				</tr>
				<tr>
					<td>DNS NAMESERVERS 2</td>
					<td><input name="dns_nameservers2" type="text" value="<?php echo $this->value['dns2']; ?>"></td>
				</tr>					
				<tr>
					<td></td>
					<td><button id="enviar" name="dns_submit" type="submit" title=""><span class="icon-floppy-o"></span>&nbsp;<?php echo $bt_grd; ?></button></td>
				</tr>		
			</table>
		</form>


	<?php 
		echo $this->value['localnet'];  
	 ?>						
	<div style="width:128px;"><button class="addAcl"><span class="icon-plus"></span>&nbsp;<?php echo "<span style='vertical-align:top;'>".$bt_agr." ACL</span>"; ?></button></div>

	<div class="addAcl-Div" title="<?php echo $bt_agr." ACL Localnet"; ?>"></div>	

<script>
  $( function() {
  	var smallDiv, 
    smallDiv = $( ".addAcl-Div" ).dialog({
      autoOpen: false,
      height: 160,
      width: 248,
      modal: true,
      open: function () {             
                $(".addAcl-Div").load('../public/global/form/addAclLocalnet.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#acl_ln').val()) {  
            alert('Please, insert ACL Rule');
            return false;  
          } else {
            $("#addAcl-Form").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addAcl" ).on( "click", function() {
      smallDiv.dialog( "open" );
    });   
  });	
</script>

	<div id="ln" style="padding-top: 12px;"><hr></div>
	
	<div style="padding:10px 10px 8px 0;text-align:right;"><a id="restart" href="#" onclick="restart('shut_rp.req')"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Raptor</button></a></div>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script> 
	<script>
	  $(function() {
	    $( "#conf_txt" ).accordion({
	    	active: false,	
			collapsible: true, 
	      
	    });
	  });
	</script>
		
		<div id="conf_txt" style="margin: 10px;">
			<h3 style="text-align:left;color:#454545;">View Config</h3>
			<div>
				<textarea style="font-size:12px;" readonly rows="25" name="content"><?php readfile("/etc/squid3/squid.conf"); ?></textarea>
			</div>
		</div>

	</div> 

	</td>
	  </tr>
	  
	 </table>

</div>

<div id="footer"><p><?php echo $cop; ?></p></div>

</div><!-- END TBOD -->

<br>

</div><!-- ALL --> 

</body>
</html>
