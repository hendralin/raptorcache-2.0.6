<?php
/**
*
* @package Main Raptorcache
* @since 1.0
*/

session_start();

require "public/global/above.php";

require get_rp_path().'/models/autoload.php';
use Raptor\Models\UpdateRp;
use Raptor\Models\FileRp;

$rp = new UpdateRp();
$rp->getLocalVersion(new FileRp);

?>

  <div id="tbod">
    <!-- TBOD -->

    <script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>

<?php

if ( $rp->isConnSocketServer(1) && $rp->update_status() == true ) {
	echo "<div id='wrap-update'><div id='case_update' style='display:none;'><div class='icon-refresh r-spin'></div>&nbsp;&nbsp;{$str_update}&nbsp;{$str_available}</div></div>";
	echo "<script>redirect('case_update', 'Update');</script>";
} else {
    echo "<div id='box_init'><div id='loading'><div style='display:inline-block;' class='icon-spinner r-spin'></div>&nbsp;".$loading."</div></div>";
    if (isset($_COOKIE['url_link'])) {
        echo "<script>redirect('loading', '".$_COOKIE['url_link']."');</script>";
    } else {
        echo "<script>redirect('loading', 'System');</script>";
    }
}

?>

  </div>
  <!-- END TBOD -->

  <br>

  </div>
  <!-- END GERAL -->

  </body>

  </html>