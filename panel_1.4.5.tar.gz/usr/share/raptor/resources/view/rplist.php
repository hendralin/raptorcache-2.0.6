 <?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */
 
require "public/global/above.php"; 
 ?>

<link rel="stylesheet" href="<?php echo get_view_link(); ?>/css/jquery-ui.css">
<script src="<?php echo get_view_link(); ?>/js/jquery-ui.min.js"></script>

<div id="tbod"> 

<?php 
	$alert_msg = $bt_restart.' Raptor'; 
	include_once "public/global/form/restart.php"; 
?>		
	<div id="case_restart_alert"></div>

		<div class="tab_config">
			<table class="t_head">
			  <tr><th colspan=7 class="tabtit"><span class="icon-list-ul"></span>&nbsp;Raptor List</th></tr>
			  <tr><th colspan=7 class="tabtitleline"><hr></th></tr>
			</table>
			<?php 
				echo $this->value["table_rules_lst"];
			?>  
			<span class="btn-default"><button class="newRule"><span class="icon-plus"></span>&nbsp;New Rule</button></span>&nbsp;
			<a id="restart" href="#" onclick="restart('shut_rp.req')"><button><span class="icon-refresh"></span>&nbsp;<?php echo $bt_re; ?>&nbsp;Raptor</button></a>

			<div class="editRuleDiv" title="Edit Rule"></div>

			<div class="newRuleDiv" title="New Rule"></div>	

		</div>

	</div>

</div>

<?php require "public/global/form/rp.modal.js.php"; ?>
<script src="<?php echo get_view_link(); ?>/js/rptbl.ajx.js"></script>
 
 </body>
 </html>