<?php

$verwp    = "1.4.5";

$cop_year = "2018";

?>