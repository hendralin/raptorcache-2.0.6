<?php 
/**
 *
 * @package Raptorcache
 * @since 1.4
 */

$verwp    = "1.4.5";

$cop_year = "2018";

$eth_input_server = "eth0";

$deflang = "Spanish"

 ?>