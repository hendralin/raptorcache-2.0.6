<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */
 
  @session_start();
  
  if (empty($_SESSION["user"])){ 
  	header("Location: ../"); exit(); 
  }

?>