<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

error_reporting(0);

function dir_path() {
  $file = "";
  $file = $_SERVER['DOCUMENT_ROOT'];
  $path = rtrim($file, '/\\' );
  $path = $path . '/raptor';
    return dirname($path);
}

function get_rp_path() {
  define( 'RP_PATH', dir_path() );
  return RP_PATH;  
}

function get_view_link() {
  define( 'PATH_DIR_URL', '../public');
  return PATH_DIR_URL;
}

function get_path_view() {
  define( 'PATH_VIEW', '../resources/view' );
  return PATH_VIEW;  
}

function get_path_req() {
  define( 'PATH_REQ', 'controllers/req' );
  return PATH_REQ;  
}


function get_request_url() {
  $loc = $_SERVER['REQUEST_URI'];
  $loc = explode('/', $loc);
  $loc = end($loc); 
  return $loc; 
}
/* top-head */
function name_distri() {
  $distri = exec("lsb_release -d | awk '{print $2,$3,$4,$5}'");
  return $distri;
}

function processor() {
  exec("cat /proc/cpuinfo | grep \"model name\" | cut -d: -f2", $PROCESSOR);
  $str1 = $PROCESSOR[0];
  return array('name'=>$PROCESSOR[0], 'cores'=>count($PROCESSOR));  
}

function processorAll() {
  exec("lscpu", $procc);
  foreach ($procc as $value) {
    if ( strstr($value, 'Model name') ) {
      $procName = explode(':', $value);
    }
    if ( strstr($value, 'Core') ) {
      $cores = explode(':', $value);
    }   
    if ( strstr($value, 'Architecture') ) {
      $arqui = explode(':', $value);
      if (trim($arqui[1]) == 'x86_64') {
        $arqui = '64 Bits';
      } else {
        $arqui = '32 Bits';
      }
    }   
  }
  $value = array('name'=>$procName[1], 'cores'=>$cores[1], 'arq'=>$arqui);  
}

function proc() {
  exec("cat /proc/cpuinfo | grep \"model name\\|processor\"", $PROCESSA);
  $str1 = trim($PROCESSA[1]);
  $str1 = preg_replace("/\s(?=\s)/", "", $str1);
  $str1 = preg_replace("/[\n\r\t]/", " ", $str1);
  $str1 =  str_replace("model name : ", "", $str1);
    return $str1;
}
function cpu_model() {
    $md = exec("cat /proc/cpuinfo | grep \"model name\" | head -n1");
    $md = substr($md, strpos($md, ":")+2, strlen($md));
    return "<b>".$md."</b>";
}
function num_proc() {
  $proc = exec("cat /proc/cpuinfo | grep processor | wc -l");
  return $proc;
}

function arquitect() {
  $plat = exec("uname -m");        
  if ($plat == "i686")
    $arquit = "(32 bits)";
  else{
    $arquit = "(64 bits)";          
  } 
  return $arquit;
}

function stat_rp_sq($portr) {
  $iprp = "localhost";
    if (! $sock = @fsockopen($iprp, $portr, $errno, $errstr, 2))
      return "<span style=\"color:rgb(252, 69, 69);\">Offline</span>";
    else {
      return "<span style=\"color:#5daf48\">Activo</span>";
    }
    fclose($sock);
}

/* Sys State */
function mem_total() {
  exec("free -m", $output);
      $str = trim($output[1]);
      $str = preg_replace("/\s(?=\s)/", "", $str);
      $str = preg_replace("/[\n\r\t]/", " ", $str);
      $ram = explode(" ", $str);
      $str = trim($output[3]);
      $str = preg_replace("/\s(?=\s)/", "", $str);
      $str = preg_replace("/[\n\r\t]/", " ", $str);
      $swap = explode(" ", $str); 

      $mem_tot = $ram[1]*1024*1024;
      return $mem_tot;
}  

function sizeTraf($traf){
  $sizetx = $traf; 
  if ($sizetx < 1024) { 
    return $sizetx . " Kbps"; 
  }
  else if ($sizetx < (1024*1024)) { 
    $sizetx_r = round($sizetx/1024,2);
    return $sizetx_r . " Mbps"; 
  }
  else if ($sizetx < (1024*1024*1024)) { 
    $sizetx_r = round($sizetx/(1024*1024),2);
    return $sizetx_r . " Gbps"; 
  } 
  else if ($sizetx < (1024*1024*1024*1024)) { 
    $sizetx_r = round($sizetx/(1024*1024*1024),2);       
    return $sizetx_r . " Tbps"; 
  }
}

/* function trafEth($eth, $file_export) {
  $eth_input_server = $eth;
  $file = $file_export;
  shell_exec("sudo ifstat -i $eth_input_server -b 1 1 | grep -v $eth_input_server | grep -v Kbps | xargs > $file");
  //$r_file = shell_exec("sudo ifstat -i $eth_input_server -b 1 1 | tail -1 | xargs ");
  $r_file = file_get_contents($file);
  $r_file = trim($r_file);
  $r_file = explode(" ", $r_file);
  $txeth = sizeTraf($r_file[0]);
  $rxeth = sizeTraf(end($r_file));
  $t= '<span class="redstat_tx">TX: '.$txeth.'</span>';
  $t.= '<span class="redstat_rx">RX: '.$rxeth.'</span>';
  return $t;
} */
  
function sizeFormat($size){
  if($size < 1024)  {
    return $size." bytes";
  }
  else if($size < (1024*1024)) {
    $size=round($size/1024,2);
    return $size." KiB";
  }
  else if($size < (1024*1024*1024)) {
    $size=round($size/(1024*1024),2);
    return $size." MiB";
  }
  else if($size < (1024*1024*1024*1024))  {
    $size=round($size/(1024*1024*1024),2);
    return $size." GiB";
  } else  {
    $size=round($size/(1024*1024*1024*1024),2);
    return $size." TiB";
  }
}

function sizeFormatSQ($size){
  if($size < 1024)  {
    return $size." KiB";
  }
  else if($size < (1024*1024)) {
    $size=round($size/1024,2);
    return $size." MiB";
  }
  else if($size < (1024*1024*1024)) {
    $size=round($size/(1024*1024),2);
    return $size." GiB";
  }
  else {
    $size=round($size/(1024*1024*1024),2);
    return $size." TiB";
  } 
}

function percC($value) {
  $r = '';
  if ( $value < 50 ) {
    $r = '<span style="color:#555">'.$value.'</span>';
  } else if ( $value < 80 ) {
    $r = '<span style="color:#FF6600">'.$value.'</span>';
  } else {
    $r = '<span style="color:#FF0000">'.$value.'</span>';;      
  }  
  return  $r;
}

function format_time($seconds) {  
  $mins  = intval($seconds / 60 % 60);
  $hours = intval($seconds / 3600 % 24);
  $days  = intval($seconds / 86400);
  if ($days > 0) {
    $uptimeString .= $days;
    $uptimeString .= (($days == 1) ? "d" : "d");
  }
  if ($hours > 0) {
    $uptimeString .= (($days > 0) ? " " : "") . $hours;
    $uptimeString .= (($hours == 1) ? "h" : "h");
  }
  if ($mins > 0) {
    $uptimeString .= (($days > 0 || $hours > 0) ? " " : "") . $mins;
    $uptimeString .= (($mins == 1) ? "m" : "m");
  }
  /*if ($seconds > 0) {
    $uptimeString .= (($days > 0 || $hours > 0 || $mins > 0) ? " " : "") . $seconds;
    $uptimeString .= (($seconds == 1) ? "s" : "s");
  }*/
  return $uptimeString;
}

/* / */

/*
function num_eth() {
  $eth = shell_exec("sudo ifconfig -a -s | grep -Ee 'eth[0-9]' | awk {'print $1\" \"$2\" \"$3\" \"$4\" \"$5\" \"$6\" \"$7\" \"$8\" \"$9\" \"$10\" \"$11\" \"$12'}");
  $eth = explode("\n", $eth);
  for ($i=0; $i < count($eth); $i++) { 
    $ethx = trim($eth[$i]);     
    $iface = explode(" ", $ethx);
    if ($iface[0] != "") {
      echo "<option value='".$iface[0]."'>".$iface[0]."</option>";
    }    
  }     
}

function ip_dns_lo() {
  $file = "/etc/resolv.conf";
  $fileln = file($file); 
  $pos = 0;
  foreach($fileln as $line) {     
    if (strpos($line, '##-##') !== FALSE){
        return 'disable';     
    }
    $pos++;
  }
  return 'enable';
}
*/

function test_cnx_db() {
  mysqli_connect("localhost","root","raptor","raptor");
  if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
  } else {
  	print "Conection Raptor database OK";
  }
}

function en_str($string) {
  $data = base64_encode($string);
  $data = str_replace(array('+','/','='),array('-','_','.'),$data);
  return $data;
}

function de_str($string) {
  $data = str_replace(array('-','_','.'),array('+','/','='),$string);
  $mod4 = strlen($data) % 4;
  if ($mod4) {
    $data .= substr('====', $mod4);
  }
  return base64_decode($data);
}

function del_line($file_in, $line_del) {
  $file = $file_in;
  $content = file_get_contents($file);
  $file_arr_ln = explode("\n", $content); 
  $pos = 0;
  foreach( $file_arr_ln as $line ) {         
    if ( strpos($line, $line_del) !== FALSE ) {
      $row = $pos+1;        
    }
      $pos++;
  }
  $newline2 = "";
  if ( $row != "" ) {
    file_put_contents($file, str_replace($file_arr_ln[($row-1)]."\n", $newline2, $content));    
    return 1;  
  }
  return 0;
} 

function details_hd() {
  $name_grep_disk = exec("sudo fdisk -l | grep /dev/ | grep bytes | head -n1 | awk {'print $1'}");
  $count_disk = shell_exec("sudo fdisk -l | grep ".$name_grep_disk." | grep bytes | grep -Ee '/dev/sd[a-z]' | grep -v '/dev/dm-0' | grep -v '/dev/mapper/' | wc -l");
  $list_dev_disk = shell_exec("sudo fdisk -l /dev/sd? | grep ".$name_grep_disk." |grep bytes | awk '{print $2}' | sed -e 's/://g'");

  $dev_disk = explode("\n", $list_dev_disk);

  for ($i=0; $i <$count_disk ; $i++) {
    $name_disk = explode("/dev/", $dev_disk[$i]);
    $name_sdx_disk = $name_disk[1];

  $dsk = shell_exec("sudo smartctl -A ".trim($dev_disk[$i])." | grep -v 'build' | grep -v 'Copyright' | grep -v '===' ");

  return "<pre>/dev/".$name_sdx_disk.$dsk."</pre>";  
  }
}

function set_value_config($file, $string_search, $string_to_replace) {
  $content     = file_get_contents($file);
  $file_arr_ln = explode("\n", $content); 
  $pos = 0;
  foreach( $file_arr_ln as $line ) { 
    if ( strpos($line, $string_search) !== FALSE){
      $val = $line;
      $v_change = $string_to_replace;
      $directive = explode("=", $line);
      $directive = $directive[0];
      $change = trim($directive) . ' = "' . $v_change. '"';
    }
  } 
  file_put_contents($file, str_replace($val, $change, $content));   
}

function search_string($open_file, $string_search) {
  $file = $open_file;
  $fileln = file($file);  
  $pos = 0;
  foreach($fileln as $line) { 
    if (strpos($line, $string_search) !== FALSE){
     $num_row = $pos + 1;        
    }
    $pos++;
  } 
  $line_string = $fileln[($num_row - 1)];   
  $quit     = array('$', ';');
  $line_string = str_replace($quit, "", $line_string);         
  return array('num_row' => $num_row, 'string' => $line_string);
}

function value_directive($open_file, $string_search) {
  $file = $open_file;
  $fileln = file($file);  
  $pos = 0;
  foreach($fileln as $line) { 
    if (strpos($line, $string_search) !== FALSE){
     $num_row = $pos + 1;        
    }
    $pos++;
  } 
  $line_string = $fileln[($num_row - 1)];            
  $value = explode(" ", $line_string);
  $value = $value[1];

  return $value;
}

function getValueHd($open_file, $string_search, $selector) {
  $file = $open_file;
  $fileln = file($file);  
  $pos = 0;
  foreach($fileln as $line) { 
    if (strpos($line, $string_search) !== FALSE){
     $num_row = $pos + 1;        
    }
    $pos++;
  } 
  $line_string = $fileln[($num_row - 1)];            
  $value = explode($selector, $line_string);

  return $value;
}

/**
 * [str_replace_once - remplace only first result]
 * @param  [type] $search  [string to search]
 * @param  [type] $replace [string that is replaced]
 * @param  [type] $subject [file content "file_get_contents($file)"]
 * @return [type]          [all stringsb with replace new string]
 */

function str_replace_once($search, $replace, $subject) {
    $pos = strpos($subject, $search);
    if ($pos === false) {
        return $subject;
    }
    return substr($subject, 0, $pos) . $replace . substr($subject, $pos + strlen($search));
}

function str_replace_last_once($search, $replace, $subject) {
    $pos = strrpos($subject, $search);
    if ($pos === false) {
        return $subject;
    }
    return substr($subject, 0, $pos) . $replace . substr($subject, $pos + strlen($search));
}

function del_void_line($file) {
  $stat_file = "";
  $result = "";
  $fileln      = file($file);
  foreach ($fileln as $line) {
      if(substr($line, 0,8) == "\n") {
        $stat_file = true;
      continue;
      } else {
          $result .= $line;
      }
  }
  file_put_contents($file, $result);  
  if ($stat_file == true) {
    return 1;
  } else {
    return 0;
  } 
}

function up_line($file, $string_search_up) {
  $fileln = file($file);  
  $pos = 0;
  foreach ($fileln as $line) {         
    if (strpos($line, trim($string_search_up)) !== FALSE) {
      $pos_check_regex = $pos + 1;   
    }
      $pos++;
  }   

  $line_above = $fileln[($pos_check_regex-2)]."\n";
  $line_above = trim($line_above);

  if (ereg("^[a-zA-Z0-9\-_#]{1,10}", $line_above)) { 
    //Add new line(tmp) below   
    $content1       = file_get_contents($file);
    $row_regex      = explode("\n", $content1);
    $new_line_regex = $row_regex[($pos_check_regex-1)]."\n".$line_above;
      file_put_contents($file, str_replace($row_regex[($pos_check_regex-2)], $new_line_regex, $content1));
    //Delele line_above
    $content2     = file_get_contents($file);
    $row_delete   = explode("\n", $content2);
    if ($line_above != "" ) {
      file_put_contents($file, str_replace_last_once($row_delete[($pos_check_regex)]."\n", "", $content2)); 
    }
    return 1;
  } else {
    return 0;
  }
}

function down_line($file, $string_search_up) { 
  $fileln = file($file);
  if (del_void_line($file)) {
    return;
  }
  $pos = 0;
  foreach ($fileln as $line) {         
    if (strpos($line, trim($string_search_up)) !== FALSE) {
      $pos_check_regex = $pos + 1;   
    }
      $pos++;
  }

  $line_above = $fileln[($pos_check_regex)]."\n";
  $line_above = trim($line_above);

  if (ereg("^[a-zA-Z0-9\-_#]{1,10}", $line_above)) { 
    //Add two lines in line_down(reversed)
    $content1 = file_get_contents($file);
    $row_regex   = explode("\n", $content1);
    $new_line_regex = $row_regex[($pos_check_regex)]."\n".$row_regex[($pos_check_regex-1)];
      file_put_contents($file, str_replace($row_regex[($pos_check_regex-1)], $new_line_regex, $content1));
    //Delele line rule_below
    $content2     = file_get_contents($file);
    $row_delete   = explode("\n", $content2);
    if ($line_above != "" ) {
      file_put_contents($file, str_replace_last_once($row_delete[($pos_check_regex+1)]."\n", "", $content2)); 
      return 1;
    } else {
      return 0;
    }
  }
}

function del_rule_line($file, $name_rule) {
  $delRule = $name_rule;    
  $content = file_get_contents($file);
  $file_arr_ln = explode("\n", $content);
  $pos = 0;
  foreach ( $file_arr_ln as $line ) {         
    if ( strpos($line, $delRule ) !== FALSE) {
      $row = $pos + 1;        
    }
    $pos++;
  }
  if ( $name_rule != "" ) {
    $newline = "";
    file_put_contents($file, str_replace($file_arr_ln[($row-1)]."\n", $newline, $content));
    return 1;
  } else {
    return 0;
  } 
}

function change_rule_state($file, $rule_name) {
  $rule_name_on = $rule_name;    
  $fileln = file($file);
  $pos = 0;
  foreach ( $fileln as $line ) {         
    if ( strpos($line, $rule_name_on) !== FALSE) {
      $row = $pos+1;        
    }
    $pos++;
  }
  $content = file_get_contents($file);
  $row_regex    = explode("\n", $content);

  $row_regex = $row_regex[($row-1)];

  $line_stat = substr($row_regex,0,5);

  if ( $line_stat == "##-##" ) {
    //enabled rule
    $line_on  = explode("##-##", $row_regex);
    $line_on      = $line_on[1];
    file_put_contents($file, str_replace($row_regex, $line_on, $content));
    return 1;
  } 
  else if ( $line_stat != "##-##" ) {
    //disabled rule
    $line_off     = "##-##".$row_regex; 
    file_put_contents($file, str_replace($row_regex, $line_off, $content));
    return 1;
  } else {
    return 0;
  } 
}

define( 'RP_PATH', dir_path() );

 ?>
