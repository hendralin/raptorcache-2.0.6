<?php
/**
 *
 * @package Raptorcache
 * @since 1.0
 */
 
header ("Content-type: text/html; charset=utf-8");
session_start();

	$linkCookie = get_request_url();
	$linkCookie = explode('=', $linkCookie);
	$linkCookie = end($linkCookie);
	if ($linkCookie != 'init') {
		setcookie('url_link', $linkCookie); 
	}

?>