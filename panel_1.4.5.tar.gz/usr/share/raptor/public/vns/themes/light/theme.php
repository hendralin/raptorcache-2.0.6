<?php
    $colorscheme = array(
         'image_background'   => array( 255, 255, 255,   0 ),
	 'graph_background'   => array( 255, 255, 255,   0 ),
	 'graph_background_2' => array( 255, 255, 255,   0 ),
	 'grid_stipple_1'     => array( 140, 140, 140,   0 ),
         'grid_stipple_2'     => array( 200, 200, 200,   0 ),
	 'border'             => array(   255, 255, 255,   0 ),
	 'text'               => array(   73,   73,   73,   0 ),
	 'rx'                 => array( 78, 153, 213,  0 ),
	 'rx_border'	      => array(  134, 178, 213,  0 ),
	 'tx'	              => array( 251, 73,  73,  0 ),
	 'tx_border'          => array(  251, 110,  110,  0 )
     );
?>
