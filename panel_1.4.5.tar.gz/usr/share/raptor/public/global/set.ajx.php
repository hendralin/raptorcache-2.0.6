<script>

function setConf(formId, urlRequest)
{
  var str = $( "form#" + formId ).serializeArray();
  str.push({name:"tag" , value:formId});
  $.ajax({
           async: true,
           type: "POST",
           dataType: "html",
           contentType: "application/x-www-form-urlencoded",
           url: urlRequest,
           //data: {'In':var1, 'Lim':var2},
           data: str, // serialize
           beforeSend: initSet,
           success: setSucesull,
           timeout: 1000,
           error: problemSet
         }); 
  return false;
}

function initSet()
{
  var x = $('#case_alert');
  x.fadeIn( 'slow', function() {
    x.html('<div id="loading"><div style="display:inline-block;" class="icon-widget r-spin"></div>&nbsp;<?php echo $loading; ?></div>');   
  }); 
}

function setSucesull(data)
{
  var x = $('#case_alert');
  x.fadeIn( 'slow', function() {
    //x.html('<div id="loading">' + data + '</div>');   
    if (data != "Error") {
      x.html('<div id="loading"><div style="display:inline-block;" class="icon-widget r-spin"></div>&nbsp;<?php echo $alert_change_ok; ?></div>');  
    } else {
      x.html('<div id="loading"><div style="display:inline-block;" class="icon-widget r-spin"></div>&nbsp;<?php echo $alert_error; ?></div>');
    }    
    setTimeout(function() { 
        x.fadeOut('slow');           
    }, 1000);        
  }); 

}

function problemSet()
{
  $("#case_alert").html('<div id="loading"><div style="display:inline-block;" class="icon-widget r-spin"></div>&nbsp;<?php echo $alert_error; ?></div>'); 
} 

</script>