
  <form id="addAddressNameForm" action="address_list.req" method="POST">
    <table class="tab_modal in-large" cellspacing='0'>     
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td>
        <input id="add_addressList_name" type="hidden" name="add_addressList_name" value="1" />
      </td></tr>
      <tr><td class="lb-in-large">Name:&nbsp;&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input style="width: 100%;height: 20px;" id="name" type="text" name="name" value="" required></td></tr>     
    </table>
  </form>
 