<?php 
$ip_mk = $_GET['ip_mk'];
$user_mk = $_GET['user_mk'];
$pass_mk = $_GET['pass_mk'];
 ?>
  <form action="mk_u_list.req" method="POST" id="conMkForm" name="conMkForm">
    <table class="tab_modal in-short" style="border-radius: 3px;" cellspacing='0'>    
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td><input id="conn_mk" type="hidden" name="conn_mk" value="conn_mk" /></td></tr>     
      <tr><td class="in-short">IP:&nbsp;</td><td class="in-medium"><input id="ip_mk" type="text" name="ip_mk" value="<?php echo $ip_mk; ?>" placeholder="0.0.0.0" /></td></tr>
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
      <tr><td class="in-short">User:&nbsp;</td><td class="in-medium"><input id="user_mk" type="text" name="user_mk" value="<?php echo $user_mk; ?>" /></td></tr>
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
      <tr><td class="in-short">Password:&nbsp;</td><td class="in-medium"><input id="pass_mk" type="password" name="pass_mk" value="<?php echo $pass_mk; ?>" /></td></tr>        
    </table>
  </form>