<?php 
require_once "../../../main/settings.php";
require_once "../../../lang/$deflang.php";

if (!function_exists('get_view_link')) {
	require_once "../../../main/functions.php";
}

require_once '../../../models/autoload.php';
use Raptor\Models\Network;
$net = new Network();

 ?>

	<form id="firRuleForm" action="crud_rp_lst.req" method="POST">
		<table class="tab_modal in-short" cellspacing='0'>		 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><input id="filter_rule" type="hidden" name="filter_rule" value="" /></td></tr>
			<tr><td><input id="location" type="hidden" name="location" value="Raptor_Firewall" /></td></tr>
			<tr><td><input id="file" type="hidden" name="file" value="/etc/raptor/fw.sh" /></td></tr>
			<tr><td class="in-short">Name Rule:&nbsp;</td><td><input id="name" type="text" name="name" value="" required/></td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Chain:&nbsp;</td><td>
				<select name="chain" id="chain">
					<option value="INPUT" select>INPUT</option>
					<option value="OUTPUT">OUTPUT</option>
					<option value="FORWARD">FORWARD</option>
				</select>
			</td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>

			<tr><td>&nbsp;</td><td>
				<input value="1" id="src" name="src_dst" class="subject-list" type="checkbox">Src.  
    			<input value="2" id="dst" name="src_dst" class="subject-list" type="checkbox">Dst.
			</td></tr>		
			<tr><td class="in-short">Address:&nbsp;</td><td><input id="address" name="address" type="text" value="" placeholder="0.0.0.0/0" disabled/></td></tr>		

			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">In Interface:&nbsp;</td><td>
				<select name="in_interface" id="in_interface_f">
					<option value="" select></option>
					<?php $net->showNameInterfaces(); ?>
				</select>
			</td></tr>
			
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="out-short">Out Interface:&nbsp;</td><td>
				<select name="out_interface" id="out_interface_f">
					<option value="" select></option>
					<?php $net->showNameInterfaces(); ?>
				</select>
			</td></tr>

			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Action:&nbsp;</td><td>
				<select name="action" id="action">
					<option value="ACCEPT" select>ACCEPT</option>
					<option value="DROP">DROP</option>
				</select>
			</td></tr>								 
		</table>
	</form>

<script src="<?php echo get_view_link(); ?>/js/rpform.e.js"></script>
<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>

