
<?php

	require_once '../../../models/autoload.php';
	use Raptor\Models\AddressList;
	$tblList = new AddressList();
	$listName = $tblList->getListName();

?>

  <form id="addAddressItemForm" action="address_list.req" method="POST">
    <table class="tab_modal in-large" cellspacing='0'>     
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td>
        <input id="add_addressList_item" type="hidden" name="add_addressList_item" value="1" />
      </td></tr>
      <tr><td class="lb-in-large">List:&nbsp;&nbsp;</td>
	  	<td class="in-large" style="padding: 8px 0;">
			<select name="list" id="list">
				<option value=""></option>
				<?php
				foreach ($listName as $value) {
					echo "<option value=\"{$value}\">{$value}</option>";
				}
				?>
			</select>		
		</td>
	  </tr>     
      <tr><td class="lb-in-large">Address:&nbsp;&nbsp;</td>
	  	<td class="in-large" style="padding: 8px 0;"><input style="width: 100%;height: 20px;" id="address" type="text" name="address" value="" required></td>
	  </tr>    	  	   	  
    </table>
  </form>
 