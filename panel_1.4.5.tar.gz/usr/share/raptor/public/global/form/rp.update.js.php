<script>

	$(document).ready(alert_msn);
	function alert_msn() {
		var lnk_core, lnk_panel, lnk_services, alert_div;
		alert_div = $("#alert_update");
		lnk_core = $("#tbl_update > tbody > tr.row.t_core > td:nth-child(3) > a");
		lnk_panel = $("#tbl_update > tbody > tr.row.t_panel > td:nth-child(3) > a");
		lnk_services = $("#tbl_update > tbody > tr.row.t_services > td:nth-child(3) > a");
		if ( lnk_core.length > 0 && lnk_services.length > 0 && lnk_panel.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " Core, Panel y Services ". $str_available; ?></div>");
		}
		else if ( lnk_core.length > 0 && lnk_panel.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " Core y Panel ". $str_available; ?></div>");
		}
		else if ( lnk_core.length > 0 && lnk_services.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " Core y Services ". $str_available; ?></div>");
		}
		else if ( lnk_services.length > 0 && lnk_panel.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " Panel y Services ". $str_available; ?></div>");
		}
		else if ( lnk_core.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " Core ". $str_available; ?></div>");
		}
		else if ( lnk_panel.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " WebPanel ". $str_available; ?></div>");
		}
		else if ( lnk_services.length > 0 ) {
			alert_div.html("<div id='case_blue'><?php echo $str_update . " Services ". $str_available; ?></div>");			
		}
		else {
			alert_div.html("<div id='case_green'><?php echo $str_update . " OK" ?></div>");
		}	
		return alert_div.fadeIn( 'slow' );
	}

	$(".update_v").on("click", function(e) {
		e.preventDefault();
		var up_type = $(this).data("update");
		updateRp(up_type);
	});

	function updateRp(type) {	
		var data_update	= type;
	$.ajax({
			async: true,
			type: "POST",
			dataType: "html",
			contentType: "application/x-www-form-urlencoded",
			url: "../controllers/req/update.req.php",
			data: {"update":data_update}, 
			beforeSend: initSubmit,
			success: responseMessage,
			timeout: 120000,
			error: submitError
			}); 
	return false;		
	}

	function initSubmit()
	{
		var x = $("#case_restart_alert");
		x.html('<div id="loading" style="display:none;"><div style="display:inline-block;" class="icon-widget r-spin"></div><span>&nbsp;Updating...</span></div>');
		$('#loading').fadeIn( 'slow' );
	}

	function responseMessage(menssage)
	{
		var res = menssage.split("&nbsp;");
		if (res[1] == "Core") {
			$("#tbl_update > tbody > tr.t_core > td:nth-child(3)").html("<span class='unactive'><span class='icon-cog'></span></span>");
			$('#case_blue:contains(Core)').filter(function() {
				return $(this).children().length === 0;  
			}).text(function(index, text) {
				return text.replace(/Core/g, '');
			});		
		}
		else if (res[1] == "Panel") {
			$("#tbl_update > tbody > tr.t_panel > td:nth-child(3)").html("<span class='unactive'><span class='icon-cog'></span></span>");
			$('#case_blue:contains(Panel)').filter(function() {
				return $(this).children().length === 0;  
			}).text(function(index, text) {
				return text.replace(/Panel/g, '');
			});		
		}
		else if (res[1] == "Services") {
			$("#tbl_update > tbody > tr.t_services > td:nth-child(3)").html("<span class='unactive'><span class='icon-cog'></span></span>");
			$('#case_blue:contains(Services)').filter(function() {
				return $(this).children().length === 0;  
			}).text(function(index, text) {
				return text.replace(/Services/g, '');
			});		
		}		
		alert_msn();

		$("#loading > span").html("&nbsp;" + menssage);
			setTimeout(function() { 
			$('#loading').fadeOut( 'slow' );
		}, 1000);	
	}

	function submitError()
	{
		$("#case_restart_alert").html('<div id="loading" style="margin-left:10px;"><div style="display:inline-block;" class="icon-widget r-spin"></div>Problem in the server...</div>');  
		$('#loading').fadeOut( 'slow');	
	}

	// Load changeLog text
	$(function() {
	var coreLog, paneLog, servicesLog,
		coreLog = $(".coreLogDiv").dialog({
		autoOpen: false,
		height: 460,
		width: 488,
		modal: true,
		open: function() {
			$(".coreLogDiv").load('../public/global/form/logUpdate.php?log=core');
		},
		buttons: false,
		close: function() {}
		});
	$(".coreLog").on("click", function() {
		coreLog.dialog("open");
	});

	paneLog = $(".panelDiv").dialog({
		autoOpen: false,
		height: 460,
		width: 488,
		modal: true,
		open: function() {
		$(".panelDiv").load('../public/global/form/logUpdate.php?log=panel');
		},
		buttons: false,
		close: function() {}
	});
	$(".panelLog").on("click", function() {
		paneLog.dialog("open");
	});

	servicesLog = $(".servicesDiv").dialog({
		autoOpen: false,
		height: 460,
		width: 488,
		modal: true,
		open: function() {
		$(".servicesDiv").load('../public/global/form/logUpdate.php?log=services');
		},
		buttons: false,
		close: function() {}
	});
	$(".servicesLog").on("click", function() {
		servicesLog.dialog("open");
	});

	});

</script>