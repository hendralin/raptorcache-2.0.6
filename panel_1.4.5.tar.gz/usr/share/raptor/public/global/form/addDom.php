<?php 

if (isset($_GET['file_location'])) {
  $file_location = $_GET['file_location'];
} else {
  echo '<strong>!</strong>Error no file location';
  exit();  
}

if (isset($_GET['location'])) {
  $location = $_GET['location'];
} else {
  echo '<strong>!</strong>Error location';
  exit();  
} 

 ?>

	<form id="addDomForm" action="crud_rp_lst.req" method="POST">
		<table class="tab_modal in-short" cellspacing='0'>		 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td>
				<input id="add_domain" type="hidden" name="add_domain" value="1" />
				<input id="location" type="hidden" name="location" value="<?php echo $location; ?>" />
				<input id="file" type="hidden" name="file" value="<?php echo $file_location; ?>" />
			</td></tr>			
			<tr><td class="in-short">Name Rule:&nbsp;</td><td><input id="name" type="text" name="name" value="" required/></td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Domain:&nbsp;</td><td><input id="domain" type="text" name="domain" value="" placeholder="example.com" required/></td></tr>									 
		</table>
	</form>
