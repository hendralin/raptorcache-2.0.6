<?php 
require_once "../../../main/settings.php";
require_once "../../../lang/$deflang.php";

if (!function_exists('get_view_link')) {
	require_once "../../../main/functions.php";
}

require_once '../../../models/autoload.php';
use Raptor\Models\Network;
use Raptor\Models\AddressList;
$net = new Network();
$address = new AddressList();

 ?>

	<form id="natRuleForm" action="crud_rp_lst.req" method="POST">
		<table class="tab_modal in-short" cellspacing='0'>		 
			<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
			<tr><td><input id="nat_rule" type="hidden" name="nat_rule" value="" /></td></tr>
			<tr><td><input id="location" type="hidden" name="location" value="Raptor_Firewall" /></td></tr>
			<tr><td><input id="file" type="hidden" name="file" value="/etc/raptor/fw.sh" /></td></tr>
			<tr><td class="in-short">Name Rule:&nbsp;</td><td><input id="name" type="text" name="name" value="" required/></td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Chain:&nbsp;</td><td>
				<select name="chain" id="chain">
					<option value="PREROUTING" select>PREROUTING</option>
					<option value="POSTROUTING">POSTROUTING</option>
				</select>
			</td></tr>	 
			<tr><td>&nbsp;</td><td></td></tr>			

			<tr><td>&nbsp;</td><td>
				<input value="1" id="src_list" name="type_list" class="address_list" type="checkbox">Src. List 
    			<input value="2" id="dst_list" name="type_list" class="address_list" type="checkbox">Dst. List
			</td></tr>			
			<tr><td class="in-short">Address List:&nbsp;</td>
			    <td>
					<select name="address_list_name" id="address_list_name" disabled>
						<option value=""></option>
				<?php
					$listName = $address->getListName();
					foreach ($listName as $value) {
						echo "<option value=\"{$value}\">{$value}</option>";
					}
				?>
					</select>
				</td></tr> 
			<tr><td>&nbsp;</td><td></td></tr>

			<tr><td>&nbsp;</td><td>
				<input value="1" id="src_port" name="type_port" class="port-list" type="checkbox">Src. Port 
    			<input value="2" id="dst_port" name="type_port" class="port-list" type="checkbox">Dst. Port
			</td></tr>			
			<tr><td class="in-short">Port:&nbsp;</td><td><input id="port_number" name="port_number" type="text" value="" placeholder="0-65535" disabled/></td></tr> 						

			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">In Interface:&nbsp;</td><td>
				<select name="in_interface" id="in_interface_n">
					<option value="" select></option>
					<?php $net->showNameInterfaces(); ?>
				</select>
			</td></tr>
			
			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="out-short">Out Interface:&nbsp;</td><td>
				<select name="out_interface" id="out_interface_n">
					<option value="" select></option>
					<?php $net->showNameInterfaces(); ?>
				</select>
			</td></tr>			

			<tr><td>&nbsp;</td><td></td></tr>
			<tr><td class="in-short">Action:&nbsp;</td><td>
				<select name="action" id="action">
					<option value="ACCEPT" select>ACCEPT</option>
					<option value="REDIRECT">REDIRECT</option>
					<option value="MASQUERADE">MASQUERADE</option>
				</select>
			</td></tr>
			
			<tr><td>&nbsp;</td><td></td></tr>			
			<tr><td class="in-short">To Port:&nbsp;</td><td><input id="to_port" name="to_port" type="text" value="" placeholder="0-65535" disabled/></td></tr>					
		</table>
	</form>

<script src="<?php echo get_view_link(); ?>/js/rpform.e.js"></script>

