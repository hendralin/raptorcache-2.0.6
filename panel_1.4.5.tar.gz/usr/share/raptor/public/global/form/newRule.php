<?php 

if (isset($_GET['file_location'])) {
  $file_location = $_GET['file_location'];
} else {
  echo '<strong>!</strong>Error no file location';
  exit();  
}

if (isset($_GET['location'])) {
  $location = $_GET['location'];
} else {
  echo '<strong>!</strong>Error location';
  exit();  
} 

 ?>

  <form id="newRuleForm" action="crud_rp_lst.req" method="POST">
    <table class="tab_modal in-large" cellspacing='0'>     
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td>
        <input id="new_regex" type="hidden" name="new_regex" value="1" />
        <input id="location" type="hidden" name="location" value="<?php echo $location; ?>" />
        <input id="file" type="hidden" name="file" value="<?php echo $file_location; ?>" />
      </td></tr>
      <tr><td class="lb-in-large">Name:&nbsp;&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input style="min-width: 820px;width: 100%;height: 20px;" id="name" type="text" name="name" value="" required></td></tr>
      <tr><td class="lb-in-large">Rule:&nbsp;&nbsp;</td><td class="in-large"><input style="min-width: 820px;width: 100%;height: 20px;" id="nameregex" name="nameregex" value="" required></td></tr>        
    </table>
  </form>
 
