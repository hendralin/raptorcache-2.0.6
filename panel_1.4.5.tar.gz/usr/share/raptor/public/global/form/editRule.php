<?php 

$location = isset($_GET['location']) ? $_GET['location'] : 'System';

if ($_GET['id'] != '' && $_GET['file_location'] != '') {
	$val = $_GET['id'];
	$file_location = $_GET['file_location'];
} else {
	header("Location: {$location}");
}
 
$rule = file_get_contents($file_location);
$rule = explode("\n", $rule);
$rule = explode("#name#", trim($rule[$val]));

$checkDisabledRule = substr($rule[0],0,5);
if ($checkDisabledRule == "##-##") {
	$rule[0] = substr($rule[0], 5);
} 

 ?>

  <form id="editRuleForm" action="crud_rp_lst.req" method="GET">
    <table class="tab_modal in-large" cellspacing='0'>
	  <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td><input id="idrule" type="hidden" name="idrule" value="<?php echo $val; ?>" /></td></tr>
      <tr><td><input id="edit_regex" type="hidden" name="edit_regex" value="" /></td></tr>
      <tr><td><input id="location" type="hidden" name="location" value="<?php echo $location; ?>" /></td></tr>
      <tr><td><input id="file" type="hidden" name="file" value="<?php echo $file_location; ?>" /></td></tr>
      <tr><td class="lb-in-large">Name:&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input id="namerule" style="min-width: 820px;width: 100%;height: 20px;" type="text" name="namerule" value="<?php echo $rule[1]; ?>" required/></td></tr>
      <tr><td class="lb-in-large">Rule:&nbsp;</td><td class="in-large"><input id="rule" style="min-width: 820px;width: 100%;height: 20px;" type="text" name="rule" value="<?php echo $rule[0]; ?>" required/></td></tr>         
    </table>
  </form>

