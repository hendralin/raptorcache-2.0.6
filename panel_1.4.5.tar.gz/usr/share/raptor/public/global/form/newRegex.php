<?php

if (isset($_GET['file_regex'])) {
  $file_regex = $_GET['file_regex'];
} else {
  echo '<strong>!</strong>Error no file location';
  exit();  
}

if (isset($_GET['location'])) {
  $location = $_GET['location'];
} else {
  echo '<strong>!</strong>Error location';
  exit();  
}

?>


  <form id="newRegexForm" action="<?php echo $location; ?>" method="POST">
    <table class="tab_modal in-large" cellspacing='0'>     
      <tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
      <tr><td>
        <input id="new_regex" type="hidden" name="new_regex_pl" value="1" />
        <input id="location" type="hidden" name="location" value="<?php echo $location; ?>" />
        <input id="file" type="hidden" name="file" value="<?php echo $file_regex; ?>" />
      </td></tr>
      <tr><td class="lb-in-large">Name:&nbsp;&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input style="min-width: 820px;width: 100%;height: 20px;" id="name" type="text" name="name" value="" required></td></tr>
      <tr><td class="lb-in-large">Regex:&nbsp;&nbsp;</td><td class="in-large"><input style="min-width: 820px;width: 100%;height: 20px;" id="regex" name="regex" value="" required></td></tr>        
    </table>
  </form>

