<?php 
require_once "../../../main/settings.php";
require_once "../../../lang/$deflang.php";

if (!function_exists('num_eth')) {
	require_once "../../../main/functions.php";
}

require_once '../../../models/autoload.php';
use Raptor\Models\Network;
$net = new Network();

 ?>

<form action="network_add_ip.req" method="POST" id="addIpForm" name="addIpForm">
	<table class="tab_modal in-short" cellspacing='0'>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
		<tr>
			<td><?php echo $net_iface; ?>&nbsp;</td>
			<td >
				<select name="interface" id="interface">
					<option value=""></option>
					<?php $net->showNameInterfaces(); ?>
				</select>					
			</td>	
		</tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>		
		<tr><td><input id="name" type="hidden" name="enviar_regex" value="" /></td></tr>
		<tr><td><span>IP:</span>&nbsp;</td><td><input id="ip" type="text" name="ip" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>					 
		<tr><td>Netmask:&nbsp;</td><td><input id="netmask" type="text" name="netmask" value="" placeholder="255.255.255.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>					 
		<tr><td>Network:&nbsp;</td><td><input id="network" type="text" name="network" value="" placeholder="0.0.0.0" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>					 
		<tr><td>Broadcast:&nbsp;&nbsp;</td><td><input id="broadcast" type="text" name="broadcast" value="" placeholder="0.0.0.255" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>
		<tr><td>&nbsp;</td><td>&nbsp;</td></tr>					 
		<tr><td>Gateway:&nbsp;</td><td><input id="gateway" type="text" name="gateway" value="" autocomplete="off" />&nbsp;&nbsp;<span class='validate_ip'></span></td></tr>					 
	</table>
</form>

<script src="<?php echo get_view_link(); ?>/js/val_ip.js"></script>