<?php 

$location = isset($_GET['location']) ? $_GET['location'] : 'System';

if ($_GET['id'] != '' && $_GET['file_regex'] != '') {
	$val = $_GET['id'];
	$file_regex = $_GET['file_regex'];
} else {
	header("Location: {$location}");
}

$rule = file_get_contents($file_regex);
$rule = explode("\n", $rule);
$rule = explode("#name#", trim($rule[$val]));

$checkDisabledRule = substr($rule[0],0,5);
if ($checkDisabledRule == "##-##") {
	$rule[0] = substr($rule[0], 5);
	$format = substr($rule[0], 14);
	$format = explode("/){", $format);	
} else {
	$format = substr($rule[0], 14);
	$format = explode("/){", $format);	
}

 ?>

  <form id="editRegexPlForm" action="<?php echo $location; ?>" method="POST">
    <table class="tab_modal in-large" cellspacing='0'>
	<tr><td>&nbsp;</td><td>&nbsp;</td></tr> 
	      <tr><td><input id="idregex" type="hidden" name="idregex" value="<?php echo $val; ?>" /></td></tr>
      <tr><td>
        <input id="new_regex" type="hidden" name="edit_regex_pl" value="1" />
        <input id="location" type="hidden" name="location" value="<?php echo $location; ?>" />
        <input id="file" type="hidden" name="file" value="<?php echo $file_regex; ?>" />	  
	  </td></tr>

      <tr><td class="lb-in-large">Name:&nbsp;</td><td class="in-large" style="padding: 8px 0;"><input id="name" style="min-width: 820px;width: 100%;height: 20px;" type="text" name="name" value="<?php echo $rule[1]; ?>" required/></td></tr>
      <tr><td class="lb-in-large">Regex:&nbsp;</td><td class="in-large"><input id="regex" style="min-width: 820px;width: 100%;height: 20px;" type="text" name="regex" value="<?php echo $format[0]; ?>" required/></td></tr>         
    </table>
  </form>

