<?php 
if ($_GET['log'] == "core") {
	$log = "/etc/raptor/up.v/core_changelog.txt";
}
else if ($_GET['log'] == "panel") {
	$log = "/etc/raptor/up.v/panel_changelog.txt";
}
else if ($_GET['log'] == "services") {
	$log = "/etc/raptor/up.v/services_changelog.txt";
}

 ?>

		<table class="tab_modal" cellspacing='0' id="coreLogForm" name="coreLogForm">	 
			<tr><td>&nbsp;</td><td><textarea style="font-size:12px;margin-top: 10px;" readonly rows="24" cols="60" name="content"><?php readfile($log); ?></textarea></td></tr> 
		</table>
