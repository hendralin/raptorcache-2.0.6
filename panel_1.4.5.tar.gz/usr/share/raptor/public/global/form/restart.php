<script>
function restart(file_shutdown) {
	var msnConfirm;
	if (file_shutdown == 'shut_rp.req') {
		var msnConfirm = '<?php echo $alert_rp_restart; ?>';
		var msn = '<?php echo $bt_restart; ?>' + ' Raptor';
	} 
	else if (file_shutdown == 'shut_restart.req') {
		var msnConfirm = '<?php echo $alert_restarting; ?>';
		var msn = '<?php echo $bt_restart; ?>' + ' Servidor';
	}
	else if (file_shutdown == 'shut_down.req') {
		var msnConfirm = '<?php echo $alert_sysshut; ?>';
		var msn = 'Server turned off';
	}	
	if (confirm(msnConfirm)) {   		
		$.ajax({
		       async: true,
		       type: "POST",
	           dataType: "html",        
	           contentType: "application/x-www-form-urlencoded",	       
		       url: file_shutdown,
		       data: "1",
		       beforeSend: initSubmit(msn),
		       success: responseMessage,
		       timeout: 60000,
		       error: submitError
		});			
	}
}

function initSubmit(msn)
{
	if (msn == '<?php echo $bt_restart; ?>' + ' Servidor' || msn == 'Server turned off') {		
		document.body.innerHTML = '<h1>' + msn + '...</h1>';
		setTimeout(function() { 
            window.location = 'System'; 
    	}, 60000);
		return false;
	}
	var x = $("#case_restart_alert");
	x.html('<div id="loading" style="display:none;"><div style="display:inline-block;" class="icon-widget r-spin"></div>&nbsp;'+ msn +'</div>');
	$('#loading').fadeIn( 'slow' );
}
function responseMessage(menssage)
{
	$('#loading').fadeOut( 'slow' );
/*
		var loc = window.location.pathname;
		loc = loc.split("/").pop(-1);
		window.location = loc;	
 */	
}
function submitError()
{
	$("#case_restart_alert").html('<div id="loading"><div style="display:inline-block;" class="icon-widget r-spin"></div>Problem in the server...</div>');  
	$('#loading').fadeOut( 'slow');	
} 	
</script>