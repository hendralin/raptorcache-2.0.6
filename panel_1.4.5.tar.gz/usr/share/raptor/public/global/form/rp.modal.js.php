<script>

$( function() {
    var editRule, newRuleDiv, firRuleDiv, natRuleDiv, addDomDiv, form, addAddressNameDiv, addAddressItemDiv, newRegexDiv, editRegexPl;

    var emailRegex = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,
      name = $( "#name" ),
      nameRegex = $( "#nameregex" ),
      email = $( "#email" ),
      password = $( "#password" ),
      allFields = $( [] ).add( name ).add( email ).add( password ),
      tips = $( ".validateTips" );

// Generate modal Edit Rule
    editRule = $( ".editRuleDiv" ).dialog({
      autoOpen: false,
      height: 206,
      width: 930,
      modal: true,
      open: function () {            	
              var file_location = "<?php echo $this->value["file_route"]; ?>";
              var location = "<?php echo get_request_url(); ?>";
              $(".editRuleDiv").load('../public/global/form/editRule.php?id='+dat+'&file_location='+file_location+'&location='+location);                   
            },
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if (!$('#namerule').val() || !$('#rule').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#editRuleForm").submit();
          }      
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 

    $( ".editRule" ).on( "click", function() {
      editRule.dialog( "open" );
    });

// Generate modal New Rule
    newRuleDiv = $( ".newRuleDiv" ).dialog({
      autoOpen: false,
      height: 206,
      width: 930,
      modal: true,
      open: function () {             
              var file_location = "<?php echo $this->value["file_route"]; ?>";
              var location = "<?php echo get_request_url(); ?>";
              $(".newRuleDiv").load('../public/global/form/newRule.php?file_location='+file_location+'&location='+location);                   
            },      
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val() || !$('#nameregex').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#newRuleForm").submit();
          }       
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".newRule" ).on( "click", function() {
      newRuleDiv.dialog( "open" );
    });

// Generate modal Filter Rule
    firRuleDiv = $( ".firRuleDiv" ).dialog({
      autoOpen: false,
      height: 338,
      width: 292,
      modal: true,
      open: function () {             
                $(".firRuleDiv").load('../public/global/form/firRule.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#firRuleForm").submit();
          }          
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".firRule" ).on( "click", function() {
      firRuleDiv.dialog( "open" );
    }); 

// Generate modal NAT Rule
    natRuleDiv = $( ".natRuleDiv" ).dialog({
      autoOpen: false,
      height: 428,
      width: 292,
      modal: true,
      open: function () {             
                $(".natRuleDiv").load('../public/global/form/natRule.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val()) {  
            alert('Please, insert Name');
            return false;  
          } else {
            $("#natRuleForm").submit();
          }          
        }
		
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".natRule" ).on( "click", function() {
      natRuleDiv.dialog( "open" );
    }); 	   

// Generate modal Add Domain
    addDomDiv = $( ".addDomDiv" ).dialog({
      autoOpen: false,
      height: 192,
      width: 284,
      modal: true,
      open: function () {    
              var file_location = "<?php echo $this->value["file_route"]; ?>";
              var location = "<?php echo get_request_url(); ?>";
              $(".addDomDiv").load('../public/global/form/addDom.php?file_location='+file_location+'&location='+location);                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val() || !$('#domain').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#addDomForm").submit();
          }          
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".addDomain" ).on( "click", function() {
      addDomDiv.dialog( "open" );
    });     

// Generate modal add Address Name
    addAddressNameDiv = $( ".addAddressNameDiv" ).dialog({
      autoOpen: false,
      height: 172,
      width: 292,
      modal: true,
      open: function () {             
                $(".addAddressNameDiv").load('../public/global/form/addAddressName.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val()) {  
            alert('Please, insert Name');
            return false;  
          } else {
            $("#addAddressNameForm").submit();
          }          
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".addAddressName" ).on( "click", function() {
      addAddressNameDiv.dialog( "open" );
    }); 

// Generate modal add Address Item
    addAddressItemDiv = $( ".addAddressItemDiv" ).dialog({
      autoOpen: false,
      height: 208,
      width: 292,
      modal: true,
      open: function () {             
                $(".addAddressItemDiv").load('../public/global/form/addAddressItem.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#address').val()) {  
            alert('Please, insert List or Name');
            return false;  
          } else {
            $("#addAddressItemForm").submit();
          }          
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".addAddressItem" ).on( "click", function() {
      addAddressItemDiv.dialog( "open" );
    }); 	

// Generate modal New Regex Pl
    newRegexDiv = $( ".newRegexDiv" ).dialog({
      autoOpen: false,
      height: 206,
      width: 930,
      modal: true,
      open: function () {             
              var file_regex = "<?php echo $this->value["file_regex"]; ?>";
              var location = "<?php echo get_request_url(); ?>";
              $(".newRegexDiv").load('../public/global/form/newRegex.php?file_regex='+file_regex+'&location='+location);                   
            },      
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if(!$('#name').val() || !$('#regex').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#newRegexForm").submit();
          }       
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 
    $( ".newRegexPl" ).on( "click", function() {
      newRegexDiv.dialog( "open" );
    });

// Generate modal Edit Regex PL
    editRegexPl = $( ".editRegexPlDiv" ).dialog({
      autoOpen: false,
      height: 206,
      width: 930,
      modal: true,
      open: function () {            	
              var file_regex = "<?php echo $this->value["file_regex"]; ?>";
              var location = "<?php echo get_request_url(); ?>";
              $(".editRegexPlDiv").load('../public/global/form/editRegexPl.php?id='+dat+'&file_regex='+file_regex+'&location='+location);                   
            },
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if (!$('#name').val() || !$('#regex').val()) {  
            alert('Please, insert Name o Rule');
            return false;  
          } else {
            $("#editRegexPlForm").submit();
          }      
        } 
      },
      close: function() {
        allFields.removeClass( "ui-state-error" );
      }
    }); 

    $( ".editRegexPl" ).on( "click", function() {
      editRegexPl.dialog( "open" );
    });

});


</script>