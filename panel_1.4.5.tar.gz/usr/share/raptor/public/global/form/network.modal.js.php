<script>
  $( function() {
    var addIp, addGw, addBr;
// change IP    
    addIp = $( ".addIpDiv" ).dialog({
      autoOpen: false,
      height: 332,
      width: 320,
      modal: true,
      open: function () {             
                $(".addIpDiv").load('../public/global/form/addIp.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if ( !$('#interface').val() ) {  
            alert('Please, select Interface');
            return false;  	
		  }		
          if ( !$('#ip').val() ) {  
            alert('Please, insert IP');
            return false;  
          } else {
            $("#addIpForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addIp" ).on( "click", function() {
      addIp.dialog( "open" );
    });   
// add gateway
    addGw = $( ".addGwDiv" ).dialog({
      autoOpen: false,
      height: 442,
      width: 320,
      modal: true,
      open: function () {             
                $(".addGwDiv").load('../public/global/form/addGw.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if ( !$('#ip_1').val() ) {  
            alert('Please, insert IP');
            return false;  
          } else {
            $("#addGwForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addGw" ).on( "click", function() {
      addGw.dialog( "open" );
    });
// add bridge
    addBr = $( ".addBrDiv" ).dialog({
      autoOpen: false,
      height: 366,
      width: 320,
      modal: true,
      open: function () {             
                $(".addBrDiv").load('../public/global/form/addBr.php');                   
            },       
      buttons: {
		"<?php echo $bt_cancel; ?>" : function(){
			$( this ).dialog( "close" );
		},		  
        "<?php echo $bt_grd; ?>": function() {
          if ( !$('#ip').val() ) {  
            alert('Please, insert IP');
            return false;  
          } else {
            $("#addBrForm").submit();
          }          
        } 
      },
      close: function() {
      }
    }); 
    $( ".addBr" ).on( "click", function() {
      addBr.dialog( "open" );
    });    

  }); 
</script>