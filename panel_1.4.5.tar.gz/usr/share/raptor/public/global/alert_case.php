<script src="<?php echo get_view_link(); ?>/js/alrt.js"></script>

<?php 
	$location_url = explode("/", $_SERVER['REQUEST_URI']);
	$location_url = end($location_url);
	if (isset($_GET['accion']) || $_GET['error']) {
		$location_url = explode("?", $location_url);
		$location_url = $location_url[0];
	}

	$idName = "";
	if ($_GET['error'] == 1) {
		$idName = "error";
		echo "<div id=\"error\" style=\"display:none;\"><div class=\"icon-widget r-spin\"></div> {$alert_error}</div>";
	} else if ($_GET['accion'] == 1) {
		$idName = "loading";
		echo "<div id=\"loading\" style=\"display:none;\"><div class=\"icon-widget r-spin\"></div> {$alert_change_ok}</div>";
	}
?>
<script>case_alert("<?php echo $idName; ?>", "<?php echo $location_url; ?>", "500")</script>
