<!DOCTYPE html>
<html>
<head>
	<title>ERROR</title>	
	<link rel="shortcut icon" href="imgpng/tc.png" />
    <link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<div id="all"><!-- GERAL --> 
<br />
<div id="tbod" style=""> 
<div id="bod">	     
	   <br />
       <h1 style="">Acceso Denegado</h1> 
</div>
</div>
</div><!-- GERAL -->              
<br />
</body>
</html>