function restart(file_shutdown) {
	var msnConfirm;
	if (file_shutdown == 'shut_rp.req') {
		var msnConfirm = '<?php echo $alert_rp_restart; ?>';
	} 
	else if (file_shutdown == 'shut_restart.req') {
		var msnConfirm = '<?php echo $alert_rp_restart; ?>';
	}
	else if (file_shutdown == 'shut_down.req') {
		var msnConfirm = '<?php echo $alert_sysshut; ?>';
	}

	if (confirm(msnConfirm)) {   		
		$.ajax({
		       async: true,
		       type: "POST",
	           dataType: "html",        
	           contentType: "application/x-www-form-urlencoded",	       
		       url: file_shutdown,
		       data: "1",
		       beforeSend: initSubmit,
		       success: responseMessage,
		       timeout: 60000,
		       error: submitError
		});			
	}
}

function initSubmit()
{
	var x = $("#case_float_alert");
	x.html('<div id="loading" style="margin-left:10px;display:none;"><div style="display:inline-block;" class="icon-widget r-spin"></div>&nbsp;<?php echo $alert_msg; ?></div>');
	$('#loading').fadeIn( 'slow' );
}
function responseMessage(menssage)
{
	$('#loading').fadeOut( 'slow' );
/*
		var loc = window.location.pathname;
		loc = loc.split("/").pop(-1);
		window.location = loc;	
 */	
}
function submitError()
{
	$("#case_float_alert").text('<div id="loading" style="margin-left:10px;"><div style="display:inline-block;" class="icon-widget r-spin"></div>Problem in the server...</div>');  
	$('#loading').fadeOut( 'slow');	
} 