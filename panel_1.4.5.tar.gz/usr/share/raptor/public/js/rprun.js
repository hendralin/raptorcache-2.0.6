
$(document).ready(function () {
/*
   if ( window.location.href.indexOf("/admin/System") > -1 ) {
      var sys_state = $("#sys_state");
      if (sys_state.length > 0) {  
         setInterval(function () {
            sys_state.load('../controllers/inc/sys_state.php');
         }, 5000);  
         setInterval(function () {
            $("#memory").load('../controllers/inc/mmry.php');
         }, 15000);
         setInterval(function () {
            $("#hard_disk_system").load('../controllers/inc/hds.php');
         }, 27000); 
      };   
   }
 */
	if (window.location.href.indexOf("/admin/System") > -1) {
		setInterval(function () {
			$("#memory").load('../controllers/inc/mmry.php');
		}, 15000);
		setInterval(function () {
			$("#hard_disk_system").load('../controllers/inc/hds.php');
		}, 27000);
	}
	else if ( window.location.href.indexOf("/admin/Monitor_Hard_Disk_IO") > -1 ) { 
		setInterval(function () {
			$("#io").load('../controllers/inc/iost.php');
		}, 4000);
	}   
	else if ( window.location.href.indexOf("/admin/Monitor_Hard_Disk") > -1 ) { 
		setInterval(function () {
			$("#hard_disk_view").load('../controllers/inc/hd.php');
		}, 4000);
	}   
	else if ( window.location.href.indexOf("/admin/Log_Access_HTTPS") > -1 ) { 
		setInterval(function () {
			$("#log_ajx_https").load('../controllers/inc/logs_rp_https.php');
		}, 4000);
	}   
	else if ( window.location.href.indexOf("/admin/Log_Access_HTTP") > -1 ) { 
		setInterval(function () {
			$("#log_ajx_acc").load('../controllers/inc/logs_rp_acc.php');
		}, 4000);
	}  
	else if ( window.location.href.indexOf("/admin/Ping_DNS") > -1 ) { 
		setInterval(function () {
			$("#ping_dns").load('../controllers/inc/ping_dns.php');
		}, 2000);
	}   

	$.ajaxSetup({ cache: false });   

});
