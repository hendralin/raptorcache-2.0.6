

var pattern_ip = /\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
var pattern_cidr = /\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\/?([0-9]|[1-2][0-9]|3[0-2])\b/;

$('td input[type="text"]').not('#name').keypress(function (e) {
    if (e.which != 8 && e.which != 0 && e.which != 46 && e.which != 47 && (e.which < 48 || e.which > 57)) {
        //console.log(e.which);
        return false;
    }
}).keyup(function () {
    var this1 = $(this);
    //console.log(" id= "+this1)

	if (this1.val().indexOf("/") !== -1 && !pattern_cidr.test(this1.val())) {		
		$(this).closest('td').prev('td').css({ color: "#fc4646" });
		$(this).closest('td input').css({ "border": "1px solid tomato" });
		$(this).next("span").text('!').css({ fontSize: "14px" });

		if (this1.val().length < 8 && this1.val().indexOf("/") !== -1) {
			this1.val(this1.val().replace('/', ''));
		}
		else if (this1.val().indexOf("..") !== -1) {
			this1.val(this1.val().replace('..', '.'));
		}
		else if (this1.val().indexOf("//") !== -1) {
			this1.val(this1.val().replace('//', '/'));
		}		
	}
    else if ( !pattern_ip.test(this1.val()) ) {
		console.log("-"+this1.val());
        $( this ).closest('td').prev('td').css({color : "#fc4646"});
        $( this ).closest('td input').css({"border": "1px solid tomato"});
        $( this ).next( "span" ).text('!').css({fontSize : "14px"});

        if (this1.val().indexOf("..") !== -1) 
			this1.val(this1.val().replace('..', '.'));	
					        
    } else {        
        var lastChar = this1.val().substr(this1.val().length - 1);
        if (lastChar == '.') 
            this1.val(this1.val().slice(0, -1));
        
        var ip = this1.val().split('.');
        if (ip.length == 4) {
            $( this ).closest('td').prev('td').css({"color":"#454545"});
            $( this ).closest('td input').css({"border": "1px solid #bbb"});
            $( this ).next( "span" ).text('');         
        }
    }

}); 

