var x = $(document);
x.ready(init2);

function init2() {
	$(".format").click(function(e) {
		e.preventDefault();
		var devDisk = $(this).data("format");
		var x = {"format":devDisk};
		send(x);	
	});
	$(".mount").click(function(e) {
		e.preventDefault();
		var devDisk = $(this).data("mount");
		var x = {"mount":devDisk};
		send(x);
	});	
	$(".umount").click(function(e) {
		e.preventDefault();
		var devDisk = $(this).data("umount");
		var x = {"umount":devDisk};
		send(x);
	});		
}

function send(devDisk) {
	$.ajax({
	       async: true,
	       type: "POST",
           dataType: "html",        
           contentType: "application/x-www-form-urlencoded",	       
	       url: "../controllers/ajx/mountDisk.php",
	       data: devDisk,
	       beforeSend: initSubmit,
	       success: responseMessage,
	       timeout: 120000,
	       error: submitError
	});	
	return false;
}

function initSubmit() {
	var x = $("#loading");
	x.html("<div class='icon-widget r-spin'></div> Loading...");
	x.fadeIn();
}

function responseMessage(data) {
	var x = $("#loading");
	x.html("<div class='icon-widget r-spin'></div>" +  data);
	x.fadeIn();
	setTimeout(function() { 
		x.fadeOut( 'slow' );
		window.location='Mount_Disk';
	}, 2000);	
}

function submitError() {
	var x = $("#loading");
	x.html("<div class='icon-widget r-spin'></div> Error...");
	x.fadeIn();
	setTimeout(function() { 
		x.fadeOut( 'slow' );
		window.location='Mount_Disk';
	}, 2000);	
}