if (window.location.href.indexOf("/admin/Raptor_Firewall") > -1) {

	$('#firRuleForm').mouseenter( function() {
		var subject_list = $('.subject-list');
		subject_list.on('change', function () {
			if ($('#src').prop('checked') || $('#dst').prop('checked')) 
				$('#address').prop("disabled", false);
			else 
				$('#address').prop("disabled", true);
			subject_list.not(this).prop('checked', false);
		});

		var in_interface_f, out_interface_f;
		in_interface_f = $('#in_interface_f');
		out_interface_f = $('#out_interface_f');
		in_interface_f.on("click", function () {
			out_interface_f.children('option').each(function () {
				out_interface_f.val(out_interface_f.find("option[selected]").val());
			});
			out_interface_f.css({ "background-color": "#ebebe4" });
			in_interface_f.css({ "background-color": "#fff" });
		});
		out_interface_f.on("click", function () {
			in_interface_f.children('option').each(function () {
				in_interface_f.val(in_interface_f.find("option[selected]").val());
			});
			in_interface_f.css({"background-color": "#ebebe4"});
			out_interface_f.css({"background-color": "#fff"});
		});		
	});

	$('#natRuleForm').mouseenter( function() {
		var type_list = $('.address_list');
		var address_list = $('#address_list_name');
		type_list.on('change', function () {
			if ($('#src_list').prop('checked') || $('#dst_list').prop('checked')) {
				address_list.prop("disabled", false);
				address_list.css({ "background-color": "#fff" });
			} else  {
				address_list.prop("disabled", true);
				address_list.css({ "background-color": "#ebebe4" });
			}	
			type_list.not(this).prop('checked', false);
		});

		var port_list = $('.port-list');
		port_list.on('change', function () {
			if ($('#src_port').prop('checked') || $('#dst_port').prop('checked')) 
				$('#port_number').prop("disabled", false);
			else 
				$('#port_number').prop("disabled", true);
			port_list.not(this).prop('checked', false);
		});	

		var in_interface_n, out_interface_n;
		in_interface_n = $('#in_interface_n');
		out_interface_n = $('#out_interface_n');
		in_interface_n.on("click", function () {
			out_interface_n.children('option').each(function () {
				out_interface_n.val(out_interface_n.find("option[selected]").val());
			});
			out_interface_n.css({ "background-color": "#ebebe4" });
			in_interface_n.css({ "background-color": "#fff" });
		});
		out_interface_n.on("click", function () {
			in_interface_n.children('option').each(function () {
				in_interface_n.val(in_interface_n.find("option[selected]").val());
			});
			in_interface_n.css({"background-color": "#ebebe4"});
			out_interface_n.css({"background-color": "#fff"});
		});

		$('#natRuleForm').on('change', 'select', function (e) {
			var val, option, name;
			var val = $(e.target).val();
			var option = $(e.target).find("option:selected").text();
			var name = $(e.target).attr('name');
			if (option == "REDIRECT" && name == "action")
				$('#to_port').prop("disabled", false);
			else
				$('#to_port').prop("disabled", true);
			
		});	

	});

}