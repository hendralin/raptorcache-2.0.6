$(document).ready(function() {
  runS();
  runT();
});	

function runT()
{
	 $.getJSON("../controllers/ajx/r_threads.php", function(json) {
	 	//console.log(json);
	 	var x = json;
	 	$("#open_threads_netstat").html(x.psauxT);
	});	  
	setTimeout(runT, 2000);
}	

function runS()
{

   $.getJSON("../controllers/ajx/r_system.php") 
    .done(function(json) {
    //console.log(json);
    var x = json;
    $("#psauxT").html(x.psauxT);
    $("#stat_cache_rp").html(x.stat_cache_rp);
    //$("#version_rp").html(x.version_rp);
    $("#stat_cache_sq").html(x.stat_cache_sq);
    //$("#version_sq").html(x.version_sq);
    $("#cnx_us").html(x.cnx_us);
    $("#open_threads_netstat").html(x.open_threads_netstat);
    $("#num_us").html(x.num_us);
    //
    $("#cnx_dns").html(x.cnx_dns);
    $("#uptime").html(x.uptime);
    $("#cpu_temp").html(x.cpu_temp);
    $("#io_cpu").html(x.io_cpu);
    //
    $("#avg_1m").html(x.avg_1m +'%');
    $("#avg_5m").html(x.avg_5m +'%');
    $("#avg_15m").html(x.avg_15m +'%');

    var avg_wc_1m = $(".charts-wrapper.1m"),
        avg_wc_5m = $(".charts-wrapper.5m"),
        avg_wc_15m = $(".charts-wrapper.15m"),  
        avg_wb_1m = $("div.shadow.1m"),
        avg_wb_5m = $("div.shadow.5m"),
        avg_wb_15m = $("div.shadow.15m");          
	
	var green = '#92C443', orange = '#f99e61', red = '#fb5050'; 
		
    if ( x.avg_1m < 50 ) {
      	avg_wc_1m.css('color', green);
      	avg_wb_1m.css('border', '3px solid ' + green); 
    } else if ( x.avg_1m < 80 ) {
		avg_wc_1m.css('color', orange);
		avg_wb_1m.css('border', '3px solid ' + orange); 
    } else {
		avg_wc_1m.css('color', red);  
		avg_wb_1m.css('border', '3px solid ' + red);    
    }
    if ( x.avg_5m < 50 ) {
		avg_wc_5m.css('color', green);
		avg_wb_5m.css('border', '3px solid ' + green); 
    } else if ( x.avg_5m < 80 ) {
		avg_wc_5m.css('color', orange);
		avg_wb_5m.css('border', '3px solid ' + orange);
    } else {
		avg_wc_5m.css('color', red);  
		avg_wb_5m.css('border', '3px solid ' + red);       
    }
    if ( x.avg_15m < 50 ) {
		avg_wc_15m.css('color', green);
		avg_wb_15m.css('border', '3px solid ' + green); 
    } else if ( x.avg_15m < 80 ) {
		avg_wc_15m.css('color', orange);
		avg_wb_15m.css('border', '3px solid ' + orange);
    } else {
		avg_wc_15m.css('color', red);  
		avg_wb_15m.css('border', '3px solid ' + red);     
    } 

    var cpubar = $("#cpubar"),
        membar = $("#membar");
    cpubar.css('width', x.cpu_usage0 + '%');
    cpubar.html(x.cpu_usage1);

    membar.css('width', x.mem_value + '%');
    membar.html(x.mem_value + '%');

  });   
  setTimeout(runS, 5000);
}; 
