
	$(".del_regx").on("click", function(e) {
		e.preventDefault();
		var delete_line = $(this).data("delete_line");			
		var location = $(this).data("location");
		var file = $(this).data("file");
		delItem(delete_line, location, file);
	});
	function delItem(delete_line, location, file) 
	{
		var data_delete_line = delete_line;
		var data_location = location;
		var data_file = file;
		if(confirm("Are you shure delete item?")) {
			$.ajax({
				async:true,
				type: "POST",
				dataType: "html",
				contentType: "application/x-www-form-urlencoded",
				url: "../controllers/req/crud_rp_lst.req.php",
				data: {
						"delete_line" : data_delete_line, 
						"location" : location,
						"file" : data_file
						},
				//beforeSend: inicioEnvio,
				success: function (data) {
								window.location.href = data;		
							},
				timeout: 40000,
				error: function (data) {
							}	   
				}); 
			return false;	      
		} else {
		return false;
		}	
	}		

	$(".change_state").on("click", function(e) {
		e.preventDefault();
		var change_state, location, file;
		change_state = $(this).data('change_state');
		location = $(this).data('location');
		file = $(this).data('file');
		changeStateItem(change_state, location, file);
	});
	function changeStateItem(change_state, location, file) 
	{
		var data_change_state, data_location, data_file;
		data_change_state = change_state;
		data_file = file;
		data_location = location;
		$.ajax({
			async:true,
			type: "POST",
			dataType: "html",
			contentType: "application/x-www-form-urlencoded",
			url: "../controllers/req/crud_rp_lst.req.php",
			data: {
					"change_state" : data_change_state, 
					"file" : data_file,
					"location" : data_location
					},
			success: function (data) {						
						window.location.href = data;
						},
			timeout: 40000,
			error: function (data) {
						}	   
			}); 
		return false;	      
		
	}

	$(".move").on("click", function(e) {
		e.preventDefault();
		var regex_name, move, location, file;
		regex_name = $(this).data('regex_name');
		move = $(this).data('move');
		location = $(this).data('location');
		file = $(this).data('file');
		moveItem(regex_name, move, location, file);
	});
	function moveItem(regex_name, move, location, file) 
	{
		var data_regex_name, data_move, data_location, data_file;
		data_move = move;
		data_regex_name = regex_name;
		data_file = file;
		data_location = location;
		$.ajax({
			async:true,
			type: "POST",
			dataType: "html",
			contentType: "application/x-www-form-urlencoded",
			url: "../controllers/req/crud_rp_lst.req.php",
			data: {
					"move": data_move, 
					"regex_name" : data_regex_name, 
					"file" : data_file,
					"location" : data_location
					},
			success: function (data) {						
						window.location.href = data;
						},
			timeout: 40000,
			error: function (data) {
						}	   
			}); 
		return false;	      
		
	}	

	$(".del_address").on("click", function(e) {
		e.preventDefault();
		var list = $(this).data('list');
		var address = $(this).data('address');
		delAddressItem(list, address);
	});
	function delAddressItem(list, address) 
	{
		var data_list = list;
		var data_address = address;
		if(confirm("Are you shure delete item?")) {
			$.ajax({
				async:true,
				type: "POST",
				dataType: "html",
				contentType: "application/x-www-form-urlencoded",
				url: "../controllers/req/address_list.req.php",
				data: {
						"del_item": 1, 
						"list" : data_list, 
						"address" : data_address
						},
				success: function (data) {
								window.location.href = 'Raptor_AddressList?list=' + data;
							},
				timeout: 40000,
				error: function (data) {
								window.location.href = 'Raptor_AddressList?error=1';
							}	   
				}); 
			return false;	      
		} else {
		return false;
		}	
	}