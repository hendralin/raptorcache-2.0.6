  function case_alert(div_alert, redirect_to, time) 
  { 
  	var x;
  	x = $("#"+div_alert);
    x.fadeIn('slow', function() {
        setTimeout(function() { 
            x.fadeOut('slow', function() {
              window.location = redirect_to; 
            });           
      }, time);       
    });  
  }

  function redirect(div_alert, redirect_to)
  {
    var x;
    x = $("#"+div_alert);
    x.fadeIn('slow', function() {
      window.location = redirect_to;    
    });    
  }