<!DOCTYPE html>
<html>
<head>
	<title>ERROR</title>	
	<link rel="shortcut icon" href="imgpng/tc.png" />
    <link rel="stylesheet" href="../css/style.css" type="text/css" />
<style>

</style>

</head>
<body>
<div id="all"><!-- GERAL -->     
       <h1 style="">Acceso Denegado</h1> 
</div><!-- GERAL -->              
</body>
</html>