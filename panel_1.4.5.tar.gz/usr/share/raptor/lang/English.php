<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */
 error_reporting(0);
 
  $lang = 'en';
  
  $listMont = array('','Jan.','Feb.','March','April','May','June','July','Aug.','Sept','Oct.','Nov.','Dec.');
  $listWeek = array('','Mon'=>'Monday','Tue'=>'Tuesday','Wed'=>'Wednesday','Thu'=>'Thursday','Fri'=>'Friday','Sat'=>'Saturday','Sun'=>'Sunday');

  $serverErr ='Could not establish connection to the server.';

  $dia = array();
  
  $loginPanel        ='Login WebPanel';    
  $ident             ='Username';   
  $ident2            ='Password';
  $prof              ='Profile';
  $cantIdent         ='Username or password incorrect';          
  $identProblem1     ='Unreachable server.';
  $identProblem2     ='Technical problem.';
  $enter             ='Enter';

  $mysqlProblem1     ='Could not establish connection to the database.';

  $loading           ='Loading...'; 

  $user              ='Username:';
//
  $m_sys             ='System';
  $m_sys_cpu         ='CPU Usage';
  $m_sys_hd          ='Hard Disk';
  $m_sys_mem         ='Mem. RAM';
  $m_sys_red         ='Traf. RED';
//
  $m_est             ='&nbsp;&nbsp;Statistics&nbsp;';  
  $m_dom             ='&nbsp;&nbsp;Domains&nbsp;';
  $m_ext             ='&nbsp;&nbsp;Extensions&nbsp;';
  $m_alm             ='&nbsp;&nbsp;Storage&nbsp;';
  $m_ahr             ='&nbsp;&nbsp;Saving&nbsp;';
  $m_trf             ='&nbsp;&nbsp;Traf. RED';
  $m_res             ='&nbsp;&nbsp;Summary Total&nbsp;';
  $m_listpl          ='&nbsp;&nbsp;Raptor list&nbsp;';
  $m_onfpl           ='&nbsp;&nbsp;On / Off Plugins&nbsp;';
  $m_statepl         ='&nbsp;&nbsp;Last Activ. Plugin&nbsp;';
  $m_cc              ='&nbsp;&nbsp;Content cach&eacute&nbsp;';
  $m_ud              ='&nbsp;&nbsp;Url denied&nbsp;';
  $m_util            ='Utility&nbsp;';
  $m_dd              ='&nbsp;&nbsp;Hard Disks&nbsp;';
  $m_nconex          ='&nbsp;&nbsp;N&deg; User Conect.&nbsp;';
  $m_ajus            ='Settings&nbsp;';
  $m_config          ='Settings';
  $m_lang            ='&nbsp;&nbsp;Language&nbsp;';
  $m_reg             ='Record&nbsp;';
  $m_titlg           ='&nbsp;&nbsp;Enter your Language&nbsp;';
  $m_clg             ='&nbsp;&nbsp;Language:&nbsp;';
  $m_exit            ='&nbsp;&nbsp;Exit&nbsp;';
//
  $lang_rp           = 'English';
//  
  $rp_repdate        ='Days Storage';
  $rp_repdreq        ='Saving by days';
  $rp_repdtrd        ='Threads by days';
  $rp_repext         ='Report by Extensions';
  $rp_reptot         ='Report Summary Total';

  $rp_date           ='Date';
  $rp_files          ='Files';
  $rp_size           ='Size';
  $rp_eco            ='Economy';
  $rp_hits           ='Hits';
  $rp_porcent        ='Effectiveness';
  $rp_domain         ='Domain';
  $rp_ext            ='Ext';
  $rp_ico            ='Ico';

  $rp_edidc          ='Cache Directory';   
  $rp_edilc          ='Cache Limit';  
  $rp_edmin          ='Min. Object Size';   
  $rp_edmax          ='Max. Object Size'; 
  $rp_edyes          ='Si';  
  $rp_edno           ='No';  
//  
  $mem_memram        ='RAM Memory';
  $mem_mt            ='Total Memory';
  $mem_mu            ='Used Memory';
  $mem_ml            ='Free Memory';
  $mem_mp            ='Compart. Memory';
  $mem_mb            ='Buffers Memory';
  $mem_mc            ='Cach&eacute Memory';
  $mem_st            ='Total Swap';
  $mem_su            ='Used Swap';
  $mem_sl            ='Free Swap';
//  
  $red_tr            ='Network Trafic';
//  
  $vit_er            ='&nbsp;Status Raptor';
  $vit_es            ='&nbsp;Status Squid';
  $vit_con           ='&nbsp;Conections';
  $vit_us            ='&nbsp;Users';
  $vit_dns           ='&nbsp;DNS Cache';
  $vit_tact          ='&nbsp;Active Time';
  $vit_temp          ='&nbsp;Temperature';
//
  $sysdisk           ='Storage - RaptorCache';
  $sysdisk_nd        ='N&deg; Discs';
  $sysdisk_dsk       ='Disc';
  $sysdisk_smart     ='S.M.A.R.T.';
  $sysdisk_mod       ='Model ';
  $sysdisk_sp        ='Size ';
  $sysdisk_temp      ='Temp.';
  $sysdisk_cdir      ='Cach&eacute; Dir.';
  $sysdisk_et        ='Total Space';
  $sysdisk_eu        ='Used Space';
  $sysdisk_el        ='Free Space';
  $sysdisk_oc        ='Obj. in Cach&eacute;';
  $sysdisk_u         ='% Used';
  $sysdisk_l         ='% Free';
//
  $sq_den            ='Bloqued Websites';
  $rp_actdes         ='Enabled or Disabled plugins';
  $hlp_ej            ='To disable a plugin add <strong> # </strong> at the beginning of the line, for example.';
  $backup_bd         ='Backup Database';
  $c_user            ='Change Username and password RaptorPanel';
  $hlp               ='Help';
  $bt_agr            ='Add';
  $bt_act            ='Update';
  $bt_agr_ip         ='Add IP';
  $bt_grd            ='Save';
  $bt_re             ='Restart';
  $bt_cancel         ='Cancel';
//  
  $vns_res           ='Summary';
  $vns_hr            ='Hours';
  $vns_d             ='Days';
  $vns_m             ='Months';
  $vns_res2          ='Summary';
  $vns_t10           ='Top 10 Days';
  $vns_u24h          ='Last 24 Hours';
  $vns_u30d          ='Last 30 Days';
  $vns_u12m          ='Last 12 Months';
  $vns_eh            ='This Hora';
  $vns_ed            ='This Dia';
  $vns_em            ='This Month';
  $vns_em            ='All the Time';
  $vns_td            ='data Traffic';
  $vns_tt            ='All the Time';
//
  $hd_title          ='Information from hard drives';
  $hd_sbtitle        ='information from hard drive';
  $hd_model          ='Model';
  $hd_test           ='Test';
  $hd_temp           ='Temperature';
  $hd_size           ='Size';
  $hd_speed          ='Disk Read';
  $hd_life           ='Hours';
  $hd_monitoring     ='Monitoring';  
//
  $net_ir            ='Interface List';
  $net_ip            ='IP Address';
  $net_iface         ='Interface';
//  
  $lng_title        ='Language';
  $lng_es            ='Spanish';
  $lng_en            ='English';
  $lng_pt            ='Portuguese';
//  
  $bt_sysshut        ='Turn Off Server';  
  $bt_sysreboot      ='Reboot Server';  
  $bt_rp_restart     ='Reboot Raptor';  
  $bt_restart        ='Restarting';  
  $alert_sysshut     ='Are you shure Apagar el Servidor?';  
  $alert_sysreboot   ='Are you shure Reboot Server?';  
  $alert_rp_restart  ='Are you shure Reboot Raptor?';   
  $alert_restarting  ='Are you shure Reboot?';   
  $alert_change_ok   ='It has saved changes';  
  $alert_error       ='Error...'; 
  $alert_add_us_er   ='Could not enter the user';
  $alert_chg_us_er   ='Could not change the password'; 
  $alert_up_file_ok  ='It has been uploaded correctly';  
//
  $alert_submit      ='Are you sure you want to save changes?';
//
  $pu_title          ='Enter your Username and Password WebPanel';
  $pu_user           ='User:';
  $pu_pass           ='Password:&nbsp;&nbsp;';
  $pu_new_user       ='New User';  
  $pu_user_profile   ='Profile:';    
  $pu_change_pw      ='Change Password';  
  $pu_change_pw_l    ='Old Password:';
  $pu_change_pw_n    ='New Password:';  
  $up_dns            ='Update DNS';
  $num_cnx           ='Number of connections';
  $alert_restart     ='It has restarted';
  $alert_fw          ='It has restarted the firewall';
  $alert_no_ip       ='He could not enter the IP';
  $alert_iface       ='Choose a Network Interface';
  $alertpu_uspass    ='Please enter your Username and Password';
  $alertpu_us        ='Please enter your Username';
  $alertpu_pass      ='Please enter your Password';
  $alertpu_len       ='Your password must be more than 4 characters';
  $alertpu           ='Are you sure to change your username and password?';
//
  $alert_lang        ='Not entered your Language';   
  $alert_langok      ='Changed your language WebPanel';  
//  
  $io_r_user         ='Show the percentage of CPU utilization that occurred while executing at the user level (application).';
  $io_r_nice         ='Show the  percentage of CPU utilization that occurred while executing at the user level with nice priority.';
  $io_r_sys          ='Show the percentage of CPU utilization  that  occurred while executing at the system level (kernel).';
  $io_r_iowait       ='Show the  percentage of time that the CPU or CPUs were idle during which the system had an outstanding disk I/O request.';
  $io_r_idle         ='Show the  percentage of time that the CPU or CPUs were idle and the system did not have an outstanding disk  I/O request.';

  $io_r_dev          ='This column gives the device (or partition) name.';
  $io_r_tps          ='Indicate the number of transfers per second that were issued to the device.';
  $io_r_blk_read_s   ='Indicate the amount of data read from the drive expressed in a number of blocks per second.';
  $io_r_blk_wrtn_s   ='Indicate the amount of data written to the drive expressed in a number of blocks per second.';
  $io_r_blk_read     ='The total number of blocks read.';
  $io_r_blk_wrtn     ='The total number of blocks written.';
  $io_r_kb_read_s    ='Indicate the amount of data read from the drive expressed in kilobytes per second.';
  $io_r_kb_wrtn_s    ='Indicate the amount of data written to the drive expressed in kilobytes per second.';
  $io_r_kb_read      ='The total number of kilobytes read.';
  $io_r_kb_wrtn      ='The total number of kilobytes written.';
  $io_r_rrqm_s       ='The number of read requests merged per second that were issued to the device.';
  $io_r_wrqm_s       ='The number of write requests merged per second that were issued to the device.';
  $io_r_r_s          ='The number of read requests that were issued to the device per second.';
  $io_w_r_s          ='The number of write requests that were issued to the device per second.';
  $io_r_rsec_s       ='The number of sectors read from the device per second.';
  $io_w_rsec_s       ='The number of sectors written to the device per second.';
  $io_r_rkB_s        ='The number of kilobytes read from the device per  second.';
  $io_w_rkB_s        ='The number of kilobytes written to the device per second.';
  $io_r_avgrq_sz     ='The average size (in sectors) of the requests that were issued to the device.';
  $io_r_avgqu_sz     ='The average queue length of the requests that were issued to the device.';
  $io_r_await        ='The average time (in  milliseconds) for I/O requests issued to the device to be served.';
  $io_r_svctm        ='The average service time (in  milliseconds) for I/O requests that were issued to the device.';
  $io_r_util         ='Percentage of CPU time during which I/O requests were issued to the device (bandwidth utilization for the device). Device saturation occurs when this value is close to 100%.';
//
  $advice_fw         ='The order of the rules is important, the rule \'Redirect 312x\' It must be under of the segment rule of users';
//
  $float_alert_ok    ="<div class='float_alert'><div class='spinner'><div class='dot1'></div><div class='dot2'></div></div><div class='alrt_msg'>{$alert_change_ok}</div></div>";
  $float_alert_er    ="<div class='float_alert'><div class='spinner'><div class='dot1'></div><div class='dot2'></div></div><div class='alrt_msg'>{$alert_error}</div></div>";
//
  $str_update        ='Update';
  $str_available     ='available';
//
  $langs = array('Spanish' => $lng_es, 'English' => $lng_en, 'Portugues' => $lng_pt);
//
  include_once 'main/aboutIs.php';
  $cop ='Copyright &copy; '.$cop_year.' @ RaptorPanel '.$verwp.' &copy; All Rights Reserved';
  $wpv = 'RaptorPanel '.$verwp;
    
?>