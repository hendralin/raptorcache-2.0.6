<?php
//error_reporting(-1);

require 'bootstrap/autoload.php';

$app = new Start();
$app->callController();
