<?php 

session_start();
include_once "../main/auth.php";
require "../class/Database.php";

$db = Database::getInstance();
$db->getConnection();
//$sql = "SELECT DATE_FORMAT(d_down,'%d/%m/%Y') as d_down,COUNT(*) as files,sum(file_size) as size,sum(requested_size) as eco, sum(requested_size/file_size) as hits from raptor group by d_down DESC LIMIT 12";
$sql = "SELECT DATE_FORMAT(d_down,'%d/%m/%Y') as d_down, file_size FROM `raptor`.`http` group by d_down DESC LIMIT 12";
$result = $db->execute($sql);

$rows = array();
while($r = mysqli_fetch_array($result)) {
	$row[0] = $r['d_down'];
	$row[1] = $r['file_size'];
	array_push($rows,$row);
}

print json_encode($rows, JSON_NUMERIC_CHECK);

$db->disconnectDB();

?> 
