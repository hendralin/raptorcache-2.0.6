<?php 
session_start();
include_once "../main/auth.php";

if (!function_exists('dir_path')) {
    include '/usr/share/raptor/main/functions.php';
}

 ?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>TOP 10 SSL</title>
		<script type="text/javascript" src="<?php echo get_view_link(); ?>/js/rpengine.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
		    Highcharts.setOptions({
		        lang: {
		            numericSymbols: [' KiB', ' MiB', ' GiB', ' TiB', ' PiB', ' EiB']
		        }
	    	});
			var options = {
                colors: [
                   '#83be26', 
                   '#AA4643', 
                   '#89A54E', 
                   '#80699B', 
                   '#3D96AE', 
                   '#DB843D', 
                   '#92A8CD', 
                   '#A47D7C', 
                   '#B5CA92'
                ],				
				chart: {
                    type: 'areaspline',

	                renderTo: 'container',
	                plotBackgroundColor: null,
	                plotBorderWidth: null,
	                plotShadow: false
	            },
                credits: {
                    text: false
                },
	            title: {
	                text: false
	            },
                legend: {
                    enabled: false
                },
                exporting: {
                    enabled: false
                },

                xAxis: {
                	type: 'category',                	
            		tickPixelInterval: 60
        		},

                yAxis: {
                	min:0,
                	tickPixelInterval: 30,
            		title: {
                		text: false
            		},
            		plotLines: [{
	                	value: 0,
	                	width: 1,
	                	color: '#808080'
            		}]
        		},

	            tooltip: {
	                formatter: function() {
	                	  result = this.y;
  							if (this.y < 1024) { result = this.y + " bytes" }
  							else if (this.y < 1024*1024) { result = Highcharts.numberFormat(this.y / (1024), 2) + " KiB" }
  							else if (this.y < 1024*1024*1024) { result = Highcharts.numberFormat(this.y / (1024*1024), 2) + " MiB" }
  							else if (this.y < 1024*1024*1024*1024) { result = Highcharts.numberFormat(this.y / (1024*1024*1024), 2) + " GiB" }
  							else {result = Highcharts.numberFormat(this.y / (1024*1024*1024*1024), 2) + " TiB"}	

                        return this.point.name + " - " + result ;
	                    //return '<b>'+ this.point.name +'</b>';
	                }
	            },
	            plotOptions: {
	                line: {
	                    allowPointSelect: true,
	                    cursor: 'pointer',
	                    dataLabels: {
	                        enabled: true,
	                        color: '#000000',
	                        connectorColor: '#000000',
	                        formatter: function() {
	                            //return '<b>'+ this.point.name +'</b>: '+ Highcharts.numberFormat(this.percentage, 2) +' %';
	                            //return '<b>'+ this.point.name +'</b>';
	                        }
	                    }
	                }
	            },
	            series: [{
	                type: 'line',
	                name: 'Ahorro por fecha',
	                data: []
	            }]
	        }
	        
	        $.getJSON("data_ssl.php", function(json) {
				options.series[0].data = json;
	        	chart = new Highcharts.Chart(options);
	        });	        
	        
      	});   
		</script>
		<script src="<?php echo get_view_link(); ?>/js/highcharts.js"></script>
	<style>
	body{
		margin:0;
	}
	#container{
	background-color:#FFF;
	min-width: 400px; 
	max-width:1000px; 
	height: 220px; 
	margin: 0 auto;
	border-left: 1px solid #afafaf;
	border-right: 1px solid #afafaf;
	padding-top:16px;
}
	</style>	
	</head>
	<body>
		<div id="container"></div>
	</body>
</html>
