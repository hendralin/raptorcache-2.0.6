<?php

header("Content-type: text/json");

    $file = "/var/tmp/ethmon";
    require_once '../../main/settings.php';
    //shell_exec("sudo ifstat -i $eth_input_server -b 0.5 1 | grep -v $eth_input_server | grep -v Kbps | xargs > $file");
    
	//$r_file = file_get_contents($file);    
	$r_file = shell_exec("sudo ifstat -i $eth_input_server -b 1 1 | egrep -v 'eth|Kbps|enp' | xargs");
	$r_file = preg_replace('/\s\s+/', ' ', $r_file);
    $r_file = explode(" ", trim($r_file));
    $txeth = $r_file[0] * 1024;
    $rxeth = $r_file[1] * 1024;
	$x = time() * 1000;
	$y = $rxeth;
	$y2 = $txeth;

	//$y3 = $y + $y2;
	//$y3 = rand($y, $y2);

	//$ret = array($x, $y, $y2, $y3);
	$r_eth = array($x, $y, $y2);
	echo json_encode($r_eth);

?>