<!DOCTYPE html>
<html lang="en">

<head>
  <link rel="shortcut icon" href="images/favicon.png" />
  <meta charset="UTF-8">
  <title>RaptorCache - Test DB</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <style>
    body {
      background: #f1f1f1;
    }
    
    input[type="submit"] {
      -moz-box-shadow: inset 0px 1px 0px 0px #ffffff;
      -webkit-box-shadow: inset 0px 1px 0px 0px #ffffff;
      box-shadow: inset 0px 1px 0px 0px #ffffff;
      background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #ededed), color-stop(1, #dfdfdf));
      background: -moz-linear-gradient(top, #ededed 5%, #dfdfdf 100%);
      background: -webkit-linear-gradient(top, #ededed 5%, #dfdfdf 100%);
      background: -o-linear-gradient(top, #ededed 5%, #dfdfdf 100%);
      background: -ms-linear-gradient(top, #ededed 5%, #dfdfdf 100%);
      background: linear-gradient(to bottom, #ededed 5%, #dfdfdf 100%);
      filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#ededed', endColorstr='#dfdfdf', GradientType=0);
      background-color: #ededed;
      -moz-border-radius: 4px;
      -webkit-border-radius: 4px;
      border-radius: 4px;
      border: 1px solid #AAA;
      display: inline-block;
      cursor: pointer;
      color: #777777;
      font-family: Arial;
      font-size: 15px;
      font-weight: bold;
      padding: 6px 24px;
      text-decoration: none;
      text-shadow: 0px 1px 0px #ffffff;
    }
    
    input[type="submit"]:hover {
      background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #dfdfdf), color-stop(1, #ededed));
      background: -moz-linear-gradient(top, #dfdfdf 5%, #ededed 100%);
      background: -webkit-linear-gradient(top, #dfdfdf 5%, #ededed 100%);
      background: -o-linear-gradient(top, #dfdfdf 5%, #ededed 100%);
      background: -ms-linear-gradient(top, #dfdfdf 5%, #ededed 100%);
      background: linear-gradient(to bottom, #dfdfdf 5%, #ededed 100%);
      filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#dfdfdf', endColorstr='#ededed', GradientType=0);
      background-color: #dfdfdf;
    }
    
    input[type="submit"]:active {
      position: relative;
      top: 1px;
    }
    
    .test_db {
      -moz-box-shadow: 0px 0px 0px 2px #f7c5c0;
      -webkit-box-shadow: 0px 0px 0px 2px #f7c5c0;
      box-shadow: 0px 0px 0px 2px #f7c5c0;
      background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #fc8d83), color-stop(1, #e4685d));
      background: -moz-linear-gradient(top, #fc8d83 5%, #e4685d 100%);
      background: -webkit-linear-gradient(top, #fc8d83 5%, #e4685d 100%);
      background: -o-linear-gradient(top, #fc8d83 5%, #e4685d 100%);
      background: -ms-linear-gradient(top, #fc8d83 5%, #e4685d 100%);
      background: linear-gradient(to bottom, #fc8d83 5%, #e4685d 100%);
      filter: progid: DXImageTransform.Microsoft.gradient(startColorstr='#fc8d83', endColorstr='#e4685d', GradientType=0);
      background-color: #fc8d83;
      -moz-border-radius: 4px;
      -webkit-border-radius: 4px;
      border-radius: 4px;
      border: 1px solid #d83526;
      display: inline-block;
      color: #ffffff;
      font-family: Arial;
      font-size: 19px;
      padding: 12px 37px;
      margin-top: 4px;
      text-decoration: none;
      text-shadow: 0px 1px 0px #b23e35;
    }
  </style>
</head>

<body>
  <form action="test_db.php" method="POST" id="db">
    <input type="hidden" name="test" value="test">
    <input type="submit" name="submit" id="submit" value="Test">
  </form>

<?php
error_reporting(0);
include "main/functions.php";
if (isset($_POST["test"]) && isset($_POST["submit"])) {
    echo "<script>
    $(document).ready(function(){
        $('.test_db').fadeIn('slow');
    });
    </script>";
    echo "<div class='test_db' style='display:none;'>";
    $test = isset($_POST['test']) ? $_POST['test'] : NULL;
    if ($test == "test") 
        echo test_cnx_db();
    echo "</div>";
}
?>
</body>

</html>