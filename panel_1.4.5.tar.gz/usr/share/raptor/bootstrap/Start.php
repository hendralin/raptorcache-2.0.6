<?php

class Start 
{

	private $rolName;
	private $fileName;
	private $controller;

	public function __construct() 
	{
		$getUrl = isset($_GET['url']) ? $_GET['url'] : null ;

		if ($getUrl != "") {
			$pos = strpos($getUrl, '.req');
			if ($pos == true) { // request
				$url = rtrim($getUrl, '/');
				$url = explode('/', $url);
				require 'controllers/Request.php';
				$this->controller = new Request();
				$this->fileName = $url[1];
				$this->controller->getPage($this->fileName);				
				return;
			} else {
				require 'routes/web.php';
				$this->rolName = $rolName;
				$this->fileName = $fileName;
			}
		} else {
			$this->rolName = "index";
			$this->fileName = "";
		} 		
	}

	public function callController()
	{
		if ($this->rolName != "" && $this->fileName == "") {
			$file = 'controllers/' . ucfirst($this->rolName) . 'Controller.php';
		}
		else if ($this->rolName != "" && $this->fileName != "") {
			$file = 'controllers/' . ucfirst($this->fileName) . 'Controller.php';
		}		

		if (file_exists($file)) {
			require $file;
		} else {
			require 'controllers/ErrorController.php';
			$this->controller = new Error();
			return;
		}
		
		$this->rolName = ucfirst($this->rolName); // Admin

		if ($this->fileName != "") {
			$this->controller = new $this->fileName();	
		} else {
			/**
			 * [$this->controller description]
			 * @var [type] obj init index
			 */
			$this->controller = new $this->rolName;
			return;
		}
		
		if ($this->rolName == "Admin") {
			$this->controller->getPage($this->fileName);
		} else {
			header('location: /');
			exit();
		}		
	}

}