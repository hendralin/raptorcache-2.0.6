<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */

class Controller 
{

	public function __construct() 
	{
		include "main/functions.php";
		$this->view = new View();
	}

}