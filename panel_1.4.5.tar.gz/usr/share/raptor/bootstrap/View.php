<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

class View 
{
	private $value;
	private $option;

	public function render($name, $value = NULL, $option = NULL)
	{
		$this->value = $value;
		$this->option = $option;
		require 'public/' . $name . '.php'; 
	}

	public function renderRQ($name)
	{
		require $name . '.php'; 
	}

}