<?php 

namespace Raptor\Models;

class MemoryRam {

	private $output;

	public function __construct()
	{
		exec("free -m | grep -v \"buffers/cache\"", $this->output);
	}

	public function normValues($values)
	{
		$str = $values;
		$str = preg_replace("/\s(?=\s)/", "", $str);
	    $str = preg_replace("/[\n\r\t]/", " ", $str);
	    $arr_vals = explode(" ", $str);
		return $arr_vals;
	}

	public function getValuesRam() 
	{		
	    $str = trim($this->output[1]);
	    $ram = $this->normValues($str);
	     
	    $mem_tot = $ram[1]*1024*1024;

	    $mem_free = $ram[3]*1024*1024;
	    $mem_free_porc = round($ram[3] * 100 / $ram[1],0);

	    $mem_us = $ram[2]*1024*1024;
	    $mem_us_porc = round($ram[2] * 100 / $ram[1],0);

	    $mem_comp = $ram[4]*1024*1024;
	    $mem_comp_porc = " (".round($ram[4] * 100 / $ram[1],0)."%)";

	    $mem_buf = $ram[5]*1024*1024;
	    $mem_buf_porc = " (".round($ram[5] * 100 / $ram[1],0)."%)";

	    $mem_ch = $ram[6]*1024*1024;
	    $mem_ch_porc = "(".round($ram[6] * 100 / $ram[1],0)."%)"; 	

		$mem_values = array();		
		$mem_values[] = $mem_tot;
		$mem_values[] = $mem_free;
		$mem_values[] = $mem_free_porc;
		$mem_values[] = $mem_us;
		$mem_values[] = $mem_us_porc;
		$mem_values[] = $mem_comp;
		$mem_values[] = $mem_comp_porc;
		$mem_values[] = $mem_buf;
		$mem_values[] = $mem_buf_porc;
		$mem_values[] = $mem_ch;
		$mem_values[] = $mem_ch_porc;

	    return $mem_values;
	}

	public function getValuesSwap() 
	{
	    $str = trim($this->output[2]);	
		$swap = $this->normValues($str);

	    $swap_tot = $swap[1]*1024*1024;

	    $swap_us = $swap[2]*1024*1024;
	    $swap_us_porc = " (".round($swap[2] * 100 / $swap[1],0)."%)";

	    $swap_free = $swap[3]*1024*1024;
	    $swap_free_porc = " (".round($swap[3] * 100 / $swap[1],0)."%)";

		$swap_values = array();
		$swap_values[] = $swap_tot;
		$swap_values[] = $swap_us;
		$swap_values[] = $swap_us_porc;
		$swap_values[] = $swap_free;
		$swap_values[] = $swap_free_porc;

	    return $swap_values;
	}

 }

 ?>