<?php

namespace Raptor\Models;

class AddressList
{

    public function getListName()
    {
        $list = shell_exec("sudo ipset list | grep \"Name:\" | awk {'print $2'}");
        $arrline = explode("\n", $list);
        if (end($arrline) == NULL) {
            array_pop($arrline);
        }
        return $arrline;
    }

    public function getListItems($listName)
    {
        $list = shell_exec("sudo ipset list ".$listName." | egrep -v [a-zA-Z]");
        $arrline = explode("\n", $list);
        if (end($arrline) == NULL) {
            array_pop($arrline);
        }
        return $arrline;
    }
	    
}

?>