<?php 

$current_date = shell_exec('date +%Y-%m-%d');

$file = "/etc/raptor/fw.sh";
$search = "--dport 443 -j REDIRECT --to-port 3127";
$check = search_string($file, $search);
if (substr($check['string'], 0, 5) != "##-##") {

	$count_files =  $file_size = $eco_size = $hits = 0;

	$type = "ssl";
	$count_files = shell_exec("sudo squidclient -h 127.0.0.1 mgr:info | grep 'on-disk objects' | xargs |awk '{print $1}'");

/*	$file_size_total = shell_exec("sudo squidclient -h 127.0.0.1 mgr:storedir | grep 'Current Size:' | awk '{print $3}'");
	$file_size_total = intval($file_size) * 1024;*/

	$file_size = shell_exec("sudo squidclient -h 127.0.0.1 mgr:counters | grep 'server.all.kbytes_in' | awk '{print $3}'");
	$file_size = intval($file_size) ;

	$eco_size = shell_exec("sudo squidclient -h 127.0.0.1 mgr:counters | grep 'client_http.hit_kbytes_out' | awk '{print $3}'");
	$eco_size = intval($eco_size) ;

	$hits = shell_exec("sudo squidclient -h 127.0.0.1 mgr:counters | grep client_http.hits | awk '{print $3}'");

	$new_eco_size = $new_hits = $result = "";

	// update values if restart
	$sql = "SELECT date_ssl, file_size, eco_size, hits FROM `raptor`.`ssl` WHERE date_ssl = '".$current_date."'  LIMIT 1; ";
	$result   = $db->execute($sql);
	$todayDate = mysqli_num_rows($result);
	foreach ($result as $row) { 
		if ($row['file_size'] > $file_size) { 
			$file_size = $file_size + intval($row['file_size']);			
		}
		if ($row['eco_size'] > $eco_size) {
			$eco_size = $eco_size + intval($row['eco_size']);
		}		
		if ($row['hits'] > $hits) {
			$hits = $hits + intval($row['hits']);
		}
	}			

	$up = $ins = "";

	if ($todayDate > 0) {			
		// update count_files for current day
/*		$sql = "SELECT max(id_ssl),`count_files` FROM `raptor`.`ssl` WHERE id_ssl = ((select max(id_ssl) FROM `raptor`.`ssl`)-1); ";
		$result   = $db->execute($sql);
		foreach ($result as $row) {
			if ($row['count_files']) { 
				$count_files = $count_files - intval($row['count_files']);
			}
		}*/

		$up = "UPDATE `raptor`.`ssl` SET type = '".$type."', date_ssl = '".$current_date."', count_files = '".$count_files."', file_size = '".$file_size."', eco_size = '".$eco_size."', hits = '".$hits."' WHERE date_ssl ='".$current_date."'; ";
		if ($db->execute($up)) {
		//echo "_UPDATE_SSL";
		}
	} else {
		$ins = "INSERT INTO `raptor`.`ssl`(type, date_ssl, count_files, file_size, eco_size, hits) VALUES('".$type."', '".$current_date."', '".$count_files."', '".$file_size."','".$eco_size."','".$hits."'); ";
		if ($db->execute($ins)) {
		//echo "_INSERT_SSL";
		}		
	}
}

 ?>