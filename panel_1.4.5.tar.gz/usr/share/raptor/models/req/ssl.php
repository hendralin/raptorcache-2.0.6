<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.4
 */

require_once '/usr/share/raptor/class/Database.php';
require_once '/usr/share/raptor/main/functions.php';

$db = Database::getInstance();
$db->getConnection();

require '/usr/share/raptor/models/req/upHttps.php';
require '/usr/share/raptor/models/req/upHttp.php';


 ?>