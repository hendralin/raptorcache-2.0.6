<?php 

$current_date = shell_exec('date +%Y-%m-%d');

if ($current_date != "" || $current_date != NULL) {
	$hit_http = $files = $count_user = $sizes = $d_req = $eco = $threads = $percent = $result = "";
	$sql = "SELECT DATE_FORMAT(d_down,'%Y-%m-%d') as d_down, COUNT(*) as files, sum(file_size) as sizes, MAX(thread_usage) as threads FROM `raptor`.`raptor` WHERE d_down='".$current_date."'; ";
	$result = $db->execute($sql);
	foreach ($result as $row) {		
		$files      = $row['files'];
		$count_user = 0;		
		$sizes      = round($row['sizes'], 2);	
		$threads    = $row['threads'];					
	}

	$sql = "SELECT DATE_FORMAT(d_req,'%Y-%m-%d') as d_req, sum(requested_size/file_size) as hits, sum(requested_size) as eco, sum(requested_size)/sum(file_size) as percent FROM `raptor`.`raptor` WHERE d_req='".$current_date."'; ";
	$result = $db->execute($sql);
	foreach ($result as $row) {
		$d_req      = $row['d_req'];
		$hit_http   = round($row['hits'], 0);
		$eco        = $row['eco'];	
		$percent    = round(($row["percent"]) * 100, 2);
	}
	
	if ($d_req != "" || $d_req != null) {
		$sql = "SELECT d_down FROM `raptor`.`http` WHERE d_down ='".$current_date."' LIMIT 1; ";
		$result = $db->execute($sql);
		$num_rows = mysqli_num_rows($result);

		if ($num_rows > 0) {
			$up = "UPDATE `raptor`.`http` SET `hit_http` = '".$hit_http."', `file` = '".$files."', `file_size` = '".$sizes."',`d_req` = '".$d_req."', `requested_size` = '".$eco."', `thread_usage` = '".$threads."', `percent` = '".$percent."' WHERE d_down='".$current_date."';";
			if ($db->execute($up)) {
			//echo "_UPDATE_HTTP\n\n";
			}
		} else {
			$ins = "INSERT INTO `raptor`.`http` (`id`, `hit_http`, `file`, `count_user`, `file_size`, `d_down`, `d_req`, `requested_size`, `thread_usage`, `percent`) VALUES 
											(NULL, '".$hit_http."', '".$files."', '".$count_user."', '".$sizes."', '".$current_date."', '".$d_req."', '".$eco."', '".$threads."', '".$percent."');";
			if ($db->execute($ins)) {
			//echo "_INSERT_HTTP\n\n";
			}		
		}
	}	
}	
	echo "DONE\n";
$db->disconnectDB();

 ?>