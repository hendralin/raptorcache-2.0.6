<?php 

namespace Raptor\Models;

abstract class File 
{
  
	protected $fileLocation;
	protected $content;

	public function __construct($fileLocation = NULL)
	{
		$this->fileLocation = $fileLocation;		
	}

	public function getContent()
	{
		$this->content = file_get_contents($this->fileLocation);
		return $this->content;
	}

}

 ?>