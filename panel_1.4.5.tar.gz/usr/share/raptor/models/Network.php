<?php 

namespace Raptor\Models;

class Network 
{

	private $file_dns = "/etc/resolv.conf";
	private $file_ip_cache = "/etc/squid3/squid.conf";

	private $interfacePrefix;
	private $file_interface = "/etc/network/interfaces";
	private $arr_content_interface = array();	

	public function __construct()
	{
		$this->interfacePrefix = shell_exec("sudo cat /etc/network/interfaces | grep iface | grep static | xargs | awk {'print $2'}");
		$this->interfacePrefix = substr($this->interfacePrefix, 0, 3);
		$this->arr_content_interface = file($this->file_interface);
	}

	public function list_interface_name() 
	{
		$eth = shell_exec("sudo ls -A /sys/class/net | tr -d ' '");	
		//$eth = preg_replace("[\n|\r|\n\r]", '-', $eth);
		$arrEth = explode("\n", $eth);
		return $arrEth;
	}

	public function is_cidr() 
	{
		foreach ($this->arr_content_interface as $value) {
			if ( strstr($value, "address") && strstr($value, "/") ) {
				return true;
			}
		}
		return false;
	}

	public function get_ip_address() 
	{
		$interfaces = array();
		$pos = 0;
		$count = 7;
		if ( $this->is_cidr() ) 
			$count = 4;
		foreach ($this->arr_content_interface as $linea) {			
			if ( strstr($linea , "allow-hotplug {$this->interfacePrefix}") || strstr($linea , "auto {$this->interfacePrefix}") ) {
				$arr_eth = array();	
				for ($i=0; $i < $count; $i++) { 
					$value = preg_replace('/\s\s+/', ' ', $this->arr_content_interface[$pos + $i]);
					$value = explode(' ', $value);
					$arr_eth[$value[0]] = $value[1];	
				}
				$interfaces[] = $arr_eth; 
			}
			$pos++;
		}
		return $interfaces;
	}

	public function show_interfaces() 
	{
	    $eth = shell_exec("sudo ifconfig -a -s | grep '". $this->interfacePrefix ."[a-zA-Z0-9]' | awk {'print $1\" \"$2\" \"$3\" \"$4\" \"$5\" \"$6\" \"$7\" \"$8\" \"$9\" \"$10\" \"$11\" \"$12'}");
	    $eth = explode("\n", $eth);
		$count_eth = array();
	    for ($i = 0; $i < count($eth); $i++) { 
			if ($eth[$i] != "" || $eth[$i] != NULL) { 	
				$values_eth = array();			
				$dts_eth = trim($eth[$i]);
				$dts_eth = explode(" ", $dts_eth);
				for ($j=0; $j < 11; $j++) { 					
					$values_eth[] = $dts_eth[$j];
				}
				$count_eth[] = $values_eth;
			}						
	    }
		return $count_eth;
	}

	public function showNameInterfaces()
	{
		$eths = shell_exec("sudo ifconfig -a -s | grep '". $this->interfacePrefix ."[a-zA-Z0-9]' | awk {'print $1\" \"$2\" \"$3\" \"$4\" \"$5\" \"$6\" \"$7\" \"$8\" \"$9\" \"$10\" \"$11\" \"$12'}");
		$eths = explode("\n", $eths);
		for ($i=0; $i < count($eths); $i++) {     
			$iface = explode(" ", trim($eths[$i]));
			if ($iface[0] != "") {
			  echo "<option value='".$iface[0]."'>".$iface[0]."</option>";
			}    
		} 		
	}

	public function getIpCache()
	{
		$content = file_get_contents($this->file_ip_cache);
		$file_arr_ln = explode("\n", $content);		
		$pos = 0;
		foreach( $file_arr_ln as $linea ) {    
			if ( strstr($linea, "cache_peer ") ) {
				$ip_cache = explode(" ", $linea);		
				return $ip_cache[1];			  
			} 
			$pos++;
		}
	}

	public function putIpCache($string_search, $ip_r, $last_string) {
		$content = file_get_contents($this->file_ip_cache);
		$arr_lines = explode("\n", $content);	
		$pos = 0;
		foreach($arr_lines as $linea) { 
			if (strstr($linea, $string_search)){
			 $num_row = $pos;        
			}
			$pos++;
		} 
		$line_string = $arr_lines[$num_row];
		$line_string = explode(" ", $line_string);
		$new_line = $line_string[0]." ".$ip_r." ".$last_string; 		
		file_put_contents($this->file_ip_cache, str_replace($arr_lines[$num_row], $new_line, $content));			
	}
	
	public function show_dns_address() {
		$fileln = file($this->file_dns);
		echo "<table class=\"sortable\" cellspacing='0' style=\"border-radius:0 0 3px 3px;width:300px;margin-bottom: 0;\">";
		echo "<tr>";
		echo "<th style='border-right:none;'>Nameservers</th>";
		echo "</tr>";
		$posdns = 0;
		foreach($fileln as $line_dns) {        
			if (strstr($line_dns, "nameserver")) {
				$row_dns  = $posdns + 1;  
				$content  = file_get_contents($this->file_dns);
				$l_dns    = explode("\n", $content);
				$l_dns    = $l_dns[($row_dns - 1)];
				$ip_dns   = explode(" ", $l_dns);
				$ip_dns   = $ip_dns[1];
				if (trim($ip_dns) != "127.0.0.1")
					echo "<tr class='row'><td>".$ip_dns."</td></tr>";
			}
			$posdns++;
		}
		echo "</table>";  
	}	

	public function isDNScache()
	{
		$line_cache_dns = search_string($this->file_dns, "127.0.0.1");
		if (substr($line_cache_dns['string'], 0, 1) == "#") {
			return false;
		} else {
			return true;
		}
	}

}


 ?>