<?php 
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

namespace Raptor\Models;

class Statistic
{
	
	public $objDb;
	private $resultTotal;
	
	public function __construct($objConn)
	{		
		$this->objDb = $objConn;		
	}
	
	private function get_total_http()
	{
		$sql = "SELECT domain,COUNT(*) as files,sum(file_size) as size,sum(requested_size) as eco, sum(requested_size/file_size) as hits from `raptor`.`raptor` group by domain";

		$this->resultTotal = $this->objDb->execute($sql);

		foreach ($this->resultTotal as $valor) {
			//$percent      += round(($valor["eco"]/$valor["size"])*100,2);
			$totaleconomy += $valor["eco"];
			$totalhits    += $valor["hits"];
			$totalcount   += $valor["files"];
			$totalsize    += $valor["size"];	

		}
		$totalcount   = number_format($totalcount, 0, "",".");
		$totalsize    = sizeFormat($totalsize);
		$totaleconomy = sizeFormat($totaleconomy);
		$totalhits    = number_format($totalhits, 0, "",".");
		$percent      = number_format(round(($totaleconomy/$totalsize)*100,3), 2, ",",".");

		$total_http = array("files" => $totalcount, "size" => $totalsize, "eco" => $totaleconomy, "hits" => $totalhits, "percent" => $percent);
		return $total_http;
	}
	public function show_total_http()
	{
		$show_http = $this->get_total_http();
		$http = "
			<tr>
				<td>Total</td>
				<td>{$show_http['files']}</td>
				<td>{$show_http['size']}</td>
				<td>{$show_http['eco']}</td>
				<td>{$show_http['hits']}</td>
				<td style='text-align:right;width:70px;'>{$show_http['percent']} %</td>
			</tr>";
		return $http;
	}

	public function get_total_ssl()
	{
		$sql = "SELECT type,sum(count_files) as files,sum(file_size) as size,sum(eco_size) as eco, sum(hits) as hits from `raptor`.`ssl` group by type";
		//$sql = "SELECT * from `raptor`.`ssl` ORDER BY id_ssl DESC LIMIT 1";

		$this->resultTotal = $this->objDb->execute($sql);

		foreach ($this->resultTotal as $valor) {
			$totaleconomy += $valor["eco"];
			$totalhits    += $valor["hits"];
			$totalcount   += $valor["files"];
			$totalsize    += $valor["size"];	
		}
		$totalcount   = number_format($totalcount, 0, "",".");
		$totalsize    = sizeFormat($totalsize);
		$totaleconomy = sizeFormat($totaleconomy);
		$totalhits    = number_format($totalhits, 0, "",".");
		$percent      = number_format(round(($totaleconomy/$totalsize)*100,3), 2, ",",".");

		$total_https = array("files" => $totalcount, "size" => $totalsize, "eco" => $totaleconomy, "hits" => $totalhits, "percent" => $percent);
		return $total_https;
	}
	public function show_total_ssl()
	{
		$show_ssl = $this->get_total_ssl();
		$https = "
			<tr>
				<td>Total</td>
				<td>{$show_ssl['files']}</td>
				<td>{$show_ssl['size']}</td>
				<td>{$show_ssl['eco']}</td>
				<td>{$show_ssl['hits']}</td>
				<td style='text-align:right;width:70px;'>{$show_ssl['percent']} %</td>
			</tr>";
		return $https;
	}
	
}





 ?>