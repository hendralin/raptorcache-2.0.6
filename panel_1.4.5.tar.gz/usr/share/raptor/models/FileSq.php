<?php 

namespace Raptor\Models;

use Raptor\Models\File;

class FileSq extends File
{

	public $dns1;
	public $dns2;

	public function __construct($fileLocation)
	{
		parent::__construct($fileLocation);
		$location_url = explode("/", $_SERVER['REQUEST_URI']);
		$this->routeLocation = end($location_url);	
		$this->content = explode("\n", $this->getContent());
	}

	public function get_dns_nameservers()
	{		
		foreach ($this->content as $value) {
			if (strstr($value, "dns_nameservers")) {
				$dir_dns_nameservers = explode(' ', $value);
				$this->dns1 = $dir_dns_nameservers[1];
				$this->dns2 = $dir_dns_nameservers[2];
			}
		}					
	}

	public function show_localnet() 
	{
		$tbl = "<table class=\"sortable\" cellspacing='0' style=\"border-radius:3px;width:372px;margin-left:10px;margin-bottom:0;\">";
		$tbl .= "<tr>";
		$tbl .= "<th style='border-right:none;'>ACL Localnet</th><th style='border-right:none;'></th>";
		$tbl .= "</tr>";
		$pos = 0;
		foreach( $this->content as $line_search ) {        
			if (strstr($line_search, 'acl localnet')) {
				$value = explode(" ", $line_search);
				$value = $value[3];
				$delete_line = "<a class='del_regx' href='sqconf.req?delete_line={$value}'>X</a>";
				$tbl .= "<tr class='row'><td>".$value."</td><td style='text-align:right;'>".$delete_line."</td></tr>";
			}
			$pos++;
		}
		$tbl .= "</table>";  
		return $tbl;
	}

	public function getNumRow($directive)
	{	
		$pos = 0;
		foreach($this->content as $linea) {	        
			if (strstr($linea, $directive)) {
			 $row = $pos + 1;       
			 return $row;
			}
		    $pos++;
		}
	}

	public function setValueLocalnet($acl_localnet)
	{
		$pos = 0;
		foreach($this->content as $linea) {	        
			if (strstr($linea, "acl localnet")) {
				$row = $pos;       
			}
		    $pos++;
		}
		$new_line_regex = $this->content[($row)]."\n"."acl localnet src ".$acl_localnet;
		file_put_contents($this->fileLocation, str_replace($this->content[$row], $new_line_regex, $this->getContent()));		
	}

	public function deleteValueLocalnet($acl_localnet)
	{		
		$pos = 0;
		foreach ( $this->content as $linea ) {	        
			if ( strstr($linea, $acl_localnet) ) {
				$row = $pos;        
			}
			$pos++;
		}
		$new_line_regex = "";
		file_put_contents($this->fileLocation, str_replace($this->content[$row]."\n", $new_line_regex, $this->getContent()));		
	}

	public function setValueDNS($dns1, $dns2)
	{			
		$pos = 0;
		foreach ($this->content as $linea) {                
			if (strstr($linea, "dns_nameservers"))
				$row = $pos;	
			$pos++;
		}
		$new_dns_nameservers = "dns_nameservers ".$dns1." ".$dns2;
		file_put_contents($this->fileLocation, str_replace($this->content[$row], $new_dns_nameservers, $this->getContent()));		
	}

	public function setValueDirective($directiveName, $directiveNewValue)
	{			
		$pos = 0;
		foreach ($this->content as $linea) {                
			if (strstr($linea, $directiveName))
				$row = $pos;	
			$pos++;
		}
		$newDirective = $directiveName." ".$directiveNewValue;
		file_put_contents($this->fileLocation, str_replace($this->content[$row], $newDirective, $this->getContent()));		
	}	

	public function __call($name, $arguments)
	{
		$this->get_dns_nameservers();
		$no_method = true;

		$method_name = substr($name, 0, 3);

		if ($method_name == 'get') {
			$no_method = false;
			$real_name = substr(strtolower($name), 4);
			return $this->$real_name;
		}

		if ($no_method) {
			throw Exception("Method {$name} no found");			
		}

	}	

}

 ?>