<?php

namespace Raptor\Models;

use Raptor\Models\FileRp;

class StoreHTTPS extends FileRp
{
	public function __construct($fileLocation)
	{
		parent::__construct($fileLocation);
		$location_url = explode("/", $_SERVER['REQUEST_URI']);
		$this->routeLocation = end($location_url);	
	}

	public function showRules() 
	{		
		$arrline = $this->getContent();
		$arrline = explode("\n", $arrline);
		$tbl = "<table class='sortable' cellspacing='0'>"; 
	    $tbl .= "<tr>";
	    $tbl .= "<th>&nbsp;</th>";
	    $tbl .= "<th>Name</th>";
	    $tbl .= "<th>Regex</th>";
	    $tbl .= "<th style='border-right:none;'></th>";
	    $tbl .= "<th style='border-right:none;'></th>";
	    $tbl .= "<th style='border-right:none;'></th>";
	    $tbl .= "<th style='border-right:none;padding: 2px 4px;'></th>";
	    $tbl .= "</tr>";
		$total_items = 0; $item = 1;
		for ($i=0; $i < count($arrline); $i++) { 
			if ( strpos($arrline[$i], "#name#") !== FALSE ) {				
				$total_items++;
			}
		}		
		for ($i=0; $i < count($arrline); $i++) { 
			if ( strpos($arrline[$i], "#name") !== FALSE ) {
				$line = explode("#name#",$arrline[$i]);
				$regex = $line[0];										
				$name = $line[1];
				$up_rule = ($item > 1) ? $this->move_up_rule($name) : ''; 
				$down_rule = ($item == $total_items) ? '' : $this->move_down_rule($name);			
				if (substr($arrline[$i], 0, 5) == "##-##") {					
					$this->rule = substr($regex, 5);
					if (substr($regex, 5, 5) == "elsif") 					
						$regex = $this->formatRegex($this->rule);											
					$tbl .= "<tr class='row'>";
					$tbl .= "<td style='color:#AAA;width:40px;'>".$this->state_rule($name, "OFF")."</td>";
					$tbl .= "<td style='color:#AAA;text-align:left;'>".$name."</td>";
					$tbl .= "<td style='color:#AAA;text-align:left;width:700px;'>".$regex."</td>";	
					$tbl .= "<td style='padding-right:0'>".$up_rule."</td>";
					$tbl .= "<td style='padding-right:0'>".$down_rule."</td>";
					$tbl .= "<td style='padding-right:0'>".$this->edit_rule($i)."</td>";
					$tbl .= "<td style='color:#AAA;padding: 2px 4px;'>".$this->delete_rule($name, $regex)."</td>";
					$tbl .= "</tr>";				
				} else {
					if (substr($arrline[$i], 0, 1) == "#") 
						continue;
					if (substr($regex, 0, 5) == "elsif") 						
						$regex = $this->formatRegex($regex);							
					$tbl .= "<tr class='row'>";
					$tbl .= "<td style='width:40px;'>".$this->state_rule($name, "ON")."</td>";
					$tbl .= "<td style='text-align:left;'>".$name."</td>";
					$tbl .= "<td style='text-align:left;width:700px;'>".$regex."</td>";			
					$tbl .= "<td style='padding-right:0'>".$up_rule."</td>";
					$tbl .= "<td style='padding-right:0'>".$down_rule."</td>";					
					$tbl .= "<td style='padding-right:0'>".$this->edit_rule($i)."</td>";					
					$tbl .= "<td style='padding: 2px 4px;'>".$this->delete_rule($name, $regex)."</td>";
					$tbl .= "</tr>";				
				}
				$item++;				
			}
		}
		$tbl .= "<table class='t_footer'><tr><td colspan='7'>{$total_items}&nbsp;" . (($total_items > 1) ? $txt='items' : $txt='item') . "</td></tr></table>";
		$tbl .= "</table>";
		return $tbl;
	} 

	public function edit_rule($i)
	{
		return "<a class='editRegexPl' onclick='window.dat=".$i."'><span class='icon-pencil-square-o'></span></a>";
	}    	

	private function formatRegex($regex)
	{
		$format = substr($regex, 14);
		$format = explode("/){", $format);
		return $format[0];
	}

	public function insertRegex($file, $name, $regex)
	{
		$existNameRule = false;
		$content = file_get_contents($file);
		$arr_content   = explode("\n", $content);	
		$pos = 0;
		foreach ($arr_content as $line) {	 
			$ruleNameTmp = explode("#name#", $line);
			$ruleNameTmp = trim($ruleNameTmp[1]);
			if ( strpos($line, "$out=\"ERR\"" ) !== FALSE ) {
				$row = $pos;
			}		
			if ( $ruleNameTmp == $name ) {
				$existNameRule = true;
			}
			$pos++;
		}
		if ( $existNameRule == true && $row != "") {
			$suffix = time();
			$regex = 'elsif($url=~m/' . $regex . '/){$out="OK store-id=http://' . $name . "." . substr($suffix, -3) . '.squid.internal/" . $1 . "." . $2;}';
			$new_rule = $regex . " #name#" . $name . "." . substr($suffix, -3) . "\nelse{\$out=\"ERR\";}";				
			file_put_contents($file, str_replace($arr_content[$row], $new_rule, $content));						
		}			
		else if ( $existNameRule == false && $row != "" ) {
			$regex = 'elsif($url=~m/' . $regex . '/){$out="OK store-id=http://' . $name . '.squid.internal/" . $1 . "." . $2;}';
			$new_rule = $regex . " #name#" . $name . "\nelse{\$out=\"ERR\";}";
			file_put_contents($file, str_replace($arr_content[$row], $new_rule, $content));
		}		
	}	

	public function editRegex($file, $idregex, $name, $regex) 
	{
		$content   = file_get_contents($file);
		$row_regex = explode("\n", $content);		
		$regex = 'elsif($url=~m/' . $regex . '/){$out="OK store-id=http://' . $name . '.squid.internal/" . $1 . "." . $2;}';
		$new_rule = $regex . " #name#" . $name; 
		file_put_contents($file, str_replace($row_regex[$idregex], $new_rule, $content));
	}	

}


?>