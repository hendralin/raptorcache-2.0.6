<?php

namespace Raptor\Models;

Class HardDisk
{
    private $countDisk;
    private $listDevDisk;
    
    private $nameGrepDisk;
    
    public $arr_dev_disk;
    
    public function __construct()
    {
        //$this->nameGrepDisk = exec("sudo fdisk -l | grep /dev/ | grep bytes | head -n1 | awk {'print $1'}");
        $this->listDevDisk  = shell_exec("sudo fdisk -l /dev/sd? | grep -Ee '/dev/sd[a-z]:' | grep 'iB' | awk '{print $2}' | sed -e 's/://g'");
        $this->arr_dev_disk = explode("\n", $this->listDevDisk);
    }
    
    public function getCountDisk()
    {
        $this->countDisk = shell_exec("sudo fdisk -l | grep -Ee '/dev/sd[a-z]:' | grep 'iB' | grep -v '/dev/dm-0' | grep -v '/dev/mapper/' | wc -l");
        return $this->countDisk;
    }
    
    public function getIostat($sdx)
    {
        $iostat = shell_exec("iostat -x -d -k 1 2 {$sdx} | tail -2 | grep \"{$sdx}\" | xargs");
        $iostat = explode(" ", trim($iostat));
        $iw = number_format($iostat[9], 1, ".", "");
        if ($iw > 100)
            $iw = 100;
        if ($iostat != "") {
            $io = array();
            $io[] = $iostat[3];
            $io[] = $iostat[5];
            $io[] = $iostat[4];
            $io[] = $iostat[6];
            $io[] = $iw;
        }
        return $io;
    }
    
    public function getTempHd($sdx)
    {
        (int)$temp = shell_exec("cat /dev/shm/" . trim($sdx) . "-A | grep Temperature | grep Temperature_Celsius | awk '{print $10}'");
        $t_sdx = "/dev/".$sdx;
        if ($temp == "") {
            shell_exec("sudo smartctl -A " . trim($t_sdx) . " > /dev/shm/".$sdx."-A");
        }
        if ($temp != "") {
            $temp = substr($temp,0,2);
            if ($temp <= 40) {
                $temp = "<span style='color:#5daf48'>".$temp." &deg;C</span>";
            }
            else if ($temp > 40 && $temp <= 60) {
                $temp = "<span style='color:orange'>".$temp." &deg;C</span>";
            }
            else if ($temp > 60) {
                $temp = "<span style='color:red'>".$temp." &deg;C</span>";
            }
        } else {
            $temp = "<span style='color:#777'>No support</span>";
        }
        return $temp;
    }
    
    public function getLatencyHd($sdx)
    {
        $t_sdx = "/dev/".$sdx;
        $iop = shell_exec("sudo ioping -c 1 -s 1k " . trim($t_sdx) . " | grep time");
        $iop = explode("time=", $iop);
		if (strstr($iop[1], 'warmup')) {
			$iop = explode(' ', $iop[1]);
			$iop = $iop[0] . $iop[1];
			return $iop;
		}
        $l_ioping = $iop[1];
        return $l_ioping;
    }
    
    public function getSpaceHd($sdx)
    {
        $list_details_space = shell_exec("df -h | grep " . $sdx . " |  sed 's/ /\\n/g' | grep -Ee '[a-zA-Z0-9]' ");
        $arr_disk_items = explode("\n", $list_details_space);
        return $arr_disk_items;
    }
    
    public function getListDevDisk()
    {
        return $this->arr_dev_disk;
    }
    
    public function getSmartool($sdx)
    {
        $t_sdx = "";
        $t_sdx = "/dev/".$sdx;
        shell_exec("sudo smartctl -i ".trim($t_sdx)." > /dev/shm/".$sdx."-i");
        shell_exec("sudo smartctl -A ".trim($t_sdx)." > /dev/shm/".$sdx."-A");
        
        $file = "/dev/shm/".trim($sdx)."-i";
        $model = getValueHd($file, "Model Family:", ":");
        $device = getValueHd($file, "Device Model:", ":");
        $smart = getValueHd($file, "SMART support is:", ":");
        $smart = trim($smart[1]);
        if ($smart == "Enabled") {
            $smart='<span style="color:#5daf48">Enabled</span>';
        }else{
            $smart='<span style="color:#fb4949">Disabled</span>';
        }
        
        $capacity_all = getValueHd($file, "User Capacity:", ":");
        $capacity = explode("bytes",$capacity_all[1]);
        $hdsmd = str_replace(',', '', $capacity[0]);
        $hdsmd = sizeFormat($hdsmd);
        
        $file_a = "/dev/shm/".trim($sdx)."-A";
        $power_on = getValueHd($file_a, "Power_On_Hours", " ");
        $uncorrectable = getValueHd($file_a, "Offline_Uncorrectable", " ");
        $reallocated = getValueHd($file_a, "Reallocated_Sector_Ct", " ");
        $seek_error = getValueHd($file_a, "Seek_Error_Rate", " ");
        
        $smartool = array();
        $smartool[] = $model[1];
        $smartool[] = $device[1];
        $smartool[] = $hdsmd;
        $smartool[] = $smart;
        $smartool[] = $power_on;
        $smartool[] = $uncorrectable;
        $smartool[] = $reallocated;
        $smartool[] = $seek_error;
        
        return $smartool;
    }
    
    public function getMountHd($sdx)
    {
        $disk_items = $this->getSpaceHd($sdx);
        if ($this->getCountDisk() >= 1) {
            if ('sda' == $sdx) {
                $cache_num = "System";
            } else {
                if ($disk_items[5] == "" || $disk_items[5] == NULL) {
                    $cache_num = "No Mount";
                } else {
                    $cache_num = explode("/usr/local/raptor/", $disk_items[5]);
                    $cache_num = $cache_num[1];
                }
            }
        }
        return $cache_num;
    }
    
    public function getUuid($sdx)
    {
        $dev_disk = "/dev/".$sdx;
        $uuid = shell_exec("sudo blkid " . trim($dev_disk) . " | awk '{print $2}' | tr -d '\"'");
        if ($uuid == "")
        $uuid = shell_exec("sudo blkid | grep " . trim($dev_disk) . " | grep -v 'swap' | awk '{print $2}' | tr -d '\"'");
        return $uuid;
    }
    
    public function formatDisk($devSdx)
    {
        $disk_format = $devSdx;
        if ($disk_format != "") {
            shell_exec("sudo dd if=/dev/zero of=" . $disk_format . " bs=1M count=1");
            shell_exec("sudo mkfs.ext4 -F -v -m .1 -b 4096 " . $disk_format . "");
            return 1;
        } else {
            return 0;
        }
        
    }
    
}