<?php 

namespace Raptor\Models;

class User 
{

	public $objDb;

	public function __construct($db)
	{		
		$this->objDb = $db;	
	}

	public function getArrUser() 
	{
		$sql = "SELECT * FROM user";		
		$this->result = $this->objDb->execute($sql);
		return $this->result;
	}		
}

 ?>