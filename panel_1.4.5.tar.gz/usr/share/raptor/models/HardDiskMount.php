<?php

namespace Raptor\Models;

class HardDiskMount extends HardDisk
{
    
    private $fileConfig = '/etc/fstab';
	private $arrFileConfig = array();
    private $fileRpConfig = '/etc/raptor/raptor.conf';
    private $rpConfigContent = "";	
    
    public function __construct()
    {
        parent::__construct();
        $content = file_get_contents($this->fileConfig);
		$this->arrFileConfig = explode("\n", $content);		
		$this->rpConfigContent = file_get_contents($this->fileRpConfig);		
    }
    
    public function getListCacheDir()
    {
        $cacheDirMount = array();
        foreach($this->arrFileConfig as $line) {
            if ( strstr($line, 'raptor') ) {
				$line = preg_replace('/\s\s+/', ' ', $line);
                $checkCacheDir = explode(" ", ltrim($line));
                $checkCacheDir = trim($checkCacheDir[1]);
                $cacheDirMount[] = intval(substr($checkCacheDir, 23));
            }
        }
        asort($cacheDirMount);
        $cacheDirMount = array_values($cacheDirMount);
        return $cacheDirMount;
    }
    
    public function getNewCacheDir()
    {
		$listCacheDir = $this->getListCacheDir();
        if (count($listCacheDir) > 0) {            
            $newCacheDir = '/usr/local/raptor/cache' . (end($listCacheDir) + 1);
            for ( $i = 0; $i < count($listCacheDir); $i++ ) {
                if ($listCacheDir[$i] != ($i + 1)) {
                    $newCacheDir = '/usr/local/raptor/cache' . ($i + 1);
                    break;
				}
			}			
		} else {
			$newCacheDir = '/usr/local/raptor/cache1';
		}
		return $newCacheDir;
	}

	public function getDirCacheMount($devDisk)
	{
		$cacheDir = "";
		foreach($this->arrFileConfig as $line) {
			if (strpos($line, $devDisk) !== FALSE) {
				$cacheDir = explode(" ", ltrim($line));
				$cacheDir = trim($cacheDir[1]);
				break;
			}
		}
		return $cacheDir;
	}

	public function addValueConfig($mount_dir)
	{
		$new_mount = $mount_dir;
		$arrFileConfig = explode("\n", $this->rpConfigContent);
		$existDirective = false; $existCache = false;
		$pos = 0;
		foreach( $arrFileConfig as $line ) {			
			if ( strpos($line, "CACHE_DIR") !== FALSE ) {	
				$row = $pos;	
				$existDirective = true;
				$line = preg_replace('/\s\s+/', ' ', $line);
				$directive = explode(" ", $line);								
				for ($i=0; $i < count($directive); $i++) { 
					if ($directive[$i] == $new_mount) {
						$existCache = true;
					}								
				}				
			}
			$pos++;
		}		
		if (!$existCache) {
			$update = $arrFileConfig[$row] . "\n" . "CACHE_DIR " . $new_mount;
			file_put_contents($this->fileRpConfig, str_replace($arrFileConfig[$row], $update, $this->rpConfigContent));
		}		
		else if (!$existDirective) {
			$add = "CACHE_DIR " . $new_mount;
			file_put_contents($this->fileRpConfig, $add."\n", FILE_APPEND | LOCK_EX);
		}
	}

	public function delValueConfig($mount_dir)
	{
		$arrFileConfig = explode("\n", $this->rpConfigContent);
		$pos = 0;
		foreach( $arrFileConfig as $line ) {
			if ( strpos($line, "CACHE_DIR") !== FALSE ) {					
				$line = preg_replace('/\s\s+/', ' ', $line);
				$directive = explode(" ", $line);				
				for ($i=0; $i < count($directive); $i++) { 
					if ($directive[$i] == $mount_dir && $directive[$i] != "/usr/local/raptor/cache1") {
						file_put_contents($this->fileRpConfig, str_replace($arrFileConfig[$pos]."\n", "", $this->rpConfigContent));					
					}								
				}				
			}
			$pos++;
		}
	}

	public function SetMountDisk($disk_mount)
	{
		if ($this->getDirCacheMount($disk_mount) == "") {
			$new_cache_dir = $this->getNewCacheDir();
			$add = $disk_mount . " " . $new_cache_dir . "  ext4  noatime,async,nosuid  0  0\n";
			file_put_contents($this->fileConfig, $add, FILE_APPEND | LOCK_EX);
			if (!file_exists($new_cache_dir))
				shell_exec("sudo mkdir " . $new_cache_dir . "");
			shell_exec("sudo mount " . $new_cache_dir . "");
			$this->addValueConfig($new_cache_dir);
			shell_exec("sudo /etc/init.d/raptor restart");
			return 1;
		} else {
			return 0;
		}
	}

	public function setUmountDisk($disk_mount)
	{
		$disk_umount = $this->getDirCacheMount($disk_mount);
		if ($disk_umount != "") {
			$content = file_get_contents($this->fileConfig);
			foreach( $this->arrFileConfig as $line ) {
				if ( strpos($line, $disk_umount) !== FALSE ) {
					file_put_contents($this->fileConfig, str_replace($line."\n", "", $content));
					shell_exec("sudo umount " . $disk_umount . "");
					$this->delValueConfig($disk_umount);
					shell_exec("sudo /etc/init.d/raptor restart");					
					return 1;
				}
			}
		} else {
			return 0;
		}
	}	

}


?>