<?php
/**
*
* @package Main Raptorcache
* @since 1.0
*/

namespace Raptor\Models;

class SyState
{

	public function get_distribution_name()
	{
		$vdist = shell_exec("lsb_release -i | awk '{print $3}'");
		if (trim($vdist) == 'Debian') {
			return $vdist;
		}
		else if (trim($vidst) == 'Ubuntu') {
			return $vdist;
		}
		else {
			return "other" . " " . $vdist ;
		}
	}

	public function get_version_debian()
	{
		$v_deb = shell_exec("lsb_release -c | awk {'print $2'}");
		return $v_deb;
	}

    public function stat_cache($portr)
    {
        $iprp = "localhost";
        $nic = "";
        if ( !$nic = @fsockopen($iprp, $portr, $errno, $errstr, 1) ) {
            $r = "<span style=\"color:rgb(252, 69, 69);\">Offline</span>";
        } else {
            if ($nic) {
                $r = "<span style=\"color:#5daf48\">Activo</span>";
                fclose($nic);
            }
        }
        return $r;
    }
    
    public function version_rp()
    {
        $vrp = '';
        $vrp = shell_exec("sudo /usr/sbin/raptor -v | awk '{print $3}' | head -1");
        return "<span style='color:#2ec2d0'>v.".$vrp."</span>";
    }
    
    public function version_sq()
    {
        $vsq = '';
        $vsq = shell_exec("/usr/sbin/squid3 -v | awk '{print $4}' | head -1");
        return "<span style='color:#2ec2d0'>v.".$vsq."</>";
    }
    
    public function uptime()
    {
        $uptime	= ''; $uptimeSecs = ''; $staticUptime = '';
        $uptime = shell_exec("head -1 /proc/uptime");
        $uptime = explode(" ",$uptime);
        $uptimeSecs = $uptime[0];
        $staticUptime = format_time($uptimeSecs);
		if ($staticUptime == '')
			$staticUptime = '0m';
        return $staticUptime;
    }
    
    public function cpu_temp()
    {
        $ln = ''; $temp = '';
        $ln = shell_exec("sensors | grep -E 'CPU Temperature|temp1' >/dev/null 2>&1");
        if (trim($ln) != "") {
            $tp = explode(" ", $ln);
            for ($i=0; $i < sizeof($tp); $i++) {
                if (strpos($tp[$i], "+") !== false) {
                    $cp = str_replace("+", "", $tp[$i]);
                    break;
            	}
        	}
   		}
		if (trim($cp) == "")
		$cp = shell_exec("sensors | grep \"Core \" | awk '{ T += \$3 } { C += 1 } END { print T/C } '");
		$cp = (int)$cp;
		if (trim($cp) == 0 || trim($cp) == "") {
			$temp = "<span style='color:#777'>No Support</span>";
		} else {
			$temp = substr($cp,0,2)." &deg;C";
		}
		return $temp;
	}

	public function io_cpu()
	{
		$io_cpu = ''; //iowait
		$io_cpu = shell_exec("iostat -c -y 1 1 | grep -v 'Linux' | egrep '[0-9]+' | tr -s '[[:space:]]' | sed -e 's/,/./g' | awk '{s+=$4} END {print s}'");
		return $io_cpu;
	}

	public function system_load()
	{
		$sl = ''; $cpu = '';
		$sl = shell_exec("head -1 /proc/loadavg");
		$sl = explode(" ", $sl);
		$cpu = shell_exec("grep ^processor /proc/cpuinfo | wc -l");
		$pc = array(round(($sl[0]/$cpu)*100, 0), round(($sl[1]/$cpu)*100, 0), round(($sl[2]/$cpu)*100, 0));
		if ($pc[0] > 100) $pc[0] = 100;
		if ($pc[1] > 100) $pc[1] = 100;
		if ($pc[2] > 100) $pc[2] = 100;
		$r = array('1m' => $pc[0], '5m' => $pc[1], '15m' => $pc[2], '1v' => $sl[0], '5v' => $sl[1], '15v' => $sl[2]);
		return $r;
	}

	public function cpu_bar()
	{
		$cpuBar = ''; $usage = '';
		$cpuBar = shell_exec("ps -eo pcpu | grep -v CPU | sed -e 's/,/./g' | awk '{s+=$1} END {print s}'");
		$cpuBar = floatval($cpuBar);
		if ($cpuBar >= 0 && $cpuBar <= 100) {
			if ($cpuBar <= 10) {
				$usage = "<span style=\"color:#555555\">".$cpuBar."%</span>";
			}
			else if ($cpuBar > 10 || $cpuBar <= 100) {
				$usage = "<span style=\"color:#f5f5f5;text-shadow: unset;\">".$cpuBar."%</span>";
			} else {
				$usage = 99;
			}
			return array($cpuBar, $usage);
		} else {
			$usage = "<span style=\"color:#f5f5f5;text-shadow: unset;\">100%</span>";
			return array(100, $usage);
		}
	}


}


?>