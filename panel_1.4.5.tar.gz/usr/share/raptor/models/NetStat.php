<?php 
/**
 *
 * @package Main Raptorcache
 * @since 2.0
 */

namespace Raptor\Models;

class NetStat
{
	public function cnx_us() 
	{
		$cnx = 0;	
		$cnx = shell_exec("netstat -ntu | grep -e'8080' -e'3128'| wc -l");
		return $cnx;
	}	

	public function open_threads_netstat() 
	{
		$cnx = 0;
		$cnx = shell_exec("sudo rpcnx");
		$cnx = round($cnx, 0);
		return $cnx;
	}	

	public function num_us() 
	{
		$num_us = 1;
		$num_us = shell_exec("netstat -plan|grep :3128 | awk {'print $5'} | cut -d: -f 1 | sort | uniq -c | sort -n | grep -v 0.0.0.0 | grep -v 127.0.0.1 | wc -l");
		return $num_us;
	}

	public function cnx_dns() 
	{
		$cnx_dns = "";
		$cnx_dns = shell_exec("less \/var\/cache\/bind\/named_dump.db | grep -v ';' | grep -v 'DATE' | sort | uniq -c | wc -l");
		if ($cnx_dns < 5) 
		$cnx_dns = "<span style='color:#777'>Disabled</span>";
		return $cnx_dns;
	}
}

 ?>