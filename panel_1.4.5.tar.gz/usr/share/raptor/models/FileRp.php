<?php 

namespace Raptor\Models;

use Raptor\Models\File;

class FileRp extends File
{
	protected $routeLocation;

	public function __construct($fileLocation)
	{
		parent::__construct($fileLocation);
		$location_url = explode("/", $_SERVER['REQUEST_URI']);
		$this->routeLocation = end($location_url);	
	}

	public function showRules() 
	{		
		$arrline = $this->getContent();
		$arrline = explode("\n", $arrline);
		$tbl = "<table class='sortable' cellspacing='0'>"; 
	    $tbl .= "<tr>";
	    $tbl .= "<th>&nbsp;</th>";
	    $tbl .= "<th>Name</th>";
	    $tbl .= "<th>Rule</th>";
	    $tbl .= "<th style='border-right:none;'></th>";
	    $tbl .= "<th style='border-right:none;'></th>";
	    $tbl .= "<th style='border-right:none;'></th>";
	    $tbl .= "<th style='border-right:none;padding: 2px 4px;'></th>";
	    $tbl .= "</tr>";		
		$total_items = 0; $item = 1;
		for ($i=0; $i < count($arrline); $i++) { 
			if ( strpos($arrline[$i], "#name#") !== FALSE ) {				
				$total_items++;
			}
		}			
		for ($i=0; $i < count($arrline); $i++) { 				
			if ( strpos($arrline[$i], "#name") !== FALSE ) {
				$line = explode("#name#",$arrline[$i]);
				$rule = $line[0];										
				$name = $line[1];
				$up_rule = ($item > 1) ? $this->move_up_rule($name) : ''; 
				$down_rule = ($item == $total_items) ? '' : $this->move_down_rule($name);				
				if (substr($arrline[$i], 0, 5) == "##-##") {					
					$rule = substr($rule, 5);										
					$tbl .= "<tr class='row'>";
					$tbl .= "<td style='color:#AAA;width:40px;'>".$this->state_rule($name, "OFF")."</td>";
					$tbl .= "<td style='color:#AAA;text-align:left;'>".$name."</td>";
					$tbl .= "<td style='color:#AAA;text-align:left;width:700px;'>".$rule."</td>";	
					$tbl .= "<td style='padding-right:0'>".$up_rule."</td>";
					$tbl .= "<td style='padding-right:0'>".$down_rule."</td>";
					$tbl .= "<td style='padding-right:0'>".$this->edit_rule($i)."</td>";
					$tbl .= "<td style='color:#AAA;padding: 2px 4px;'>".$this->delete_rule($name, $rule)."</td>";
					$tbl .= "</tr>";				
				} else {
					if (substr($arrline[$i], 0, 1) == "#") 
						continue;						
					$tbl .= "<tr class='row'>";
					$tbl .= "<td style='width:40px;'>".$this->state_rule($name, "ON")."</td>";
					$tbl .= "<td style='text-align:left;'>".$name."</td>";
					$tbl .= "<td style='text-align:left;width:700px;'>".$rule."</td>";			
					$tbl .= "<td style='padding-right:0'>".$up_rule."</td>";
					$tbl .= "<td style='padding-right:0'>".$down_rule."</td>";					
					$tbl .= "<td style='padding-right:0'>".$this->edit_rule($i)."</td>";					
					$tbl .= "<td style='padding: 2px 4px;'>".$this->delete_rule($name, $rule)."</td>";
					$tbl .= "</tr>";				
				}
				$item++;				
			}
		}
		$tbl .= "<table class='t_footer'><tr><td colspan='7'>{$total_items}&nbsp;" . (($total_items > 1) ? $txt='items' : $txt='item') . "</td></tr></table>";
		$tbl .= "</table>";
		return $tbl;
	} 
	
	protected function state_rule($rule_name, $rule_state)
	{
		if ($rule_state == "ON") {
			return "<a class='enabled_pl change_state' href='#' data-change_state=\"{$rule_name}\" data-location={$this->routeLocation} data-file={$this->fileLocation}>ON</a>";
		} else {
			return "<a class='disabled_pl change_state' href='#' data-change_state=\"{$rule_name}\" data-location={$this->routeLocation} data-file={$this->fileLocation}>OFF</a>";
		}	
	}

	protected function move_up_rule($rule_name)
	{
		return "<a class='arrow_up move' href='#' data-regex_name=\"{$rule_name}\" data-move='up' data-location={$this->routeLocation} data-file={$this->fileLocation}><span class='icon-caret-up'></span></a>";
	}

	protected function move_down_rule($rule_name)
	{
		return "<a class='arrow_down move' href='#' data-regex_name=\"{$rule_name}\" data-move='down' data-location={$this->routeLocation} data-file={$this->fileLocation}><span class='icon-caret-down'></span></a>";
	}	

	protected function edit_rule($i)
	{
		return "<a class='editRule' onclick='window.dat=".$i."'><span class='icon-pencil-square-o'></span></a>";
	}    	

	protected function delete_rule($rule_name, $rule)
	{
		return "<a href='#' class='del_regx' data-delete_line={$rule_name} data-location={$this->routeLocation} data-file={$this->fileLocation}>X</a>";	
	}  

	public function getValueDirective($directive)
	{
		$content = explode("\n", $this->getContent());
		foreach ($content as $value) {
			if (strstr($value, $directive)) {
				$val = explode(' ', $value);
				$val = $val[1];
			}
		}
		return $val;
	}

	public function updateValueDirective($directive, $newValue)
	{
		$content = explode("\n", $this->getContent());
		$pos = 0;
		foreach ($content as $value) {
			if (strstr($value, $directive)) {
				$val = explode(' ', $value);				
				file_put_contents($this->fileLocation, str_replace($content[$pos], $val[0] . ' ' . $newValue, $this->getContent())); 
			}
			$pos++;
		}		
	}
/* 
	private function putValueDirective($num_row, $directiveValue) 
	{
		$content      = file_get_contents($this->fileLocation);
		$file_arr_ln  = explode("\n", $content);	
		$line_string  = $file_arr_ln[$num_row];
		$arrdirective = explode(" ", $line_string);
		$new_line     = $arrdirective[0]." ".$directiveValue;
		file_put_contents($this->fileLocation, str_replace($line_string, $new_line, $content)); 	 
	}
 	public function setValueDirective($directiveName, $directiveValue)
	{	
		$content     = file_get_contents($this->fileLocation);
		$file_arr_ln = explode("\n", $content);		
		$pos = 0;
		foreach($file_arr_ln as $linea) { 
			if (strpos($linea, $directiveName) !== FALSE) {
				$num_row = $pos;   
				$this->putValueDirective($num_row, $directiveValue); 
				break;   	
			}   
			$pos++;
		} 
	} */

	public function get_core_version() {
		$vrp = shell_exec("sudo /usr/sbin/raptor -v | awk '{print $3}' | head -1");
		if(count($vrp) < 2 || count($vrp) > 4)
			$vrp =  shell_exec("sudo /usr/sbin/raptor | grep 'Raptor' | awk '{print $6}' | head -1");
		return $vrp;
	}

	public function get_panel_version()
	{
		$vp    = search_string("/usr/share/raptor/main/aboutIs.php", "verwp");
		$vp    = explode("=", $vp['string']);
		$vp    = $vp[1];
		$quit  = array('"');
		$vp    = str_replace($quit, "", $vp);
		return trim($vp);
	}

	public function get_services_version() {
		$vsvc = shell_exec("sudo /usr/bin/clean -v");
		if ($vsvc == "") {
			$vsvc = 0;
		}
		return trim($vsvc);
	}

	public function get_lic_name_raptor() 
	{
		$nlic_rp = shell_exec("sudo /usr/sbin/raptor | grep 'Licence:' | cut -d: -f2");
		if ($nlic_rp != "") {
			$lic = $nlic_rp;
		} else {
			$lic = "Free";
		}
		return trim($lic);
	}

	public function get_lic_key_raptor() 
	{
		$nkey_rp = shell_exec("sudo /usr/sbin/raptor | grep 'Key:' | cut -d: -f2");
		if ($nkey_rp != "") {
			$key = $nkey_rp;
		} else {
			$key = "Uknow";
		}
		return trim($key);
	}	

}	

 ?>