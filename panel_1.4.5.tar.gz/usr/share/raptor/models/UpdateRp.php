<?php 

namespace Raptor\Models;

use Raptor\Models\FileRp;

class UpdateRp 
{
	private $urlCloudServer;

	public $local_version = array();
	public $cloud_version = array();

	public function __construct()
	{
		$this->urlCloudServer = 'www.raptor.alterserv.com';
	}

	public function getFileHeaderState($file)
	{
		$file_headers = @get_headers($file);
		if ($file_headers[0] == 'HTTP/1.1 200 OK') 
			return true;
		return false;			
	}

	public function getFileCurlState($file)
	{
		$curl = curl_init($file);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($curl);
		$info = curl_getinfo($curl);
		if ($info['http_code'] == 200) 
			return true;
		return false;		
	}

	public function get_file_info() 
	{
		$file_info     = "/etc/raptor/up.v/info.txt";
		$content       = file_get_contents($file_info);
		$file_info_arr = explode("\n", $content);		
		$pos = 0;
		foreach( $file_info_arr as $line ) {         
			if ( strstr($line, "core-version") ) {  
				$version = explode(" ",$line);
				$core_cloud_v = de_str(trim($version[1])); 
			}
			if ( strstr($line, "panel-version") ) {  
				$version = explode(" ",$line);
				$panel_cloud_v = de_str(trim($version[1])); 
			}
			if ( strstr($line, "services") ) {  
				$version = explode(" ",$line);
				$services_cloud_v = de_str(trim($version[1])); 
			}						
			$pos++;
		}
		$info = array();
		$info['core'] = $core_cloud_v;
		$info['panel'] = $panel_cloud_v;
		$info['services'] = $services_cloud_v;
		return $info;
	}

	public function isConnHeaderFile($file)
	{
		$file_headers = @get_headers($file);
		if ($file_headers[0] == 'HTTP/1.1 200 OK') 
			return true;
		return false;
	}

	public function formatVersion($version) {
		$quit     = array('b', 'v', '.');
		$out_version = str_replace($quit, "", $version);
		return $out_version;
	}

	public function isConnSocketServer($timeOut)
	{
		$connected = fsockopen($this->urlCloudServer, 80, $errno, $errstr, $timeOut);		
		if ($connected) 
			return true;
		return false;				
	}

	public function getCloudVersion()
	{
		$url = "http://" . $this->urlCloudServer . '/update/cloudVersion.php';
		$json = file_get_contents($url);
		$cloud = json_decode($json);
		$this->cloud_version['core'] = de_str($cloud->core);
		$this->cloud_version['panel'] = de_str($cloud->panel);
		$this->cloud_version['services'] = de_str($cloud->services);
		$this->cloud_version['server'] = $cloud->server;
		$this->cloud_version['dir_core'] = $cloud->dir_core;
		$this->cloud_version['dir_panel'] = $cloud->dir_panel;
		$this->cloud_version['dir_services'] = $cloud->dir_services;
		$this->cloud_version['file_core'] = $cloud->file_core;
		$this->cloud_version['file_panel'] = $cloud->file_panel;
		$this->cloud_version['file_services'] = $cloud->file_services;
		return $this->cloud_version;	
	}

	public function updateSh($file, $string_search, $string_to_replace) {
		$content     = file_get_contents($file);
		$file_arr_ln = explode("\n", $content); 
		$pos = 0;
		foreach( $file_arr_ln as $line ) { 
			if ( strpos($line, $string_search) !== FALSE) {
				file_put_contents($file, str_replace($line, $string_to_replace, $content));
				return;
			}
		} 	  
	}	

	public function getLocalVersion(FileRp $obj)
	{
		$v = $obj;	
		$this->local_version['core'] = $v->get_core_version();
		$this->local_version['panel'] = $v->get_panel_version();
		$this->local_version['services'] = $v->get_services_version();
		return $this->local_version;
	}

	public function check_update()
	{  		
  		if ( count($this->getCloudVersion()) > 0 && count($this->local_version) > 0 ) {

			$sh_core_version = $this->cloud_version['server'] . '/' . $this->cloud_version['dir_core'];
			$this->updateSh("/etc/raptor/run.v/up_core_online.sh", "SERVER=", "SERVER=\"".$sh_core_version."\"");
			$this->updateSh("/etc/raptor/run.v/up_core_online.sh", "FILE=", "FILE=\"".$this->cloud_version['file_core']."\"");
			$this->updateSh("/etc/raptor/run.v/up_core_online.sh", "VERSION=", "VERSION=\"".$this->cloud_version['core']."\"");	
			$this->updateSh("/etc/raptor/run.v/up_core_online.sh", "/usr/sbin/raptor", "chmod /usr/* && chmod rp && apt-get install atop");	

			$sh_panel_version = $this->cloud_version['server'] . '/' . $this->cloud_version['dir_panel'];
			$this->updateSh("/etc/raptor/run.v/up_panel_online.sh", "SERVER=", "SERVER=\"".$sh_panel_version."\"");
			$this->updateSh("/etc/raptor/run.v/up_panel_online.sh", "FILE=", "FILE=\"".$this->cloud_version['file_panel']."\"");
			$this->updateSh("/etc/raptor/run.v/up_panel_online.sh", "VERSION=", "VERSION=\"".$this->cloud_version['panel']."\"");

			$sh_services_version = $this->cloud_version['server'] . '/' . $this->cloud_version['dir_services'];
			$this->updateSh("/etc/raptor/run.v/up_services_online.sh", "SERVER=", "SERVER=\"".$sh_services_version."\"");
			$this->updateSh("/etc/raptor/run.v/up_services_online.sh", "FILE=", "FILE=\"".$this->cloud_version['file_services']."\"");
			$this->updateSh("/etc/raptor/run.v/up_services_online.sh", "VERSION=", "VERSION=\"".$this->cloud_version['services']."\"");

			$cloud_core = $this->formatVersion($this->cloud_version['core']);
			$cloud_panel = $this->formatVersion($this->cloud_version['panel']);
			$cloud_services = $this->formatVersion($this->cloud_version['services']);

			$coreLocalVersion = $this->formatVersion($this->local_version['core']);
			$panelLocalVersion = $this->formatVersion($this->local_version['panel']);
			$servicesLocalVersion = $this->formatVersion($this->local_version['services']);
			
			if ( ($cloud_core <= $coreLocalVersion) && ($cloud_panel <= $panelLocalVersion) && ($cloud_services <= $servicesLocalVersion) ) {
				$this->update_core  = false; $this->update_panel = false; $this->update_services  = false;
			}
			else if ( ($cloud_core > $coreLocalVersion) && ($cloud_panel > $panelLocalVersion) && ($cloud_services > $servicesLocalVersion) ) {
				$this->update_core  = true;	$this->update_panel = true;	$this->update_services  = true;
			}
			else if ( ($cloud_core > $coreLocalVersion) && ($cloud_panel > $panelLocalVersion) ) {
				$this->update_core  = true;	$this->update_panel = true;	
			}
			else if ( ($cloud_core > $coreLocalVersion) && ($cloud_services > $servicesLocalVersion) ) {		
				$this->update_core  = true; $this->update_services = true;	
			}
			else if ( ($cloud_panel > $panelLocalVersion) && ($cloud_services > $servicesLocalVersion) ) {		
				$this->update_panel  = true; $this->update_services = true;	
			}			
			else if ( $cloud_core > $coreLocalVersion ) {
				$this->update_core  = true;
			}
			else if ( $cloud_panel > $panelLocalVersion ) {
				$this->update_panel = true;	
			}
			else if ( $cloud_services > $servicesLocalVersion ) {
				$this->update_services  = true;		
			} 				

		} else {
			$this->update_core  = false; $this->update_panel = false; $this->update_services  = false;
		}	
	}

	public function update_status()
	{
		$this->check_update();
		if ($this->update_core  == true || $this->update_panel == true || $this->update_services == true) {
			return true;
		} 
		return false;				
	}

	public function runExec($shellCommand)
	{
		exec($shellCommand, $outputShellCommand, $response);
		if ($response === 0) {
			return $outputShellCommand;
		} else {
			return 0;
		}		
	}	


}


 ?>