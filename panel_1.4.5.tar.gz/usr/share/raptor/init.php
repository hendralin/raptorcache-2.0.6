<?php
/**
 *
 * @package Main Raptorcache
 * @since 1.0
 */

require 'class/autoload.php';
require 'models/autoload.php';

use Raptor\Models\Login;

$db = Database::getInstance();
$db->getConnection();
$user = new Login($db);
$user->loginUser();
$db->disconnectDB();

?>