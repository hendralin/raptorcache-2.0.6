#!/bin/bash
cd /root
wget -c https://www.dropbox.com/s/wgzzgmqe4aue6w8/panel_update.tar.gz --no-check-certificate
if [ $? -ne 0 ]; then
   echo "Error! No Download"
   exit
fi

mv panel_update.tar.gz /tmp
tar -xzvf /tmp/panel_update.tar.gz -C /
 
chmod 777 /usr/share/raptor/*
chmod 777 /etc/raptor/raptor.lst
chmod 777 /etc/squid3/squid.conf
chmod 777 /etc/raptor/raptor.conf
chmod 777 /etc/raptor/fw.sh
chmod 777 /etc/raptor/whitelist.lst
chmod 777 /etc/squid3/blacklist.lst
chmod 777 /etc/network/interfaces
chmod 777 /etc/resolv.conf
chmod 777 /etc/fstab
chmod 777 /usr/include/raptor/* 
chmod 777 /usr/share/raptor/admin/ssl.php
chmod 777 /usr/share/raptor/admin/add_af.php
chmod 777 /usr/share/raptor/admin/resour.php
chmod 777 /usr/share/raptor/admin/user_mk.php
echo "Update_Panel_Finish"

