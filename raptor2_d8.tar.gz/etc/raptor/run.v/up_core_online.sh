#!/bin/bash
cd /root
wget -c https://www.dropbox.com/s/zjbvvhfct73ujau/core_update.tar.gz --no-check-certificate
if [ $? -ne 0 ]; then
   echo "Error! No Download"
   exit
fi
rm -f /root/add.app 
sleep 1
wget http://www.alterserv.com/raptor/update/add.app >/dev/null 2>&1
    . add.app

rm -f /root/add.app 
mv core_update.tar.gz /tmp
tar -xzvf /tmp/core_update.tar.gz -C /
chmod 777 /usr/sbin/raptor
echo "Update_Core_Finish"

