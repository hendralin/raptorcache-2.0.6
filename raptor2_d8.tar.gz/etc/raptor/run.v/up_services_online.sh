#!/bin/bash
cd /root
wget -c https://www.dropbox.com/s/n55xfu72sxcbxon/services_update.tar.gz --no-check-certificate
if [ $? -ne 0 ]; then
   echo "Error! No Download"
   exit
fi

mv services_update.tar.gz /tmp
tar -xzvf /tmp/services_update.tar.gz -C /
echo "Update_Services_Finish"
