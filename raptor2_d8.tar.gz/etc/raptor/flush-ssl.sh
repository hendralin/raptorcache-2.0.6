#!/bin/bash

/etc/init.d/squid3 stop

rm -rf /usr/local/raptor/cache-ssl
echo "Clean cache"
sleep 2
mkdir /usr/local/raptor/cache-ssl
chmod 777 /usr/local/raptor/cache-ssl

mysql -u root raptor -praptor << eof
TRUNCATE summary_days;
eof

squid3 -z

/etc/init.d/squid3 restart
/etc/init.d/raptor restart
/etc/init.d/squid3 restart

echo "Done"
echo ""


