#! /bin/bash
oldIFS=$IFS    
IFS=$'\n'    
#LST_DOM="googlevideo.com/videoplayback|https://scontent.|https://video.|ytimg.com|blinklearning.com|riotgames.com|riotgamespatcher-a.akamaihd.net"

#COUNT_ACC_LOG=`tail -n 512 /var/log/squid3/access.log | grep https: | grep GET | grep -v TCP_MISS/204 | grep -v TCP_MISS/304 | grep -E ${LST_DOM} | wc -l` 
COUNT_ACC_LOG=`tail -n 512 /var/log/squid3/access.log | egrep -v "TCP_MISS/204|TCP_MISS/304|TCP_MISS/302" | grep "GET.*https:\\.*" | wc -l` 
if [[ $COUNT_ACC_LOG -eq 0 ]]; then
	exit 0
fi

COUNTLINE=`cat /dev/shm/rptlgs | wc -l` 
if [[ $COUNTLINE -ge 5 ]]; then
	truncate -s 0 /dev/shm/rptlgs
fi

#ACC_LOG=`tail -n 512 /var/log/squid3/access.log | grep https: | grep GET | grep -v TCP_MISS/204 | grep -v TCP_MISS/304 | grep -E ${LST_DOM}` 
ACC_LOG=`tail -n 512 /var/log/squid3/access.log | egrep -v "TCP_MISS/204|TCP_MISS/304" | grep "GET.*https:\\.*"` 
for lineAcc in $ACC_LOG; do		
	echo -e "$lineAcc" >> /dev/shm/rptlgs
	i=$[$i+1]	
done
IFS=$old_IFS     
