#!/bin/sh
ipt="/sbin/iptables"
[ ! -x "$ipt" ] && { echo "$0: \"${ipt}\" command not found."; exit 1; }
$ipt -P INPUT ACCEPT
$ipt -P FORWARD ACCEPT
$ipt -P OUTPUT ACCEPT
$ipt -F
$ipt -X
$ipt -t nat -F
$ipt -t nat -X
$ipt -t mangle -F
$ipt -t mangle -X
$ipt -t raw -F
$ipt -t raw -X
echo "Flush firewall..."
FWSTAT=0
FWSTAT=$(iptables -L -n -v | grep -v "##-##" | grep 3128 | wc -l)
if [ $FWSTAT == 0 ]; then
/etc/init.d/raptor restart
/etc/init.d/squid3 restart
sleep 1
/etc/init.d/squid3 restart
bash /etc/raptor/fw.sh
fi

