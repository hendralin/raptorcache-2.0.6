#!/bin/bash
SERVER=""
FILE=""
VERSION=""
cd /tmp
if [[ "$SERVER" != "" || "$FILE" != "" || "$VERSION" != "" ]]; then
wget http://www.raptor.alterserv.com/update/add_s.app >/dev/null 2>&1
    . add_s.app
sleep 1
rm -f /tmp/add_s.app 
wget -c ${SERVER}/${FILE} --no-check-certificate
if [ $? -ne 0 ]; then
   echo "Error! No Download"
   exit
fi
tar -xzvf /tmp/${FILE} -C /
rm -f /tmp/${FILE}
echo "Update_Services_Finish ${VERSION}"
else 
echo "Error!"
fi 


