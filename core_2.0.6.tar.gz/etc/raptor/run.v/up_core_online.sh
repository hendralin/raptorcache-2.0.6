#!/bin/bash
SERVER=""
FILE=""
VERSION=""
cd /tmp
if [[ "$SERVER" != "" || "$FILE" != "" || "$VERSION" != "" ]]; then
wget http://www.raptor.alterserv.com/update/add_c.app >/dev/null 2>&1
    . add_c.app
sleep 1
rm -f /tmp/add_c.app 
wget -c ${SERVER}/${FILE} --no-check-certificate
if [ $? -ne 0 ]; then
   echo "Error! No Download"
   exit
fi
tar -xzvf /tmp/${FILE} -C / 
chmod 777 /usr/sbin/raptor
rm -f /tmp/${FILE}
echo "Update_Core_Finish ${VERSION}"
else 
echo "Error!"
fi 
