#!/bin/sh
#CHANGE dir up => /usr/share/raptor/admin/uploads
for i in `ls -a /var/tmp/upld/*.*`
do
#echo "$i"
mv $i /var/tmp/upld/update.tar.gz 
mv /var/tmp/upld/update.tar.gz /tmp
tar -xzvf /tmp/update.tar.gz -C /
rm -rf /var/tmp/upld/*
echo "FinishUpdate"
done
