#!/bin/bash

curl http://www.raptor.alterserv.com/update/info.txt > /etc/raptor/up.v/info.txt
if [ $? -ne 0 ]; then
   echo "Error! Internet Connection"
   exit
fi
curl http://www.raptor.alterserv.com/update/core_changelog.txt > /etc/raptor/up.v/core_changelog.txt
curl http://www.raptor.alterserv.com/update/panel_changelog.txt > /etc/raptor/up.v/panel_changelog.txt
curl http://www.raptor.alterserv.com/update/services_changelog.txt > /etc/raptor/up.v/services_changelog.txt

#cat info.txt
