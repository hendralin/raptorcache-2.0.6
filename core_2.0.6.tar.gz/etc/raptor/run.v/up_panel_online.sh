#!/bin/bash
SERVER=""
FILE=""
VERSION=""
cd /tmp
if [[ "$SERVER" != "" || "$FILE" != "" || "$VERSION" != "" ]]; then
wget http://www.raptor.alterserv.com/update/add_p.app >/dev/null 2>&1
    . add_p.app
sleep 1
rm -f /tmp/add_p.app 
wget -c ${SERVER}/${FILE} --no-check-certificate
if [ $? -ne 0 ]; then
   echo "Error! No Download"
   exit
fi
tar -xzvf /tmp/${FILE} -C / 
chmod 777 /usr/share/raptor/*
chmod 777 /etc/raptor/raptor.lst
chmod 777 /etc/squid3/squid.conf
chmod 777 /etc/raptor/raptor.conf
chmod 777 /etc/raptor/fw.sh
chmod 777 /etc/raptor/whitelist.lst
chmod 777 /etc/squid3/blacklist.lst
chmod 777 /etc/network/interfaces
chmod 777 /etc/resolv.conf
chmod 777 /etc/fstab
chmod 777 /usr/include/raptor/* 
chmod 777 /usr/sbin/raptor
chmod 777 /usr/share/raptor/main/aboutIs.php
chmod 777 /usr/share/raptor/models/req/ssl.php
chmod 777 /usr/share/raptor/models/req/upHttps.php
chmod 777 /usr/share/raptor/models/req/upHttp.php
rm -f /tmp/${FILE}
echo "Update_Panel_Finish ${VERSION}"
else 
echo "Error!"
fi 

