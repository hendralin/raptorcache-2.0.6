#!/bin/bash

oldIFS=$IFS    
IFS=$'\n' 

COMMAND=`ls /usr/local/raptor/address`

for LINE in $COMMAND; do
	echo "Restore list => $LINE"
	ipset restore -f /usr/local/raptor/address/${LINE}
done

IFS=$old_IFS  
