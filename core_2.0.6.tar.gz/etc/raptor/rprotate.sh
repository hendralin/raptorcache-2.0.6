#!/bin/bash
PATH="/bin:/usr/bin:/usr/local/bin"
dates=`date +%Y%m%d`
#raptorlog=/var/log/raptor/access.log
raptorlog=/var/log/raptor/
find $raptorlog -name '*.log' -type f -size +30720k | while read logfile
do       # the parsing of a line
 echo $logfile
 newlogfile=$logfile.$dates
 cp $logfile $newlogfile
 cat /dev/null > $logfile
 gzip -f -9 $newlogfile
done
find $raptorlog -name '*.gz' -type f -mtime 30 | xargs rm -f